import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { StudentLayout, CoachLayout, ParentLayout } from './components/Layout';

// Auth
import AuthPage from './pages/AuthPage';

// Student pages
import StudentDashboard from './pages/student/Dashboard';
import StudentProfile from './pages/student/Profile';
import StudentStudy from './pages/student/Study';
import StudentSubjects from './pages/student/Subjects';
import StudentResources from './pages/student/Resources';
import StudentTasks from './pages/student/Tasks';
import StudentCalendar from './pages/student/Calendar';
import StudentExams from './pages/student/Exams';
import StudentAnalysis from './pages/student/Analysis';
import StudentWrongs from './pages/student/Wrongs';
import StudentRepetition from './pages/student/Repetition';
import StudentCompare from './pages/student/Compare';
import StudentAICoach from './pages/student/AICoach';
import StudentWeeklyReport from './pages/student/WeeklyReport';
import StudentMotivation from './pages/student/Motivation';
import StudentMessages from './pages/student/Messages';
import StudentNotifications from './pages/student/Notifications';

// Coach pages
import CoachDashboard from './pages/coach/Dashboard';
import CoachRiskAnalysis from './pages/coach/RiskAnalysis';
import CoachAccounting from './pages/coach/Accounting';
import CoachClassOverview from './pages/coach/ClassOverview';
import CoachClassAnalysis from './pages/coach/ClassAnalysis';
import CoachStudents from './pages/coach/Students';
import CoachStudentDetail from './pages/coach/StudentDetail';
import CoachWeeklyProgram from './pages/coach/WeeklyProgram';
import CoachTaskManagement from './pages/coach/TaskManagement';
import CoachAssignResource from './pages/coach/AssignResource';
import CoachAssignSubject from './pages/coach/AssignSubject';
import CoachLessonManagement from './pages/coach/LessonManagement';
import CoachExamTemplate from './pages/coach/ExamTemplate';
import CoachCreateExam from './pages/coach/CreateExam';
import CoachEnterResult from './pages/coach/EnterResult';
import CoachBulkResult from './pages/coach/BulkResult';
import CoachMessages from './pages/coach/Messages';
import CoachNotes from './pages/coach/Notes';
import CoachMeetingsPayments from './pages/coach/MeetingsPayments';
import CoachBulkNotify from './pages/coach/BulkNotify';
import CoachClassReport from './pages/coach/ClassReport';

// Parent pages
import ParentOverview from './pages/parent/Overview';
import ParentCharts from './pages/parent/Charts';
import ParentCalendar from './pages/parent/Calendar';
import ParentNotifications from './pages/parent/Notifications';
import ParentReport from './pages/parent/Report';
import ParentAISummary from './pages/parent/AISummary';
import ParentMessage from './pages/parent/Message';

function StudentPanel() {
  return (
    <StudentLayout>
      <Routes>
        <Route path="dashboard" element={<StudentDashboard />} />
        <Route path="profile" element={<StudentProfile />} />
        <Route path="study" element={<StudentStudy />} />
        <Route path="subjects" element={<StudentSubjects />} />
        <Route path="resources" element={<StudentResources />} />
        <Route path="tasks" element={<StudentTasks />} />
        <Route path="calendar" element={<StudentCalendar />} />
        <Route path="exams" element={<StudentExams />} />
        <Route path="analysis" element={<StudentAnalysis />} />
        <Route path="wrongs" element={<StudentWrongs />} />
        <Route path="repetition" element={<StudentRepetition />} />
        <Route path="compare" element={<StudentCompare />} />
        <Route path="ai-coach" element={<StudentAICoach />} />
        <Route path="weekly-report" element={<StudentWeeklyReport />} />
        <Route path="motivation" element={<StudentMotivation />} />
        <Route path="messages" element={<StudentMessages />} />
        <Route path="notifications" element={<StudentNotifications />} />
        <Route path="*" element={<Navigate to="dashboard" replace />} />
      </Routes>
    </StudentLayout>
  );
}

function CoachPanel() {
  return (
    <CoachLayout>
      <Routes>
        <Route path="dashboard" element={<CoachDashboard />} />
        <Route path="risk" element={<CoachRiskAnalysis />} />
        <Route path="accounting" element={<CoachAccounting />} />
        <Route path="class-overview" element={<CoachClassOverview />} />
        <Route path="class-analysis" element={<CoachClassAnalysis />} />
        <Route path="students" element={<CoachStudents />} />
        <Route path="student-detail" element={<CoachStudentDetail />} />
        <Route path="weekly-program" element={<CoachWeeklyProgram />} />
        <Route path="task-management" element={<CoachTaskManagement />} />
        <Route path="assign-resource" element={<CoachAssignResource />} />
        <Route path="assign-subject" element={<CoachAssignSubject />} />
        <Route path="lesson-management" element={<CoachLessonManagement />} />
        <Route path="exam-template" element={<CoachExamTemplate />} />
        <Route path="create-exam" element={<CoachCreateExam />} />
        <Route path="enter-result" element={<CoachEnterResult />} />
        <Route path="bulk-result" element={<CoachBulkResult />} />
        <Route path="messages" element={<CoachMessages />} />
        <Route path="notes" element={<CoachNotes />} />
        <Route path="meetings" element={<CoachMeetingsPayments />} />
        <Route path="bulk-notify" element={<CoachBulkNotify />} />
        <Route path="class-report" element={<CoachClassReport />} />
        <Route path="*" element={<Navigate to="dashboard" replace />} />
      </Routes>
    </CoachLayout>
  );
}

function ParentPanel() {
  return (
    <ParentLayout>
      <Routes>
        <Route path="overview" element={<ParentOverview />} />
        <Route path="charts" element={<ParentCharts />} />
        <Route path="calendar" element={<ParentCalendar />} />
        <Route path="notifications" element={<ParentNotifications />} />
        <Route path="report" element={<ParentReport />} />
        <Route path="ai-summary" element={<ParentAISummary />} />
        <Route path="message" element={<ParentMessage />} />
        <Route path="*" element={<Navigate to="overview" replace />} />
      </Routes>
    </ParentLayout>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<AuthPage />} />
        <Route path="/student/*" element={<StudentPanel />} />
        <Route path="/coach/*" element={<CoachPanel />} />
        <Route path="/parent/*" element={<ParentPanel />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

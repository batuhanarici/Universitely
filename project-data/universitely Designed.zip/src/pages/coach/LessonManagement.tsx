import { useState } from 'react';
import { Card, Input, Label, FormGroup, Btn, useToast } from '../../components/ui';
import { subjects as initial } from '../../lib/mockData';

const initialLessons = [...new Set(initial.map(s => s.lesson))];

export default function CoachLessonManagement() {
  const { toast, show } = useToast();
  const [lessons, setLessons] = useState(initialLessons);
  const [allSubjects, setAllSubjects] = useState(initial);
  const [selectedLesson, setSelectedLesson] = useState(initialLessons[0]);
  const [lessonInput, setLessonInput] = useState('');
  const [subjectInput, setSubjectInput] = useState('');

  function addLesson(e: React.FormEvent) {
    e.preventDefault();
    if (!lessonInput.trim() || lessons.includes(lessonInput.trim())) return;
    setLessons(l => [...l, lessonInput.trim()]);
    setLessonInput('');
    show('Ders eklendi ✓');
  }

  function addSubject(e: React.FormEvent) {
    e.preventDefault();
    if (!subjectInput.trim() || !selectedLesson) return;
    setAllSubjects(l => [...l, { id: Date.now().toString(), name: subjectInput.trim(), lesson: selectedLesson, done: false, weak: false }]);
    setSubjectInput('');
    show('Konu eklendi ✓');
  }

  const currentSubjects = allSubjects.filter(s => s.lesson === selectedLesson);

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {toast}
      <div><h1 className="page-title">Ders / Konu Yönetimi</h1></div>

      <div className="grid-2">
        <Card>
          <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Dersler</h3>
          <form onSubmit={addLesson} style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
            <Input placeholder="Yeni ders adı" value={lessonInput} onChange={e => setLessonInput(e.target.value)} />
            <Btn variant="primary" type="submit" size="sm">Ekle</Btn>
          </form>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {lessons.map(l => (
              <button key={l} onClick={() => setSelectedLesson(l)}
                style={{ padding: '6px 14px', borderRadius: 8, border: selectedLesson === l ? '1.5px solid #E4BB60' : '1.5px solid rgba(15,27,45,0.15)', background: selectedLesson === l ? 'rgba(228,187,96,0.12)' : 'transparent', fontFamily: 'var(--font-body)', fontSize: 13, fontWeight: 600, color: selectedLesson === l ? '#A07C20' : '#0F1B2D', cursor: 'pointer' }}>
                {l}
              </button>
            ))}
          </div>
        </Card>

        <Card>
          <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>
            {selectedLesson} Konuları
          </h3>
          <form onSubmit={addSubject} style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
            <Input placeholder="Yeni konu adı" value={subjectInput} onChange={e => setSubjectInput(e.target.value)} />
            <Btn variant="primary" type="submit" size="sm">Ekle</Btn>
          </form>
          <div className="rule-lines" style={{ borderRadius: 8, overflow: 'hidden' }}>
            {currentSubjects.length === 0 ? (
              <p style={{ padding: '10px 12px', fontSize: 13, color: 'rgba(15,27,45,0.45)' }}>Konu yok. Ekleyin.</p>
            ) : currentSubjects.map(s => (
              <div key={s.id} style={{ padding: '9px 12px', fontSize: 13, color: '#0F1B2D' }}>{s.name}</div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

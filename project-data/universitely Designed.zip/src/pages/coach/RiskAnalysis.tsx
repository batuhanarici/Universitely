import { useState } from 'react';
import { Card, Badge, KPICard, ProgressBar, AnimatedNumber } from '../../components/ui';
import { riskScores } from '../../lib/mockData';

const factorLabels: Record<string, string> = {
  netDrop: 'Net Düşüşü',
  pendingTask: 'Bitmemiş Görev',
  wrongUnsolved: 'Çözülmemiş Yanlış',
  resourceDelay: 'Kaynak Gecikmesi',
  lowTempo: 'Düşük Tempo',
};

const suggestions: Record<string, string[]> = {
  yüksek: ['Acil görüşme planla', 'Haftalık takip başlat', 'Ailesini bilgilendir', 'Çalışma takvimi oluştur'],
  orta: ['Ek kaynak ata', 'Hedef netini gözden geçir', 'Tekrar planını güçlendir'],
  düşük: ['Mevcut ilerlemeyi koru', 'Motivasyonu sürdür'],
};

export default function CoachRiskAnalysis() {
  const [expanded, setExpanded] = useState<string | null>(null);
  const high = riskScores.filter(r => r.level === 'yüksek').length;
  const mid = riskScores.filter(r => r.level === 'orta').length;
  const low = riskScores.filter(r => r.level === 'düşük').length;

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div>
        <h1 className="page-title">AI Risk Analizi</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Kural tabanlı risk değerlendirmesi</p>
      </div>

      <div className="grid-3">
        <KPICard label="Yüksek Risk" value={high} color="#C4503A" />
        <KPICard label="Orta Risk" value={mid} color="#E4BB60" />
        <KPICard label="Düşük Risk" value={low} color="#2A9D8F" />
      </div>

      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Öncelik Sıralaması</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
          {riskScores.map((r, i) => (
            <div key={r.studentId}>
              <div
                onClick={() => setExpanded(expanded === r.studentId ? null : r.studentId)}
                style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 8px', borderBottom: '1px solid rgba(15,27,45,0.06)', cursor: 'pointer' }}
              >
                <span className="tabular" style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, color: 'rgba(15,27,45,0.25)', minWidth: 28 }}>{i+1}</span>
                <span style={{ flex: 1, fontSize: 14, fontWeight: 500 }}>{r.studentName}</span>
                <Badge variant={r.level === 'yüksek' ? 'brick' : r.level === 'orta' ? 'gold' : 'teal'}>{r.level}</Badge>
                <span className="tabular" style={{ fontSize: 13, color: 'rgba(15,27,45,0.5)', minWidth: 50 }}>net {r.avgNet}</span>
                <div style={{ width: 100 }}><ProgressBar pct={r.score} color={r.level === 'yüksek' ? '#C4503A' : r.level === 'orta' ? '#E4BB60' : '#2A9D8F'} /></div>
                <span className="tabular" style={{ fontSize: 14, fontWeight: 700, color: r.level === 'yüksek' ? '#C4503A' : r.level === 'orta' ? '#A07C20' : '#2A9D8F', minWidth: 36 }}>{r.score}</span>
                <span style={{ fontSize: 16, color: 'rgba(15,27,45,0.3)' }}>{expanded === r.studentId ? '▲' : '▼'}</span>
              </div>

              {expanded === r.studentId && (
                <div className="anim-slide" style={{ padding: '16px 20px', background: 'rgba(15,27,45,0.02)', borderBottom: '1px solid rgba(15,27,45,0.06)' }}>
                  <div className="grid-2" style={{ marginBottom: 16 }}>
                    {Object.entries(r.factors).map(([key, val]) => (
                      <div key={key} style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <span style={{ fontSize: 12, fontWeight: 600 }}>{factorLabels[key]}</span>
                          <span className="tabular" style={{ fontSize: 12, fontWeight: 700, color: val > 60 ? '#C4503A' : val > 30 ? '#A07C20' : '#2A9D8F' }}>{val}</span>
                        </div>
                        <ProgressBar pct={val} color={val > 60 ? '#C4503A' : val > 30 ? '#E4BB60' : '#2A9D8F'} />
                      </div>
                    ))}
                  </div>
                  <div>
                    <p style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'rgba(15,27,45,0.4)', marginBottom: 8 }}>AI Önerileri</p>
                    <ul style={{ margin: 0, paddingLeft: 16, display: 'flex', flexDirection: 'column', gap: 4 }}>
                      {(suggestions[r.level] || []).map((s, j) => (
                        <li key={j} style={{ fontSize: 13, color: '#0F1B2D' }}>{s}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

import { Card, KPICard, Badge, ProgressBar, Btn } from '../../components/ui';
import { students, exams, subjectPerformance } from '../../lib/mockData';
import { downloadCSV, printPDF } from '../../lib/utils';

const weekAvgs = students.map(s => ({
  name: s.name,
  avgNet: s.avgNet,
  exams: exams.slice(0, 3).map(e => ({ name: e.name.split(' ').slice(-1)[0], net: (e.net + Math.random() * 10 - 5).toFixed(1) })),
}));

const classAvg = +(students.reduce((a, s) => a + s.avgNet, 0) / students.length).toFixed(1);

export default function CoachClassReport() {
  function downloadCsv() {
    downloadCSV('sinif-raporu', ['Öğrenci', 'Deneme Adı', 'Net'],
      students.flatMap(s => exams.map(e => [s.name, e.name, String(e.net)])));
  }
  function downloadPdf() {
    printPDF('Sınıf Haftalık Raporu', '22–28 Ocak 2024',
      ['Öğrenci', 'Deneme Sayısı', 'Ortalama Net'],
      students.map(s => [s.name, String(exams.length), String(s.avgNet)]));
  }

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div>
          <h1 className="page-title">Sınıf Raporu</h1>
          <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>22–28 Ocak 2024 · Son 7 gün</p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <Btn variant="ghost" size="sm" onClick={downloadCsv}>CSV</Btn>
          <Btn variant="primary" size="sm" onClick={downloadPdf}>PDF</Btn>
        </div>
      </div>

      <div className="grid-3">
        <KPICard label="Öğrenci" value={students.length} />
        <KPICard label="Deneme Sonucu" value={exams.length} />
        <KPICard label="Sınıf Ortalaması" value={classAvg} decimals={1} color="#E4BB60" />
      </div>

      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Ders Bazlı Başarı</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {subjectPerformance.map(s => (
            <div key={s.subject}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span style={{ fontSize: 13, fontWeight: 500 }}>{s.subject}</span>
                <span className="tabular" style={{ fontSize: 13, fontWeight: 700, color: s.pct < 55 ? '#C4503A' : '#2A9D8F' }}>{s.pct}%</span>
              </div>
              <ProgressBar pct={s.pct} color={s.pct < 55 ? '#C4503A' : '#2A9D8F'} />
            </div>
          ))}
        </div>
      </Card>

      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Öğrenci Sıralaması</h3>
        {[...weekAvgs].sort((a,b) => b.avgNet - a.avgNet).map((s, i) => (
          <div key={s.name} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 0', borderBottom: '1px solid rgba(15,27,45,0.06)' }}>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, color: 'rgba(15,27,45,0.2)', minWidth: 28 }}>{i+1}</span>
            <div style={{ flex: 1 }}>
              <p style={{ fontSize: 13, fontWeight: 500, marginBottom: 4 }}>{s.name}</p>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                {s.exams.map(e => (
                  <span key={e.name} style={{ fontSize: 10, padding: '2px 6px', borderRadius: 4, background: 'rgba(15,27,45,0.07)', color: 'rgba(15,27,45,0.7)' }}>
                    {e.name} · {e.net}
                  </span>
                ))}
              </div>
            </div>
            <div style={{ width: 80 }}><ProgressBar pct={(s.avgNet / 120) * 100} color="#E4BB60" /></div>
            <span className="metric-value" style={{ fontSize: 18, fontWeight: 700, minWidth: 40, textAlign: 'right' }}>{s.avgNet}</span>
          </div>
        ))}
      </Card>
    </div>
  );
}

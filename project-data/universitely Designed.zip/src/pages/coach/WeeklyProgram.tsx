import { useState } from 'react';
import { Card, Select, Input, Label, FormGroup, Btn, Badge, Checkbox, useToast } from '../../components/ui';
import { students } from '../../lib/mockData';
import { Icon } from '../../components/Layout';

const days = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar'];

type DayTask = { id: string; text: string; done: boolean; approved: boolean };
type Week = Record<string, DayTask[]>;

const initWeek: Week = {};
days.forEach(d => { initWeek[d] = []; });
initWeek['Pazartesi'] = [{ id: '1', text: '20 Matematik sorusu çöz', done: true, approved: false }, { id: '2', text: 'Fonksiyonlar konusunu çalış', done: false, approved: false }];
initWeek['Çarşamba'] = [{ id: '3', text: 'Fizik mekanik tekrarı', done: false, approved: false }];

export default function CoachWeeklyProgram() {
  const { toast, show } = useToast();
  const [studentId, setStudentId] = useState(students[0].id);
  const [weekStart, setWeekStart] = useState('2024-01-29');
  const [week, setWeek] = useState<Week>(initWeek);
  const [drafts, setDrafts] = useState<Record<string, string>>({});

  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekEnd.getDate() + 6);

  function addTask(day: string) {
    const text = drafts[day]?.trim();
    if (!text) return;
    text.split('\n').filter(Boolean).forEach(line => {
      setWeek(w => ({ ...w, [day]: [...(w[day] || []), { id: Date.now().toString() + Math.random(), text: line.trim(), done: false, approved: false }] }));
    });
    setDrafts(d => ({ ...d, [day]: '' }));
    show('Görev eklendi ✓');
  }

  function delTask(day: string, id: string) {
    setWeek(w => ({ ...w, [day]: w[day].filter(t => t.id !== id) }));
  }

  function today() { return weekStart; }

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {toast}
      <div><h1 className="page-title">Haftalık Program</h1></div>

      <Card style={{ padding: '14px 20px' }}>
        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-end' }}>
          <FormGroup style={{ minWidth: 180 }}>
            <Label>Öğrenci</Label>
            <Select value={studentId} onChange={e => setStudentId(e.target.value)}>
              {students.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
          </FormGroup>
          <FormGroup>
            <Label>Hafta Başı</Label>
            <Input type="date" value={weekStart} onChange={e => setWeekStart(e.target.value)} />
          </FormGroup>
          <p style={{ fontSize: 13, color: 'rgba(15,27,45,0.5)', paddingBottom: 8 }}>
            {weekStart} — {weekEnd.toISOString().slice(0,10)}
          </p>
        </div>
      </Card>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 8, overflowX: 'auto', minWidth: 900 }}>
        {days.map(d => {
          const dayTasks = week[d] || [];
          const doneCount = dayTasks.filter(t => t.done).length;
          return (
            <div key={d} style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div className="card" style={{ padding: '10px 10px', borderTop: '3px solid #E4BB60', minHeight: 200 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                  <span style={{ fontSize: 12, fontWeight: 700, color: '#0F1B2D' }}>{d.slice(0,3)}</span>
                  {dayTasks.length > 0 && <span style={{ fontSize: 10, color: 'rgba(15,27,45,0.4)' }}>{doneCount}/{dayTasks.length}</span>}
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 10 }}>
                  {dayTasks.map(t => (
                    <div key={t.id} style={{ display: 'flex', gap: 4, alignItems: 'flex-start' }}>
                      <Checkbox checked={t.done} onChange={() => setWeek(w => ({ ...w, [d]: w[d].map(x => x.id === t.id ? {...x, done: !x.done} : x) }))} />
                      <span style={{ flex: 1, fontSize: 11, lineHeight: 1.4, textDecoration: t.done ? 'line-through' : 'none', color: t.done ? 'rgba(15,27,45,0.35)' : '#0F1B2D' }}>{t.text}</span>
                      <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#C4503A', padding: 0, opacity: 0.5 }}
                        onClick={() => delTask(d, t.id)}>×</button>
                    </div>
                  ))}
                </div>
                <textarea
                  placeholder="Görev ekle…"
                  value={drafts[d] || ''}
                  onChange={e => setDrafts(dr => ({...dr, [d]: e.target.value}))}
                  onKeyDown={e => { if (e.key === 'Enter' && e.ctrlKey) { e.preventDefault(); addTask(d); }}}
                  style={{ width: '100%', resize: 'none', height: 48, fontSize: 11, padding: '4px 6px', border: '1px solid rgba(15,27,45,0.12)', borderRadius: 6, fontFamily: 'var(--font-body)', background: 'transparent', outline: 'none', color: '#0F1B2D' }}
                />
                <button className="btn btn-ghost btn-sm" style={{ width: '100%', marginTop: 4, fontSize: 11 }} onClick={() => addTask(d)}>+ Ekle</button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

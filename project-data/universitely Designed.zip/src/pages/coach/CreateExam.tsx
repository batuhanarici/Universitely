import { useState } from 'react';
import { Card, Input, Label, FormGroup, Select, Btn, Badge, useToast } from '../../components/ui';
import { examTemplates, exams } from '../../lib/mockData';

type NewExam = { id: string; name: string; templateName: string; type: string; date: string };

export default function CoachCreateExam() {
  const { toast, show } = useToast();
  const [newExams, setNewExams] = useState<NewExam[]>([]);
  const [form, setForm] = useState({ name: '', templateId: '', type: 'TYT', date: new Date().toISOString().slice(0,10) });

  function create(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name || !form.templateId) return;
    const tpl = examTemplates.find(t => t.id === form.templateId);
    setNewExams(l => [...l, { id: Date.now().toString(), name: form.name, templateName: tpl?.name || '', type: form.type, date: form.date }]);
    setForm(f => ({ ...f, name: '' }));
    show('Deneme oluşturuldu ✓');
  }

  const badgeVariant: Record<string, 'gold' | 'teal' | 'gray'> = { TYT: 'gold', AYT: 'teal', Branş: 'gray' };

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {toast}
      <div><h1 className="page-title">Deneme Oluştur</h1></div>

      {examTemplates.length === 0 ? (
        <Card><p style={{ fontSize: 13, color: 'rgba(15,27,45,0.6)' }}>Önce Deneme Şablonu oluşturun.</p></Card>
      ) : (
        <Card>
          <h3 className="section-title" style={{ marginBottom: 16, fontSize: 16 }}>Yeni Deneme</h3>
          <form onSubmit={create} style={{ display: 'grid', gridTemplateColumns: '2fr 2fr 1fr 1fr auto', gap: 10, alignItems: 'flex-end' }}>
            <FormGroup><Label>Deneme Adı *</Label><Input placeholder="TYT Denemesi #4" value={form.name} onChange={e => setForm(f=>({...f,name:e.target.value}))} required /></FormGroup>
            <FormGroup><Label>Şablon *</Label>
              <Select value={form.templateId} onChange={e => setForm(f=>({...f,templateId:e.target.value}))} required>
                <option value="">Şablon seç…</option>
                {examTemplates.map(t => <option key={t.id} value={t.id}>{t.name} · {t.subject}</option>)}
              </Select>
            </FormGroup>
            <FormGroup><Label>Tür</Label><Select value={form.type} onChange={e => setForm(f=>({...f,type:e.target.value}))}><option>TYT</option><option>AYT</option><option>Branş</option></Select></FormGroup>
            <FormGroup><Label>Tarih</Label><Input type="date" value={form.date} onChange={e => setForm(f=>({...f,date:e.target.value}))} /></FormGroup>
            <Btn variant="primary" type="submit" size="sm">Oluştur</Btn>
          </form>
        </Card>
      )}

      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Oluşturulan Denemeler</h3>
        <table className="data-table">
          <thead><tr><th>Ad</th><th>Şablon</th><th>Tür</th><th>Tarih</th></tr></thead>
          <tbody>
            {[...exams, ...newExams].map(e => (
              <tr key={e.id}>
                <td style={{ fontWeight: 500 }}>{e.name}</td>
                <td style={{ fontSize: 12, color: 'rgba(15,27,45,0.6)' }}>{'templateName' in e ? e.templateName : e.subject}</td>
                <td><Badge variant={badgeVariant[e.type] || 'gray'}>{e.type}</Badge></td>
                <td style={{ fontSize: 12, color: 'rgba(15,27,45,0.6)' }}>{e.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

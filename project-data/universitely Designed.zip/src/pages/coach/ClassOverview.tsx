import { Card, EmptyState, Badge } from '../../components/ui';
import { students, subjectPerformance } from '../../lib/mockData';

const classWeakSubjects = subjectPerformance
  .map(s => ({ ...s, weakCount: Math.floor(Math.random() * students.length + 1) }))
  .sort((a, b) => b.weakCount - a.weakCount);

export default function CoachClassOverview() {
  const sorted = [...students].sort((a, b) => b.avgNet - a.avgNet);

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div>
        <h1 className="page-title">Sınıf Genel Durumu</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Nete göre sıralı öğrenci listesi</p>
      </div>

      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Öğrenciler — Nete Göre</h3>
        <table className="data-table">
          <thead><tr><th>#</th><th>Ad</th><th>En Zayıf Konu</th><th>Net</th><th>D</th><th>Y</th><th>B</th></tr></thead>
          <tbody>
            {sorted.map((s, i) => (
              <tr key={s.id}>
                <td style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 700, color: 'rgba(15,27,45,0.25)' }}>{i+1}</td>
                <td>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <div style={{ width: 8, height: 8, borderRadius: '50%', background: s.active ? '#2A9D8F' : '#9A9FA8' }} />
                    <span style={{ fontWeight: 500 }}>{s.name}</span>
                  </div>
                </td>
                <td style={{ fontSize: 12, color: '#C4503A' }}>{s.weakestSubject}</td>
                <td><span className="metric-value" style={{ fontSize: 20, fontWeight: 700 }}>{s.avgNet}</span></td>
                <td className="tabular" style={{ color: '#2A9D8F', fontWeight: 600 }}>{Math.floor(s.avgNet * 1.1)}</td>
                <td className="tabular" style={{ color: '#C4503A', fontWeight: 600 }}>{Math.floor(s.avgNet * 0.15)}</td>
                <td className="tabular" style={{ color: '#9A9FA8', fontWeight: 600 }}>{Math.floor(s.avgNet * 0.05)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Ağırlık Verilmesi Gereken Konular</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {classWeakSubjects.map(s => (
            <div key={s.subject} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '8px 0', borderBottom: '1px solid rgba(15,27,45,0.06)' }}>
              <span style={{ flex: 1, fontSize: 13, fontWeight: 500 }}>{s.subject}</span>
              <div style={{ height: 6, width: 120, background: 'rgba(15,27,45,0.07)', borderRadius: 3, overflow: 'hidden' }}>
                <div style={{ height: '100%', width: `${(s.weakCount / students.length) * 100}%`, background: '#C4503A', borderRadius: 3 }} />
              </div>
              <span style={{ fontSize: 12, color: 'rgba(15,27,45,0.5)', minWidth: 60, textAlign: 'right' }}>{s.weakCount}/{students.length} öğrenci</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

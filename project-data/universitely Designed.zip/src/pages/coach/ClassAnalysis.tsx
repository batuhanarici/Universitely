import { useState } from 'react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts';
import { Card, Badge, Select, Label, FormGroup, ProgressBar } from '../../components/ui';
import { students, exams, subjectPerformance } from '../../lib/mockData';

const tt = { contentStyle: { background: '#0F1B2D', border: 'none', borderRadius: 8, color: '#F4EFE4', fontSize: 12 } };

const colors = ['#E4BB60', '#2A9D8F', '#C4503A', '#9A9FA8', '#0F1B2D'];

const netTrendData = exams.map(e => ({
  name: e.name.split(' ').slice(-1)[0],
  'Arda': e.net - 5 + Math.random() * 10,
  'Zeynep': e.net + 10 + Math.random() * 5,
  'Can': e.net - 15 + Math.random() * 8,
  'Sınıf Ort.': e.net,
}));

const rankData = students.map(s => ({ name: s.name.split(' ')[0], net: s.avgNet })).sort((a,b) => b.net - a.net);

export default function CoachClassAnalysis() {
  const [typeFilter, setTypeFilter] = useState('Tüm');
  const [lessonFilter, setLessonFilter] = useState('');
  const [examFilter, setExamFilter] = useState('');

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div>
        <h1 className="page-title">Sınıf Analizi</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Filtrelenebilir çoklu grafik analizi</p>
      </div>

      {/* Filters */}
      <Card style={{ padding: '14px 20px' }}>
        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-end' }}>
          <FormGroup style={{ minWidth: 120 }}>
            <Label>Tür</Label>
            <Select value={typeFilter} onChange={e => setTypeFilter(e.target.value)}>
              {['Tüm','TYT','AYT','Branş'].map(t => <option key={t}>{t}</option>)}
            </Select>
          </FormGroup>
          <FormGroup style={{ minWidth: 140 }}>
            <Label>Ders</Label>
            <Select value={lessonFilter} onChange={e => setLessonFilter(e.target.value)}>
              <option value="">Tümü</option>
              {['Matematik','Türkçe','Fizik','Kimya','Biyoloji'].map(l => <option key={l}>{l}</option>)}
            </Select>
          </FormGroup>
          <FormGroup style={{ minWidth: 180 }}>
            <Label>Deneme</Label>
            <Select value={examFilter} onChange={e => setExamFilter(e.target.value)}>
              <option value="">Tüm Denemeler</option>
              {exams.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
            </Select>
          </FormGroup>
        </div>
      </Card>

      {/* Net Trend */}
      <Card className="tape-accent">
        <h3 className="section-title" style={{ marginBottom: 16, fontSize: 16 }}>Net Trendi</h3>
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={netTrendData}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(15,27,45,0.06)" />
            <XAxis dataKey="name" tick={{ fontSize: 11, fill: 'rgba(15,27,45,0.4)' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: 'rgba(15,27,45,0.4)' }} axisLine={false} tickLine={false} />
            <Tooltip {...tt} />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            {['Arda','Zeynep','Can','Sınıf Ort.'].map((name, i) => (
              <Line key={name} type="monotone" dataKey={name} stroke={colors[i]} strokeWidth={name === 'Sınıf Ort.' ? 2.5 : 1.5} strokeDasharray={name === 'Sınıf Ort.' ? '5 5' : undefined} dot={false} />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </Card>

      <div className="grid-2">
        {/* Öğrenci sıralama */}
        <Card>
          <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Öğrenci Sıralaması</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {rankData.map((s, i) => (
              <div key={s.name} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 700, color: 'rgba(15,27,45,0.2)', minWidth: 24 }}>{i+1}</span>
                <span style={{ flex: 1, fontSize: 13, fontWeight: 500 }}>{s.name}</span>
                <div style={{ width: 80 }}><ProgressBar pct={(s.net / 120) * 100} color="#E4BB60" /></div>
                <span className="tabular" style={{ fontSize: 14, fontWeight: 700, minWidth: 40 }}>{s.net}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Ders başarı */}
        <Card>
          <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Ders Başarı Analizi</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {subjectPerformance.map(s => (
              <div key={s.subject}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                  <span style={{ fontSize: 12, fontWeight: 500 }}>
                    {s.subject}
                    {s.pct < 55 && <Badge variant="brick" key="b">Zayıf</Badge>}
                  </span>
                  <span className="tabular" style={{ fontSize: 12, fontWeight: 700, color: s.pct < 55 ? '#C4503A' : '#2A9D8F' }}>{s.pct}%</span>
                </div>
                <ProgressBar pct={s.pct} color={s.pct < 55 ? '#C4503A' : '#2A9D8F'} />
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Öğrenci karşılaştırma */}
      <Card>
        <h3 className="section-title" style={{ marginBottom: 16, fontSize: 16 }}>Öğrenci Net Karşılaştırma</h3>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={rankData} barSize={36}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(15,27,45,0.06)" />
            <XAxis dataKey="name" tick={{ fontSize: 11, fill: 'rgba(15,27,45,0.4)' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: 'rgba(15,27,45,0.4)' }} axisLine={false} tickLine={false} />
            <Tooltip {...tt} />
            <Bar dataKey="net" fill="#0F1B2D" radius={[3,3,0,0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>
    </div>
  );
}

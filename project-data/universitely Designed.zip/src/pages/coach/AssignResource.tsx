import { useState } from 'react';
import { Card, Select, Input, Label, FormGroup, Btn, Badge, ProgressBar, useToast } from '../../components/ui';
import { students, resources as initial } from '../../lib/mockData';
import { Icon } from '../../components/Layout';

const types = ['Kitap', 'Soru Bankası', 'Deneme', 'Video'];

export default function CoachAssignResource() {
  const { toast, show } = useToast();
  const [studentId, setStudentId] = useState(students[0].id);
  const [resources, setResources] = useState(initial);
  const [form, setForm] = useState({ name: '', type: 'Kitap', total: '', endDate: '' });

  function assign(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name || !form.total) return;
    setResources(l => [...l, { id: Date.now().toString(), name: form.name, type: form.type, total: +form.total, progress: 0, startDate: new Date().toISOString().slice(0,10), endDate: form.endDate || '2024-03-31' }]);
    setForm({ name: '', type: 'Kitap', total: '', endDate: '' });
    show('Kaynak atandı ✓');
  }

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {toast}
      <div><h1 className="page-title">Kaynak Ata</h1></div>

      <Card style={{ padding: '14px 20px' }}>
        <FormGroup>
          <Label>Öğrenci</Label>
          <Select value={studentId} onChange={e => setStudentId(e.target.value)} style={{ maxWidth: 220 }}>
            {students.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
          </Select>
        </FormGroup>
      </Card>

      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Yeni Kaynak Ata</h3>
        <form onSubmit={assign} style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr auto', gap: 10, alignItems: 'flex-end' }}>
          <FormGroup><Label>Kaynak Adı *</Label><Input placeholder="Palme TYT Matematik" value={form.name} onChange={e => setForm(f=>({...f,name:e.target.value}))} required /></FormGroup>
          <FormGroup><Label>Tür</Label><Select value={form.type} onChange={e => setForm(f=>({...f,type:e.target.value}))}>{types.map(t => <option key={t}>{t}</option>)}</Select></FormGroup>
          <FormGroup><Label>Toplam *</Label><Input type="number" min={1} placeholder="320" value={form.total} onChange={e => setForm(f=>({...f,total:e.target.value}))} required /></FormGroup>
          <FormGroup><Label>Bitiş Hedefi</Label><Input type="date" value={form.endDate} onChange={e => setForm(f=>({...f,endDate:e.target.value}))} /></FormGroup>
          <Btn variant="primary" type="submit" size="sm">Ata</Btn>
        </form>
      </Card>

      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Atanan Kaynaklar</h3>
        {resources.length === 0 ? <p style={{ fontSize: 13, color: 'rgba(15,27,45,0.45)' }}>Kaynak atanmamış.</p> : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {resources.map(r => {
              const p = Math.round((r.progress / r.total) * 100);
              return (
                <div key={r.id} style={{ padding: '10px 0', borderBottom: '1px solid rgba(15,27,45,0.06)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                      <span style={{ fontSize: 13, fontWeight: 500 }}>{r.name}</span>
                      <Badge variant="gray">{r.type}</Badge>
                    </div>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                      <span className="tabular" style={{ fontSize: 13 }}>{r.progress}/{r.total} ({p}%)</span>
                      <button className="btn btn-danger btn-sm" onClick={() => setResources(l => l.filter(x => x.id !== r.id))}><Icon name="trash" size={13} /></button>
                    </div>
                  </div>
                  <ProgressBar pct={p} color="#E4BB60" />
                </div>
              );
            })}
          </div>
        )}
      </Card>
    </div>
  );
}

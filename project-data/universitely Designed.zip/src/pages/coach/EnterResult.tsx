import { useState } from 'react';
import { Card, Select, Label, FormGroup, Btn, Badge, useToast } from '../../components/ui';
import { students, exams, examTemplates } from '../../lib/mockData';

type Answer = 'D' | 'Y' | 'B' | null;
const btnStyle = (val: Answer, cur: Answer, color: string) => ({
  padding: '4px 10px', borderRadius: 6, border: `1.5px solid ${cur === val ? color : 'rgba(15,27,45,0.15)'}`,
  background: cur === val ? `${color}20` : 'transparent', fontFamily: 'var(--font-body)', fontSize: 12,
  fontWeight: 700, color: cur === val ? color : 'rgba(15,27,45,0.5)', cursor: 'pointer',
});

export default function CoachEnterResult() {
  const { toast, show } = useToast();
  const [examId, setExamId] = useState(exams[0].id);
  const [studentId, setStudentId] = useState(students[0].id);
  const [answers, setAnswers] = useState<Record<number, Answer>>({});
  const [saved, setSaved] = useState(false);

  const exam = exams.find(e => e.id === examId);
  const template = examTemplates.find(t => t.id === exam?.templateId);
  const questions = template ? template.ranges.flatMap(r => {
    const qs = [];
    for (let i = r.from; i <= r.to; i++) qs.push({ no: i, topic: r.topic });
    return qs;
  }) : Array.from({ length: 20 }, (_, i) => ({ no: i + 1, topic: 'Genel' }));

  const marked = Object.keys(answers).length;
  const allMarked = marked === questions.length;

  function save() {
    if (!allMarked) return;
    setSaved(true);
    show('Sonuçlar kaydedildi ✓');
  }

  if (saved) return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div><h1 className="page-title">Sonuç Gir</h1></div>
      <Card><p style={{ color: '#2A9D8F', fontWeight: 600, fontSize: 14 }}>✓ Bu öğrencinin bu deneme için sonuçları girildi.</p></Card>
    </div>
  );

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {toast}
      <div><h1 className="page-title">Sonuç Gir</h1></div>

      <Card style={{ padding: '14px 20px' }}>
        <div style={{ display: 'flex', gap: 12 }}>
          <FormGroup style={{ minWidth: 200 }}><Label>Deneme</Label>
            <Select value={examId} onChange={e => { setExamId(e.target.value); setAnswers({}); setSaved(false); }}>
              {exams.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
            </Select>
          </FormGroup>
          <FormGroup style={{ minWidth: 200 }}><Label>Öğrenci</Label>
            <Select value={studentId} onChange={e => setStudentId(e.target.value)}>
              {students.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
          </FormGroup>
        </div>
      </Card>

      <Card>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <h3 className="section-title" style={{ marginBottom: 0, fontSize: 16 }}>Soru Listesi</h3>
          <Badge variant={allMarked ? 'teal' : 'gray'}>{marked}/{questions.length} soru işaretlendi</Badge>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 8 }}>
          {questions.map(q => (
            <div key={q.no} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px', borderRadius: 8, background: 'rgba(15,27,45,0.02)', border: '1px solid rgba(15,27,45,0.07)' }}>
              <span className="tabular" style={{ fontSize: 13, fontWeight: 700, color: 'rgba(15,27,45,0.35)', minWidth: 28 }}>{q.no}</span>
              <span style={{ flex: 1, fontSize: 12, color: 'rgba(15,27,45,0.6)' }}>{q.topic}</span>
              <div style={{ display: 'flex', gap: 4 }}>
                {(['D','Y','B'] as Answer[]).map(v => (
                  <button key={v} style={btnStyle(v, answers[q.no], v === 'D' ? '#2A9D8F' : v === 'Y' ? '#C4503A' : '#9A9FA8')}
                    onClick={() => setAnswers(a => ({ ...a, [q.no]: v }))}>
                    {v}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 16, display: 'flex', justifyContent: 'flex-end' }}>
          <Btn variant="primary" onClick={save} disabled={!allMarked}>
            Kaydet ({marked}/{questions.length} işaretlendi)
          </Btn>
        </div>
      </Card>
    </div>
  );
}

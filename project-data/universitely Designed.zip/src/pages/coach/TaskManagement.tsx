import { useState } from 'react';
import { Card, Select, Input, Label, FormGroup, Btn, Badge, Checkbox, Textarea, useToast } from '../../components/ui';
import { students, tasks as initial } from '../../lib/mockData';
import { Icon } from '../../components/Layout';

export default function CoachTaskManagement() {
  const { toast, show } = useToast();
  const [studentId, setStudentId] = useState(students[0].id);
  const [tasks, setTasks] = useState(initial);
  const [form, setForm] = useState({ desc: '', date: new Date().toISOString().slice(0,10) });
  const [feedbacks, setFeedbacks] = useState<Record<string, string>>({});

  const studentTasks = tasks.filter(t => t.fromCoach);

  function assignTask(e: React.FormEvent) {
    e.preventDefault();
    if (!form.desc) return;
    setTasks(l => [...l, { id: Date.now().toString(), title: form.desc, date: form.date, type: 'coach', done: false, fromCoach: true, coachFeedback: '', approved: false }]);
    setForm(f => ({ ...f, desc: '' }));
    show('Görev atandı ✓');
  }

  function approve(id: string) {
    setTasks(l => l.map(t => t.id === id ? { ...t, approved: true, coachFeedback: feedbacks[id] || '' } : t));
    show('Onaylandı ✓');
  }

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {toast}
      <div><h1 className="page-title">Görev Yönetimi</h1></div>

      <Card style={{ padding: '14px 20px' }}>
        <FormGroup>
          <Label>Öğrenci</Label>
          <Select value={studentId} onChange={e => setStudentId(e.target.value)} style={{ maxWidth: 220 }}>
            {students.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
          </Select>
        </FormGroup>
      </Card>

      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Görev Ata</h3>
        <form onSubmit={assignTask} style={{ display: 'flex', gap: 10, alignItems: 'flex-end' }}>
          <FormGroup style={{ flex: 1 }}><Label>Açıklama *</Label><Input placeholder="Görev açıklaması" value={form.desc} onChange={e => setForm(f=>({...f,desc:e.target.value}))} required /></FormGroup>
          <FormGroup><Label>Tarih</Label><Input type="date" value={form.date} onChange={e => setForm(f=>({...f,date:e.target.value}))} /></FormGroup>
          <Btn variant="primary" type="submit" size="sm">Ata</Btn>
        </form>
      </Card>

      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Görevler & Kontrol</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {studentTasks.map(t => (
            <div key={t.id} className="card-sm" style={{ background: 'rgba(15,27,45,0.02)', borderRadius: 8, border: '1px solid rgba(15,27,45,0.07)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <p style={{ fontSize: 14, fontWeight: 500, marginBottom: 2 }}>{t.title}</p>
                  <p style={{ fontSize: 11, color: 'rgba(15,27,45,0.45)' }}>{t.date} · {t.type}</p>
                </div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <Badge variant={t.approved ? 'teal' : t.done ? 'gold' : 'gray'}>
                    {t.approved ? 'Onaylandı' : t.done ? 'Onay Bekliyor' : 'Bekliyor'}
                  </Badge>
                  <button className="btn btn-danger btn-sm" onClick={() => setTasks(l => l.filter(x => x.id !== t.id))}><Icon name="trash" size={13} /></button>
                </div>
              </div>
              {t.done && !t.approved && (
                <div style={{ marginTop: 10, display: 'flex', gap: 8, alignItems: 'flex-end' }}>
                  <FormGroup style={{ flex: 1 }}>
                    <Label>Geri Bildirim</Label>
                    <Input placeholder="Harika iş! Devam et." value={feedbacks[t.id] || ''} onChange={e => setFeedbacks(f => ({...f, [t.id]: e.target.value}))} />
                  </FormGroup>
                  <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, paddingBottom: 8, cursor: 'pointer' }}>
                    <Checkbox checked={false} onChange={() => approve(t.id)} />
                    Onayla
                  </label>
                </div>
              )}
            </div>
          ))}
          {studentTasks.length === 0 && <p style={{ fontSize: 13, color: 'rgba(15,27,45,0.45)' }}>Bu öğrenciye görev atanmamış.</p>}
        </div>
      </Card>
    </div>
  );
}

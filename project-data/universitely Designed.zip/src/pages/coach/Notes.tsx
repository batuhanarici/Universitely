import { useState } from 'react';
import { Card, Select, Label, FormGroup, Btn, Textarea, Badge, useToast } from '../../components/ui';
import { students, coachNotes as initial } from '../../lib/mockData';
import { Icon } from '../../components/Layout';

export default function CoachNotes() {
  const { toast, show } = useToast();
  const [studentId, setStudentId] = useState(students[0].id);
  const [notes, setNotes] = useState(initial);
  const [form, setForm] = useState({ text: '', importance: 'normal' });

  const studentNotes = notes.filter(n => n.studentId === studentId);
  const importanceVariant: Record<string, 'brick' | 'gold' | 'gray'> = { high: 'brick', normal: 'gold', low: 'gray' };
  const importanceLabel: Record<string, string> = { high: 'Yüksek', normal: 'Normal', low: 'Düşük' };

  function addNote(e: React.FormEvent) {
    e.preventDefault();
    if (!form.text.trim()) return;
    setNotes(l => [...l, { id: Date.now().toString(), studentId, text: form.text, importance: form.importance, createdAt: new Date().toLocaleString('tr-TR') }]);
    setForm(f => ({ ...f, text: '' }));
    show('Not kaydedildi ✓');
  }

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {toast}
      <div><h1 className="page-title">Koç Notları</h1></div>

      <Card style={{ padding: '14px 20px' }}>
        <FormGroup>
          <Label>Öğrenci</Label>
          <Select value={studentId} onChange={e => setStudentId(e.target.value)} style={{ maxWidth: 220 }}>
            {students.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
          </Select>
        </FormGroup>
      </Card>

      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Not Ekle</h3>
        <form onSubmit={addNote} style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <Textarea placeholder="Not içeriği…" value={form.text} onChange={e => setForm(f=>({...f, text: e.target.value}))} required />
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <FormGroup>
              <Label>Önem</Label>
              <Select value={form.importance} onChange={e => setForm(f=>({...f, importance: e.target.value}))} style={{ maxWidth: 140 }}>
                <option value="low">Düşük</option>
                <option value="normal">Normal</option>
                <option value="high">Yüksek</option>
              </Select>
            </FormGroup>
            <Btn variant="primary" type="submit">Kaydet</Btn>
          </div>
        </form>
      </Card>

      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Notlar</h3>
        {studentNotes.length === 0 ? <p style={{ fontSize: 13, color: 'rgba(15,27,45,0.45)' }}>Bu öğrenci için not yok.</p> : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {studentNotes.map(n => (
              <div key={n.id} style={{ display: 'flex', gap: 12, padding: '12px', borderRadius: 8, background: 'rgba(15,27,45,0.02)', border: '1px solid rgba(15,27,45,0.07)', borderLeft: `3px solid ${n.importance === 'high' ? '#C4503A' : n.importance === 'normal' ? '#E4BB60' : '#9A9FA8'}` }}>
                <div style={{ flex: 1 }}>
                  <p style={{ fontSize: 13, lineHeight: 1.6, color: '#0F1B2D' }}>{n.text}</p>
                  <p style={{ fontSize: 11, color: 'rgba(15,27,45,0.4)', marginTop: 4 }}>{n.createdAt}</p>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6, alignItems: 'flex-end' }}>
                  <Badge variant={importanceVariant[n.importance]}>{importanceLabel[n.importance]}</Badge>
                  <button className="btn btn-danger btn-sm" onClick={() => setNotes(l => l.filter(x => x.id !== n.id))}><Icon name="trash" size={13} /></button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

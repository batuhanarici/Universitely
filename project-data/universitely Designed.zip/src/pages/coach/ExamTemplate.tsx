import { useState } from 'react';
import { Card, Input, Label, FormGroup, Select, Btn, Badge, useToast } from '../../components/ui';
import { subjects, examTemplates } from '../../lib/mockData';
import { Icon } from '../../components/Layout';

type Range = { id: string; from: number; to: number; topic: string };

export default function CoachExamTemplate() {
  const { toast, show } = useToast();
  const [templateName, setTemplateName] = useState('');
  const [lesson, setLesson] = useState('Matematik');
  const [ranges, setRanges] = useState<Range[]>([]);
  const [form, setForm] = useState({ from: '', to: '', topic: '' });
  const lessons = [...new Set(subjects.map(s => s.lesson))];

  function addRange(e: React.FormEvent) {
    e.preventDefault();
    if (!form.from || !form.to || !form.topic) return;
    const from = +form.from, to = +form.to;
    setRanges(r => [...r.filter(x => !(x.from <= to && x.to >= from)), { id: Date.now().toString(), from, to, topic: form.topic }].sort((a,b) => a.from - b.from));
    setForm({ from: '', to: '', topic: '' });
  }

  function save() {
    if (!templateName || ranges.length === 0) return;
    show(`Şablon kaydedildi: ${ranges.reduce((a,r) => a + r.to - r.from + 1, 0)} soru ✓`);
    setTemplateName(''); setRanges([]);
  }

  const totalQ = ranges.reduce((a, r) => a + r.to - r.from + 1, 0);

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {toast}
      <div><h1 className="page-title">Deneme Şablonu Oluştur</h1></div>

      <Card>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 12, marginBottom: 16 }}>
          <FormGroup><Label>Şablon Adı *</Label><Input placeholder="TYT Standart Şablon" value={templateName} onChange={e => setTemplateName(e.target.value)} /></FormGroup>
          <FormGroup><Label>Ders</Label><Select value={lesson} onChange={e => setLesson(e.target.value)}>{lessons.map(l => <option key={l}>{l}</option>)}</Select></FormGroup>
        </div>
        <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 10, color: 'rgba(15,27,45,0.6)' }}>Soru Aralığı Ekle</h3>
        <form onSubmit={addRange} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 3fr auto', gap: 10, alignItems: 'flex-end' }}>
          <FormGroup><Label>Başlangıç No *</Label><Input type="number" min={1} placeholder="1" value={form.from} onChange={e => setForm(f=>({...f,from:e.target.value}))} required /></FormGroup>
          <FormGroup><Label>Bitiş No *</Label><Input type="number" min={1} placeholder="40" value={form.to} onChange={e => setForm(f=>({...f,to:e.target.value}))} required /></FormGroup>
          <FormGroup><Label>Konu *</Label><Input placeholder="Türkçe / Paragraf" value={form.topic} onChange={e => setForm(f=>({...f,topic:e.target.value}))} required /></FormGroup>
          <Btn variant="primary" type="submit" size="sm"><Icon name="plus" size={14} /> Ekle</Btn>
        </form>
      </Card>

      {ranges.length > 0 && (
        <Card>
          <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Soru Tablosu ({totalQ} soru)</h3>
          <table className="data-table">
            <thead><tr><th>Başlangıç</th><th>Bitiş</th><th>Soru Sayısı</th><th>Konu</th><th></th></tr></thead>
            <tbody>
              {ranges.map(r => (
                <tr key={r.id}>
                  <td className="tabular">{r.from}</td>
                  <td className="tabular">{r.to}</td>
                  <td className="tabular" style={{ fontWeight: 600 }}>{r.to - r.from + 1}</td>
                  <td style={{ fontWeight: 500 }}>{r.topic}</td>
                  <td><button className="btn btn-danger btn-sm" onClick={() => setRanges(l => l.filter(x => x.id !== r.id))}><Icon name="trash" size={13} /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
          <div style={{ marginTop: 16, display: 'flex', justifyContent: 'flex-end' }}>
            <Btn variant="primary" onClick={save} disabled={!templateName}>Şablonu Kaydet ({totalQ} soru)</Btn>
          </div>
        </Card>
      )}

      {/* Existing templates */}
      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Mevcut Şablonlar</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {examTemplates.map(t => (
            <div key={t.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid rgba(15,27,45,0.06)' }}>
              <span style={{ fontWeight: 500 }}>{t.name}</span>
              <Badge variant="gray">{t.subject}</Badge>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

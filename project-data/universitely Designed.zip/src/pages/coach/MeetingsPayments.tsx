import { useState } from 'react';
import { Card, Select, Label, FormGroup, Btn, Input, Textarea, Badge, Tabs, Checkbox, useToast } from '../../components/ui';
import { students, meetings as initMeetings, payments as initPayments } from '../../lib/mockData';
import { Icon } from '../../components/Layout';

export default function CoachMeetingsPayments() {
  const { toast, show } = useToast();
  const [tab, setTab] = useState('Görüşmeler');
  const [meetings, setMeetings] = useState(initMeetings);
  const [payments, setPayments] = useState(initPayments);
  const [mForm, setMForm] = useState({ studentId: students[0].id, participant: 'Öğrenci', datetime: '', subject: '', note: '' });
  const [pForm, setPForm] = useState({ studentId: students[0].id, amount: '', date: new Date().toISOString().slice(0,10), desc: '' });

  const statusVariant: Record<string, 'gold' | 'teal' | 'brick'> = { planlandı: 'gold', tamamlandı: 'teal', iptal: 'brick' };

  function planMeeting(e: React.FormEvent) {
    e.preventDefault();
    const s = students.find(x => x.id === mForm.studentId)!;
    setMeetings(l => [...l, { id: Date.now().toString(), studentId: mForm.studentId, studentName: s.name, participant: mForm.participant, datetime: mForm.datetime, subject: mForm.subject, note: mForm.note, status: 'planlandı' }]);
    setMForm(f => ({...f, datetime: '', subject: '', note: ''}));
    show('Görüşme planlandı ✓');
  }

  function addPayment(e: React.FormEvent) {
    e.preventDefault();
    const s = students.find(x => x.id === pForm.studentId)!;
    setPayments(l => [...l, { id: Date.now().toString(), studentId: pForm.studentId, studentName: s.name, amount: +pForm.amount, date: pForm.date, desc: pForm.desc, paid: false }]);
    setPForm(f => ({...f, amount: '', desc: ''}));
    show('Ödeme kaydedildi ✓');
  }

  const totalPaid = payments.filter(p => p.paid).reduce((a, p) => a + p.amount, 0);
  const totalAll = payments.reduce((a, p) => a + p.amount, 0);

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {toast}
      <div><h1 className="page-title">Görüşme & Ödeme</h1></div>
      <Tabs tabs={['Görüşmeler', 'Ödemeler']} active={tab} onChange={setTab} />

      {tab === 'Görüşmeler' ? (
        <>
          <Card>
            <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Yeni Görüşme</h3>
            <form onSubmit={planMeeting} style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 2fr 2fr', gap: 10 }}>
              <FormGroup><Label>Öğrenci *</Label>
                <Select value={mForm.studentId} onChange={e => setMForm(f=>({...f,studentId:e.target.value}))}>
                  {students.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </Select>
              </FormGroup>
              <FormGroup><Label>Katılımcı</Label>
                <Select value={mForm.participant} onChange={e => setMForm(f=>({...f,participant:e.target.value}))}>
                  <option>Öğrenci</option><option>Veli</option>
                </Select>
              </FormGroup>
              <FormGroup><Label>Tarih-Saat *</Label>
                <Input type="datetime-local" value={mForm.datetime} onChange={e => setMForm(f=>({...f,datetime:e.target.value}))} required />
              </FormGroup>
              <FormGroup><Label>Konu *</Label>
                <Input placeholder="Görüşme konusu" value={mForm.subject} onChange={e => setMForm(f=>({...f,subject:e.target.value}))} required />
              </FormGroup>
              <FormGroup style={{ gridColumn: '1/-1' }}>
                <Label>Not</Label>
                <Textarea placeholder="Opsiyonel not" value={mForm.note} onChange={e => setMForm(f=>({...f,note:e.target.value}))} style={{ minHeight: 48 }} />
              </FormGroup>
              <div style={{ gridColumn: '1/-1', display: 'flex', justifyContent: 'flex-end' }}>
                <Btn variant="primary" type="submit">Görüşmeyi Planla</Btn>
              </div>
            </form>
          </Card>
          <Card>
            <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Görüşmeler</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {meetings.map(m => (
                <div key={m.id} style={{ display: 'flex', gap: 12, padding: '12px', borderRadius: 8, background: 'rgba(15,27,45,0.02)', border: '1px solid rgba(15,27,45,0.07)' }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', gap: 8, marginBottom: 4 }}>
                      <span style={{ fontWeight: 600, fontSize: 14 }}>{m.studentName}</span>
                      <Badge variant="gray">{m.participant}</Badge>
                      <Badge variant={statusVariant[m.status]}>{m.status}</Badge>
                    </div>
                    <p style={{ fontSize: 13, color: '#0F1B2D' }}>{m.subject}</p>
                    <p style={{ fontSize: 11, color: 'rgba(15,27,45,0.4)' }}>{m.datetime}</p>
                    {m.note && <p style={{ fontSize: 12, color: 'rgba(15,27,45,0.6)', marginTop: 4 }}>{m.note}</p>}
                  </div>
                  <div style={{ display: 'flex', gap: 6, alignItems: 'flex-start' }}>
                    {m.status === 'planlandı' && <>
                      <Btn variant="ghost" size="sm" onClick={() => setMeetings(l => l.map(x => x.id === m.id ? {...x, status: 'tamamlandı'} : x))}>Tamamlandı</Btn>
                      <Btn variant="danger" size="sm" onClick={() => setMeetings(l => l.map(x => x.id === m.id ? {...x, status: 'iptal'} : x))}>İptal</Btn>
                    </>}
                    <button className="btn btn-danger btn-sm" onClick={() => setMeetings(l => l.filter(x => x.id !== m.id))}><Icon name="trash" size={13} /></button>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </>
      ) : (
        <>
          <div className="grid-2">
            <div className="card"><p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(15,27,45,0.4)', marginBottom: 4 }}>Toplam Tahsilat</p><p className="metric-value" style={{ fontSize: 32, fontWeight: 700 }}>₺{totalAll.toLocaleString('tr-TR')}</p></div>
            <div className="card"><p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(15,27,45,0.4)', marginBottom: 4 }}>Ödenen</p><p className="metric-value" style={{ fontSize: 32, fontWeight: 700, color: '#2A9D8F' }}>₺{totalPaid.toLocaleString('tr-TR')}</p></div>
          </div>
          <Card>
            <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Yeni Ödeme</h3>
            <form onSubmit={addPayment} style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 2fr auto', gap: 10, alignItems: 'flex-end' }}>
              <FormGroup><Label>Öğrenci *</Label><Select value={pForm.studentId} onChange={e => setPForm(f=>({...f,studentId:e.target.value}))}>{students.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</Select></FormGroup>
              <FormGroup><Label>Tutar *</Label><Input type="number" min={0} placeholder="1500" value={pForm.amount} onChange={e => setPForm(f=>({...f,amount:e.target.value}))} required /></FormGroup>
              <FormGroup><Label>Tarih</Label><Input type="date" value={pForm.date} onChange={e => setPForm(f=>({...f,date:e.target.value}))} /></FormGroup>
              <FormGroup><Label>Açıklama</Label><Input placeholder="Ocak ayı" value={pForm.desc} onChange={e => setPForm(f=>({...f,desc:e.target.value}))} /></FormGroup>
              <Btn variant="primary" type="submit" size="sm">Kaydet</Btn>
            </form>
          </Card>
          <Card>
            <table className="data-table">
              <thead><tr><th></th><th>Öğrenci</th><th>Tutar</th><th>Tarih</th><th>Açıklama</th><th></th></tr></thead>
              <tbody>
                {payments.map(p => (
                  <tr key={p.id}>
                    <td><Checkbox checked={p.paid} onChange={() => setPayments(l => l.map(x => x.id === p.id ? {...x, paid: !x.paid} : x))} /></td>
                    <td style={{ fontWeight: 500 }}>{p.studentName}</td>
                    <td className="tabular" style={{ fontWeight: 700 }}>₺{p.amount.toLocaleString('tr-TR')}</td>
                    <td style={{ fontSize: 12, color: 'rgba(15,27,45,0.5)' }}>{p.date}</td>
                    <td style={{ fontSize: 12, color: 'rgba(15,27,45,0.6)' }}>{p.desc}</td>
                    <td><button className="btn btn-danger btn-sm" onClick={() => setPayments(l => l.filter(x => x.id !== p.id))}><Icon name="trash" size={13} /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
        </>
      )}
    </div>
  );
}

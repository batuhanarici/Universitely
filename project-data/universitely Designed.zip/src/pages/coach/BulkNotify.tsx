import { useState } from 'react';
import { Card, Btn, Textarea, Label, FormGroup, Checkbox, useToast } from '../../components/ui';
import { students } from '../../lib/mockData';

export default function CoachBulkNotify() {
  const { toast, show } = useToast();
  const [selectedStudents, setSelectedStudents] = useState<Set<string>>(new Set());
  const [selectedParents, setSelectedParents] = useState<Set<string>>(new Set());
  const [message, setMessage] = useState('');

  const studentsWithParents = students.filter(s => s.parentCode);

  function toggleStudent(id: string) {
    setSelectedStudents(s => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  }
  function toggleParent(id: string) {
    setSelectedParents(s => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  }
  function selectAllStudents() { setSelectedStudents(new Set(students.map(s => s.id))); }
  function clearStudents() { setSelectedStudents(new Set()); }
  function selectAllParents() { setSelectedParents(new Set(studentsWithParents.map(s => s.id))); }
  function clearParents() { setSelectedParents(new Set()); }

  const totalSelected = selectedStudents.size + selectedParents.size;

  function send() {
    if (!message.trim() || totalSelected === 0) return;
    show(`${totalSelected}/${totalSelected} alıcıya gönderildi ✓`);
    setMessage('');
    setSelectedStudents(new Set());
    setSelectedParents(new Set());
  }

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {toast}
      <div><h1 className="page-title">Toplu Bildirim</h1></div>

      <div className="grid-2">
        <Card>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <h3 className="section-title" style={{ marginBottom: 0, fontSize: 16 }}>Öğrenciler</h3>
            <div style={{ display: 'flex', gap: 6 }}>
              <Btn variant="ghost" size="sm" onClick={selectAllStudents}>Tümünü Seç</Btn>
              <Btn variant="ghost" size="sm" onClick={clearStudents}>Temizle</Btn>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {students.map(s => (
              <label key={s.id} style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}>
                <Checkbox checked={selectedStudents.has(s.id)} onChange={() => toggleStudent(s.id)} />
                <span style={{ fontSize: 13 }}>{s.name}</span>
              </label>
            ))}
          </div>
        </Card>

        <Card>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <h3 className="section-title" style={{ marginBottom: 0, fontSize: 16 }}>Veliler</h3>
            <div style={{ display: 'flex', gap: 6 }}>
              <Btn variant="ghost" size="sm" onClick={selectAllParents}>Tümünü Seç</Btn>
              <Btn variant="ghost" size="sm" onClick={clearParents}>Temizle</Btn>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {studentsWithParents.map(s => (
              <label key={s.id} style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}>
                <Checkbox checked={selectedParents.has(s.id)} onChange={() => toggleParent(s.id)} />
                <span style={{ fontSize: 13 }}>{s.name} velisi</span>
              </label>
            ))}
            {studentsWithParents.length === 0 && <p style={{ fontSize: 13, color: 'rgba(15,27,45,0.45)' }}>Bağlı veli yok.</p>}
          </div>
        </Card>
      </div>

      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Mesaj</h3>
        <Textarea placeholder="Gönderilecek mesaj…" value={message} onChange={e => setMessage(e.target.value)} style={{ minHeight: 100 }} />
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 12 }}>
          <Btn variant="primary" onClick={send} disabled={!message.trim() || totalSelected === 0}>
            Gönder ({totalSelected} alıcı)
          </Btn>
        </div>
      </Card>
    </div>
  );
}

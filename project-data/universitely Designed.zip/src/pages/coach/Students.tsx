import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, Btn, Input, Label, FormGroup, Badge, StatusDot, useToast } from '../../components/ui';
import { students as initial } from '../../lib/mockData';
import { Icon } from '../../components/Layout';

export default function CoachStudents() {
  const { toast, show } = useToast();
  const navigate = useNavigate();
  const [students, setStudents] = useState(initial);
  const [nameInput, setNameInput] = useState('');
  const [generatedCode, setGeneratedCode] = useState('');

  function generateCode() {
    if (!nameInput.trim()) return;
    const code = 'INV-' + Math.random().toString(36).slice(2, 8).toUpperCase();
    setGeneratedCode(code);
  }

  function copyCode() {
    navigator.clipboard.writeText(generatedCode);
    show('Kod kopyalandı ✓');
  }

  function toggleActive(id: string) {
    setStudents(l => l.map(s => s.id === id ? { ...s, active: !s.active } : s));
  }

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {toast}
      <div><h1 className="page-title">Öğrenciler</h1></div>

      {/* Generate invite code */}
      <Card className="tape-accent">
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Yeni Öğrenci Davet Kodu</h3>
        <div style={{ display: 'flex', gap: 10, alignItems: 'flex-end' }}>
          <FormGroup style={{ flex: 1 }}>
            <Label>Öğrenci Adı Soyadı</Label>
            <Input placeholder="Ad Soyad" value={nameInput} onChange={e => setNameInput(e.target.value)} />
          </FormGroup>
          <Btn variant="primary" onClick={generateCode}>Kod Üret</Btn>
        </div>
        {generatedCode && (
          <div className="anim-slide" style={{ marginTop: 16, display: 'flex', alignItems: 'center', gap: 12, padding: '12px 16px', background: 'rgba(228,187,96,0.1)', borderRadius: 8, border: '1.5px solid rgba(228,187,96,0.3)' }}>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 22, fontWeight: 700, color: '#0F1B2D', letterSpacing: '0.1em' }}>{generatedCode}</span>
            <Btn variant="ghost" size="sm" onClick={copyCode}><Icon name="copy" size={14} /> Kopyala</Btn>
          </div>
        )}
        {generatedCode && (
          <p style={{ fontSize: 12, color: 'rgba(15,27,45,0.5)', marginTop: 8 }}>Bu kodu öğrenciye ilet. Öğrenci kayıt sırasında kullanacak.</p>
        )}
      </Card>

      {/* Student list */}
      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Öğrenci Listesi</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
          {students.map(s => (
            <div key={s.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 0', borderBottom: '1px solid rgba(15,27,45,0.06)' }}>
              <button onClick={() => toggleActive(s.id)} title="Aktif/Pasif değiştir" style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 2 }}>
                <StatusDot active={s.active} />
              </button>
              <span style={{ flex: 1, fontSize: 14, fontWeight: 500 }}>{s.name}</span>
              <Badge variant={s.active ? 'teal' : 'gray'}>{s.active ? 'Aktif' : 'Pasif'}</Badge>
              {s.parentCode && (
                <span style={{ fontSize: 11, color: 'rgba(15,27,45,0.4)', fontFamily: 'var(--font-mono)' }}>{s.parentCode}</span>
              )}
              <Btn variant="ghost" size="sm" onClick={() => navigate('/coach/students')}>
                <Icon name="user" size={13} /> Detay
              </Btn>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

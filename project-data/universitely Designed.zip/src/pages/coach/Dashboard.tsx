import { useNavigate } from 'react-router-dom';
import { Card, KPICard, Badge, ProgressBar, AnimatedNumber } from '../../components/ui';
import { students, riskScores, meetings, tasks, exams } from '../../lib/mockData';
import { Icon } from '../../components/Layout';

export default function CoachDashboard() {
  const navigate = useNavigate();
  const active = students.filter(s => s.active).length;
  const passive = students.filter(s => !s.active).length;
  const pendingTasks = tasks.filter(t => !t.done).length;

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div>
        <h1 className="page-title">Koç Paneli</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>28 Ocak 2024 · Sınıfına genel bakış</p>
      </div>

      <div className="grid-4">
        <KPICard label="Toplam Öğrenci" value={students.length} />
        <KPICard label="Aktif" value={active} color="#2A9D8F" />
        <KPICard label="Pasif" value={passive} color="#9A9FA8" />
        <KPICard label="Bekleyen Görev" value={pendingTasks} color="#C4503A" />
      </div>

      <div className="grid-2">
        {/* Riskli öğrenciler */}
        <Card className="tape-accent">
          <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Riskli Öğrenciler</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {riskScores.slice(0,5).map(r => (
              <div key={r.studentId} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{ width: 8, height: 8, borderRadius: '50%', background: r.level === 'yüksek' ? '#C4503A' : r.level === 'orta' ? '#E4BB60' : '#2A9D8F', flexShrink: 0 }} />
                <span style={{ flex: 1, fontSize: 13, fontWeight: 500 }}>{r.studentName}</span>
                <div style={{ width: 80 }}><ProgressBar pct={r.score} color={r.level === 'yüksek' ? '#C4503A' : r.level === 'orta' ? '#E4BB60' : '#2A9D8F'} /></div>
                <Badge variant={r.level === 'yüksek' ? 'brick' : r.level === 'orta' ? 'gold' : 'teal'}>{r.level}</Badge>
                <button className="btn btn-ghost btn-sm" onClick={() => navigate('/coach/risk')}><Icon name="arrow_back" size={12} /></button>
              </div>
            ))}
          </div>
        </Card>

        {/* Öğrenciler */}
        <Card>
          <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Öğrencilerim</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {students.map(s => (
              <div key={s.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0', borderBottom: '1px solid rgba(15,27,45,0.06)' }}>
                <div style={{ width: 8, height: 8, borderRadius: '50%', background: s.active ? '#2A9D8F' : '#9A9FA8', flexShrink: 0 }} />
                <span style={{ flex: 1, fontSize: 13, fontWeight: 500 }}>{s.name}</span>
                <span className="tabular" style={{ fontSize: 13, fontWeight: 700 }}>{s.avgNet}</span>
                <button className="btn btn-ghost btn-sm" onClick={() => navigate('/coach/students')}><Icon name="user" size={12} /></button>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="grid-2">
        {/* Yaklaşan görüşmeler */}
        <Card>
          <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Yaklaşan Görüşmeler</h3>
          {meetings.filter(m => m.status === 'planlandı').length === 0 ? (
            <p style={{ fontSize: 13, color: 'rgba(15,27,45,0.45)' }}>Planlanmış görüşme yok.</p>
          ) : meetings.filter(m => m.status === 'planlandı').map(m => (
            <div key={m.id} style={{ display: 'flex', gap: 12, padding: '8px 0', borderBottom: '1px solid rgba(15,27,45,0.06)' }}>
              <div style={{ flex: 1 }}>
                <p style={{ fontSize: 13, fontWeight: 500 }}>{m.studentName}</p>
                <p style={{ fontSize: 11, color: 'rgba(15,27,45,0.5)' }}>{m.participant} · {m.datetime}</p>
              </div>
              <Badge variant="gold">Planlandı</Badge>
            </div>
          ))}
        </Card>

        {/* Bugünkü görevler */}
        <Card>
          <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Bugünün Görevleri</h3>
          {tasks.filter(t => t.fromCoach).map(t => (
            <div key={t.id} style={{ display: 'flex', gap: 10, padding: '8px 0', borderBottom: '1px solid rgba(15,27,45,0.06)' }}>
              <span style={{ flex: 1, fontSize: 13 }}>{t.title}</span>
              <Badge variant={t.done ? 'teal' : 'gray'}>{t.done ? 'Tamamlandı' : 'Bekliyor'}</Badge>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

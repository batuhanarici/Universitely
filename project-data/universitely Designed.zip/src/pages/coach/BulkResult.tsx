import { useState } from 'react';
import { Card, Select, Label, FormGroup, Btn, Tabs, Textarea, useToast } from '../../components/ui';
import { exams, students } from '../../lib/mockData';

type Cell = 'D' | 'Y' | 'B' | null;
const COLORS: Record<string, string> = { D: '#2A9D8F', Y: '#C4503A', B: '#9A9FA8' };

export default function CoachBulkResult() {
  const { toast, show } = useToast();
  const [examId, setExamId] = useState(exams[0].id);
  const [mode, setMode] = useState('Sınıf Grid');
  const [qCount, setQCount] = useState(20);
  const [grid, setGrid] = useState<Record<string, Cell[]>>(() => {
    const g: Record<string, Cell[]> = {};
    students.forEach(s => { g[s.id] = Array(qCount).fill(null); });
    return g;
  });
  const [pasteText, setPasteText] = useState('');
  const [errors, setErrors] = useState<string[]>([]);

  function cycleCell(studentId: string, qIdx: number) {
    setGrid(g => {
      const row = [...g[studentId]];
      const cur = row[qIdx];
      row[qIdx] = cur === null ? 'D' : cur === 'D' ? 'Y' : cur === 'Y' ? 'B' : null;
      return { ...g, [studentId]: row };
    });
  }

  function clearRow(studentId: string) {
    setGrid(g => ({ ...g, [studentId]: Array(qCount).fill(null) }));
  }

  function parseAndImport() {
    const lines = pasteText.trim().split('\n');
    const errs: string[] = [];
    lines.forEach(line => {
      const [name, answers] = line.split(';').map(x => x.trim());
      if (!name || !answers) { errs.push(`Geçersiz satır: "${line}"`); return; }
      const student = students.find(s => s.name.toLowerCase() === name.toLowerCase());
      if (!student) { errs.push(`Öğrenci bulunamadı: "${name}"`); return; }
      const cells: Cell[] = answers.split('').map(c => c === 'D' ? 'D' : c === 'Y' ? 'Y' : c === 'B' ? 'B' : null);
      setGrid(g => ({ ...g, [student.id]: cells }));
    });
    setErrors(errs);
    if (errs.length === 0) show(`${lines.length} öğrenci aktarıldı ✓`);
  }

  function save() {
    const filled = students.filter(s => grid[s.id]?.some(c => c !== null));
    const missing = students.filter(s => !filled.find(f => f.id === s.id));
    show(`${filled.length} öğrenci kaydedildi${missing.length > 0 ? ` · ${missing.length} eksik` : ''} ✓`);
  }

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {toast}
      <div><h1 className="page-title">Toplu Sonuç Gir</h1></div>

      <Card style={{ padding: '14px 20px' }}>
        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-end', flexWrap: 'wrap' }}>
          <FormGroup style={{ minWidth: 200 }}><Label>Deneme</Label>
            <Select value={examId} onChange={e => setExamId(e.target.value)}>
              {exams.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
            </Select>
          </FormGroup>
          <FormGroup style={{ minWidth: 100 }}><Label>Soru Sayısı</Label>
            <input type="number" min={1} max={160} value={qCount} onChange={e => setQCount(+e.target.value)} className="input" style={{ width: 100 }} />
          </FormGroup>
        </div>
      </Card>

      <Card>
        <Tabs tabs={['Sınıf Grid', 'Kopyala-Yapıştır']} active={mode} onChange={setMode} />
        <div style={{ marginTop: 16 }}>
          {mode === 'Sınıf Grid' ? (
            <div style={{ overflowX: 'auto' }}>
              <table style={{ borderCollapse: 'collapse', minWidth: Math.max(600, qCount * 28 + 200) }}>
                <thead>
                  <tr>
                    <th style={{ fontSize: 11, color: 'rgba(15,27,45,0.4)', fontWeight: 700, textAlign: 'left', padding: '6px 12px', position: 'sticky', left: 0, background: '#FDFBF7' }}>Öğrenci</th>
                    {Array.from({ length: qCount }, (_, i) => (
                      <th key={i} style={{ fontSize: 10, color: 'rgba(15,27,45,0.35)', fontWeight: 700, padding: '6px 4px', minWidth: 24, textAlign: 'center' }}>{i+1}</th>
                    ))}
                    <th style={{ fontSize: 11, color: 'rgba(15,27,45,0.4)', fontWeight: 700, padding: '6px 8px' }}>Dolu</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {students.map(s => {
                    const row = grid[s.id] || [];
                    const filled = row.filter(c => c !== null).length;
                    return (
                      <tr key={s.id}>
                        <td style={{ fontSize: 13, fontWeight: 500, padding: '6px 12px', whiteSpace: 'nowrap', position: 'sticky', left: 0, background: '#FDFBF7', borderBottom: '1px solid rgba(15,27,45,0.06)' }}>{s.name}</td>
                        {Array.from({ length: qCount }, (_, i) => (
                          <td key={i} style={{ padding: '3px 2px', borderBottom: '1px solid rgba(15,27,45,0.06)' }}>
                            <div
                              onClick={() => cycleCell(s.id, i)}
                              style={{
                                width: 20, height: 20, borderRadius: 4, cursor: 'pointer',
                                background: row[i] ? `${COLORS[row[i]!]}20` : 'rgba(15,27,45,0.04)',
                                border: `1px solid ${row[i] ? COLORS[row[i]!] : 'rgba(15,27,45,0.12)'}`,
                                display: 'flex', alignItems: 'center', justifyContent: 'center',
                                fontSize: 9, fontWeight: 700, color: COLORS[row[i]!] || 'rgba(15,27,45,0.2)',
                              }}
                            >{row[i] || ''}</div>
                          </td>
                        ))}
                        <td style={{ padding: '6px 8px', fontSize: 12, fontWeight: 600, color: 'rgba(15,27,45,0.5)', borderBottom: '1px solid rgba(15,27,45,0.06)' }}>{filled}/{qCount}</td>
                        <td style={{ borderBottom: '1px solid rgba(15,27,45,0.06)' }}>
                          <button className="btn btn-ghost btn-sm" style={{ fontSize: 11 }} onClick={() => clearRow(s.id)}>Temizle</button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <p style={{ fontSize: 13, color: 'rgba(15,27,45,0.6)' }}>Her satır: <code style={{ background: 'rgba(15,27,45,0.07)', padding: '2px 6px', borderRadius: 4 }}>Ad Soyad;DDYYBDD…</code></p>
              <Textarea
                placeholder={'Arda Kaya;DDDYYBBDDY\nZeynep Yıldız;DDBDYDDDBD'}
                value={pasteText} onChange={e => setPasteText(e.target.value)}
                style={{ minHeight: 160, fontFamily: 'var(--font-mono)', fontSize: 12 }}
              />
              <Btn variant="ghost" onClick={parseAndImport}>Grid\'e Aktar</Btn>
              {errors.length > 0 && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                  {errors.map((e, i) => <p key={i} style={{ fontSize: 12, color: '#C4503A' }}>{e}</p>)}
                </div>
              )}
            </div>
          )}
          <div style={{ marginTop: 16, display: 'flex', justifyContent: 'flex-end' }}>
            <Btn variant="primary" onClick={save}>Kaydet</Btn>
          </div>
        </div>
      </Card>
    </div>
  );
}

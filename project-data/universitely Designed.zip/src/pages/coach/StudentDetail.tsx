import { useNavigate } from 'react-router-dom';
import { Card, KPICard, Badge, ProgressBar, Btn } from '../../components/ui';
import { students, exams, tasks, resources, wrongQuestions, studySessions } from '../../lib/mockData';
import { Icon } from '../../components/Layout';

const student = students[0];

export default function CoachStudentDetail() {
  const navigate = useNavigate();
  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <Btn variant="ghost" size="sm" onClick={() => navigate('/coach/students')}><Icon name="arrow_back" size={14} /> Geri</Btn>
        <h1 className="page-title" style={{ marginBottom: 0 }}>{student.name}</h1>
        <Badge variant={student.active ? 'teal' : 'gray'}>{student.active ? 'Aktif' : 'Pasif'}</Badge>
      </div>

      <div className="grid-4">
        <KPICard label="Son Net" value={exams[exams.length-1].net} decimals={2} color="#E4BB60" />
        <KPICard label="Toplam Çalışma" value={31} sub="saat" />
        <KPICard label="Bekleyen Görev" value={tasks.filter(t=>!t.done).length} color="#C4503A" />
        <KPICard label="Çözülmemiş Yanlış" value={wrongQuestions.filter(w=>!w.solved).length} color="#C4503A" />
      </div>

      <div className="grid-2">
        <Card>
          <h3 className="section-title" style={{ marginBottom: 12, fontSize: 16 }}>Deneme Netleri (Son 8)</h3>
          <table className="data-table">
            <thead><tr><th>Deneme</th><th>Tarih</th><th>D/Y</th><th>Net</th></tr></thead>
            <tbody>
              {exams.map(e => (
                <tr key={e.id}>
                  <td style={{ fontSize: 12 }}>{e.name}</td>
                  <td style={{ fontSize: 12, color: 'rgba(15,27,45,0.5)' }}>{e.date}</td>
                  <td className="tabular" style={{ fontSize: 12 }}>{e.correct}/{e.wrong}</td>
                  <td><span className="metric-value" style={{ fontSize: 16, fontWeight: 700 }}>{e.net}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <Card>
            <h3 className="section-title" style={{ marginBottom: 12, fontSize: 16 }}>Son Görevler</h3>
            {tasks.slice(0,6).map(t => (
              <div key={t.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '7px 0', borderBottom: '1px solid rgba(15,27,45,0.06)' }}>
                <span style={{ fontSize: 12 }}>{t.title}</span>
                <Badge variant={t.done ? 'teal' : 'gray'}>{t.done ? 'Tamam' : 'Bekliyor'}</Badge>
              </div>
            ))}
          </Card>

          <Card>
            <h3 className="section-title" style={{ marginBottom: 12, fontSize: 16 }}>HEDEF</h3>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              <Badge variant="ink">🏛 İTÜ</Badge>
              <Badge variant="ink">📐 Bilgisayar</Badge>
              <Badge variant="gold">🎯 110 net</Badge>
            </div>
          </Card>
        </div>
      </div>

      <div className="grid-2">
        <Card>
          <h3 className="section-title" style={{ marginBottom: 12, fontSize: 16 }}>Kaynaklar</h3>
          {resources.slice(0,5).map(r => (
            <div key={r.id} style={{ padding: '8px 0', borderBottom: '1px solid rgba(15,27,45,0.06)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span style={{ fontSize: 12, fontWeight: 500 }}>{r.name}</span>
                <span className="tabular" style={{ fontSize: 12 }}>{r.progress}/{r.total}</span>
              </div>
              <ProgressBar pct={Math.round((r.progress/r.total)*100)} color="#E4BB60" />
            </div>
          ))}
        </Card>

        <Card>
          <h3 className="section-title" style={{ marginBottom: 12, fontSize: 16 }}>Son Çalışmalar</h3>
          {studySessions.slice(0,5).map(s => (
            <div key={s.id} style={{ display: 'flex', gap: 10, padding: '8px 0', borderBottom: '1px solid rgba(15,27,45,0.06)' }}>
              <div style={{ flex: 1 }}>
                <p style={{ fontSize: 12, fontWeight: 500 }}>{s.note || s.subject || '—'}</p>
                <p style={{ fontSize: 11, color: 'rgba(15,27,45,0.45)' }}>{s.date}</p>
              </div>
              <span className="tabular" style={{ fontSize: 13, fontWeight: 700 }}>{s.duration} dk</span>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

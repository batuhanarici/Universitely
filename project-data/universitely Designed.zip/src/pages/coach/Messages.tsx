import { useState, useRef, useEffect } from 'react';
import { Card, Select, Label, FormGroup, Btn, Input } from '../../components/ui';
import { students, messages as initial } from '../../lib/mockData';

export default function CoachMessages() {
  const [recipientType, setRecipientType] = useState('student');
  const [recipientId, setRecipientId] = useState(students[0].id);
  const [msgs, setMsgs] = useState(initial);
  const [text, setText] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [msgs]);

  function send(e: React.FormEvent) {
    e.preventDefault();
    if (!text.trim()) return;
    setMsgs(m => [...m, { id: Date.now().toString(), from: 'coach', text: text.trim(), time: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }), read: true }]);
    setText('');
  }

  const recipient = students.find(s => s.id === recipientId);

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div><h1 className="page-title">Mesajlar</h1></div>

      <Card style={{ padding: '14px 20px' }}>
        <div style={{ display: 'flex', gap: 12 }}>
          <FormGroup>
            <Label>Alıcı Tipi</Label>
            <Select value={recipientType} onChange={e => setRecipientType(e.target.value)} style={{ maxWidth: 160 }}>
              <option value="student">🎓 Öğrenci</option>
              <option value="parent">👪 Veli</option>
            </Select>
          </FormGroup>
          <FormGroup style={{ flex: 1 }}>
            <Label>Kişi</Label>
            <Select value={recipientId} onChange={e => setRecipientId(e.target.value)} style={{ maxWidth: 220 }}>
              {students.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
          </FormGroup>
        </div>
      </Card>

      <Card style={{ display: 'flex', flexDirection: 'column', height: 460 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14, paddingBottom: 12, borderBottom: '1px solid rgba(15,27,45,0.08)' }}>
          <div style={{ width: 36, height: 36, borderRadius: '50%', background: '#2A9D8F', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700 }}>{recipient?.name[0]}</div>
          <p style={{ fontSize: 14, fontWeight: 600 }}>{recipient?.name}</p>
        </div>
        <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 10 }}>
          {msgs.map(m => (
            <div key={m.id} style={{ display: 'flex', flexDirection: m.from === 'coach' ? 'row-reverse' : 'row', alignItems: 'flex-end', gap: 8 }}>
              <div>
                <div className={m.from === 'coach' ? 'bubble-self' : 'bubble-other'}>{m.text}</div>
                <p style={{ fontSize: 10, color: 'rgba(15,27,45,0.35)', marginTop: 2, textAlign: m.from === 'coach' ? 'right' : 'left' }}>{m.time}</p>
              </div>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>
        <form onSubmit={send} style={{ display: 'flex', gap: 8, marginTop: 12, paddingTop: 12, borderTop: '1px solid rgba(15,27,45,0.08)' }}>
          <Input placeholder="Mesaj yaz…" value={text} onChange={e => setText(e.target.value)} style={{ flex: 1 }}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(e as any); }}} />
          <Btn variant="primary" type="submit">Gönder</Btn>
        </form>
      </Card>
    </div>
  );
}

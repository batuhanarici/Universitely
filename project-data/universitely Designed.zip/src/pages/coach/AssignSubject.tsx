import { useState } from 'react';
import { Card, Select, Label, FormGroup, Btn, Badge, useToast } from '../../components/ui';
import { students, subjects } from '../../lib/mockData';
import { Icon } from '../../components/Layout';

const lessons = [...new Set(subjects.map(s => s.lesson))];

export default function CoachAssignSubject() {
  const { toast, show } = useToast();
  const [studentId, setStudentId] = useState(students[0].id);
  const [lesson, setLesson] = useState(lessons[0]);
  const [subjectId, setSubjectId] = useState('');
  const [assigned, setAssigned] = useState<typeof subjects>([]);

  const lessonSubjects = subjects.filter(s => s.lesson === lesson);

  function assign() {
    const sub = subjects.find(s => s.id === subjectId);
    if (!sub || assigned.find(a => a.id === subjectId)) return;
    setAssigned(l => [...l, sub]);
    show('Konu atandı ✓');
  }

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {toast}
      <div><h1 className="page-title">Konu Ata</h1></div>

      <Card style={{ padding: '14px 20px' }}>
        <FormGroup>
          <Label>Öğrenci</Label>
          <Select value={studentId} onChange={e => setStudentId(e.target.value)} style={{ maxWidth: 220 }}>
            {students.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
          </Select>
        </FormGroup>
      </Card>

      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Konu Ata</h3>
        <div style={{ display: 'flex', gap: 10, alignItems: 'flex-end' }}>
          <FormGroup style={{ minWidth: 160 }}><Label>Ders</Label>
            <Select value={lesson} onChange={e => { setLesson(e.target.value); setSubjectId(''); }}>
              {lessons.map(l => <option key={l}>{l}</option>)}
            </Select>
          </FormGroup>
          <FormGroup style={{ flex: 1 }}><Label>Konu</Label>
            <Select value={subjectId} onChange={e => setSubjectId(e.target.value)}>
              <option value="">Konu seç…</option>
              {lessonSubjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
          </FormGroup>
          <Btn variant="primary" onClick={assign} disabled={!subjectId}>Ata</Btn>
        </div>
        {lessonSubjects.length === 0 && <p style={{ fontSize: 12, color: 'rgba(15,27,45,0.45)', marginTop: 8 }}>Bu ders için Ders/Konu yönetiminden konu ekleyin.</p>}
      </Card>

      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Atanan Konular</h3>
        {assigned.length === 0 ? <p style={{ fontSize: 13, color: 'rgba(15,27,45,0.45)' }}>Konu atanmamış.</p> : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
            {assigned.map(s => (
              <div key={s.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: '1px solid rgba(15,27,45,0.06)' }}>
                <span style={{ flex: 1, fontSize: 13, fontWeight: 500 }}>{s.name}</span>
                <Badge variant="gray">{s.lesson}</Badge>
                <Badge variant={s.done ? 'teal' : 'gray'}>{s.done ? '✓ Tamamlandı' : 'Çalışılıyor'}</Badge>
                <button className="btn btn-danger btn-sm" onClick={() => setAssigned(l => l.filter(x => x.id !== s.id))}><Icon name="trash" size={13} /></button>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

import { useState } from 'react';
import { Card, KPICard, Badge, Btn, Input, Label, FormGroup, Select, Checkbox, useToast } from '../../components/ui';
import { payments as initial, students } from '../../lib/mockData';
import { formatDate } from '../../lib/utils';
import { Icon } from '../../components/Layout';

const filters = ['Hepsi', 'Ödendi', 'Bekleniyor', 'Gecikti'];

export default function CoachAccounting() {
  const { toast, show } = useToast();
  const [payments, setPayments] = useState(initial);
  const [filter, setFilter] = useState('Hepsi');
  const [form, setForm] = useState({ studentId: '', amount: '', date: new Date().toISOString().slice(0,10), desc: '' });

  const today = '2024-01-28';
  const total = payments.reduce((a, p) => a + p.amount, 0);
  const paid = payments.filter(p => p.paid).reduce((a, p) => a + p.amount, 0);
  const late = payments.filter(p => !p.paid && p.date < today).reduce((a, p) => a + p.amount, 0);
  const pending = payments.filter(p => !p.paid && p.date >= today).reduce((a, p) => a + p.amount, 0);

  function getStatus(p: typeof payments[0]) {
    if (p.paid) return 'Ödendi';
    if (p.date < today) return 'Gecikti';
    return 'Bekleniyor';
  }

  const filtered = payments.filter(p => {
    if (filter === 'Hepsi') return true;
    return getStatus(p) === filter;
  });

  function addPayment(e: React.FormEvent) {
    e.preventDefault();
    const student = students.find(s => s.id === form.studentId);
    if (!student || !form.amount) return;
    setPayments(l => [...l, { id: Date.now().toString(), studentId: form.studentId, studentName: student.name, amount: +form.amount, date: form.date, desc: form.desc, paid: false }]);
    setForm({ studentId: '', amount: '', date: new Date().toISOString().slice(0,10), desc: '' });
    show('Ödeme kaydedildi ✓');
  }

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {toast}
      <div><h1 className="page-title">Muhasebe</h1></div>

      <div className="grid-4">
        <KPICard label="Toplam Tahsilat" value={total} sub="₺" />
        <KPICard label="Ödenen" value={paid} sub="₺" color="#2A9D8F" />
        <KPICard label="Bekleniyor" value={pending} sub="₺" color="#E4BB60" />
        <KPICard label="Gecikmiş" value={late} sub="₺" color="#C4503A" />
      </div>

      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Yeni Ödeme</h3>
        <form onSubmit={addPayment} style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 2fr auto', gap: 10, alignItems: 'flex-end' }}>
          <FormGroup><Label>Öğrenci *</Label>
            <Select value={form.studentId} onChange={e => setForm(f=>({...f,studentId:e.target.value}))} required>
              <option value="">Seç…</option>{students.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
          </FormGroup>
          <FormGroup><Label>Tutar (₺) *</Label><Input type="number" min={0} placeholder="1500" value={form.amount} onChange={e => setForm(f=>({...f,amount:e.target.value}))} required /></FormGroup>
          <FormGroup><Label>Tarih</Label><Input type="date" value={form.date} onChange={e => setForm(f=>({...f,date:e.target.value}))} /></FormGroup>
          <FormGroup><Label>Açıklama</Label><Input placeholder="Ocak ayı ücreti" value={form.desc} onChange={e => setForm(f=>({...f,desc:e.target.value}))} /></FormGroup>
          <Btn variant="primary" type="submit" size="sm">Kaydet</Btn>
        </form>
      </Card>

      <Card>
        <div style={{ display: 'flex', gap: 8, marginBottom: 14, flexWrap: 'wrap' }}>
          {filters.map(f => (
            <button key={f} onClick={() => setFilter(f)}
              style={{ padding: '5px 12px', borderRadius: 8, border: filter === f ? '1.5px solid #E4BB60' : '1.5px solid rgba(15,27,45,0.15)', background: filter === f ? 'rgba(228,187,96,0.12)' : 'transparent', fontFamily: 'var(--font-body)', fontSize: 12, fontWeight: 600, color: filter === f ? '#A07C20' : '#0F1B2D', cursor: 'pointer' }}>
              {f}
            </button>
          ))}
        </div>
        <table className="data-table">
          <thead><tr><th></th><th>Öğrenci</th><th>Tutar</th><th>Tarih</th><th>Açıklama</th><th>Durum</th><th></th></tr></thead>
          <tbody>
            {filtered.map(p => {
              const status = getStatus(p);
              return (
                <tr key={p.id}>
                  <td><Checkbox checked={p.paid} onChange={() => setPayments(l => l.map(x => x.id === p.id ? {...x, paid: !x.paid} : x))} /></td>
                  <td style={{ fontWeight: 500 }}>{p.studentName}</td>
                  <td className="tabular" style={{ fontWeight: 700 }}>₺{p.amount.toLocaleString('tr-TR')}</td>
                  <td style={{ fontSize: 12, color: 'rgba(15,27,45,0.5)' }}>{formatDate(p.date)}</td>
                  <td style={{ fontSize: 12, color: 'rgba(15,27,45,0.6)' }}>{p.desc}</td>
                  <td><Badge variant={status === 'Ödendi' ? 'teal' : status === 'Gecikti' ? 'brick' : 'gold'}>{status}</Badge></td>
                  <td><button className="btn btn-danger btn-sm" onClick={() => setPayments(l => l.filter(x => x.id !== p.id))}><Icon name="trash" size={13} /></button></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

import { Card, Badge } from '../../components/ui';
import { tasks, meetings, weeklyStudyData } from '../../lib/mockData';

const days7 = Array.from({ length: 7 }, (_, i) => {
  const d = new Date('2024-01-22');
  d.setDate(d.getDate() + i);
  return { date: d.toISOString().slice(0,10), label: d.toLocaleDateString('tr-TR', { weekday: 'short', day: 'numeric', month: 'short' }) };
});

export default function ParentCalendar() {
  const futureMeetings = meetings.filter(m => m.status === 'planlandı');

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div>
        <h1 className="page-title">Takvim</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Haftalık plan ve görüşme tarihleri</p>
      </div>

      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Haftalık Plan</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
          {days7.map((day, i) => {
            const dayTasks = tasks.filter(t => t.date === day.date);
            const study = weeklyStudyData[i];
            return (
              <div key={day.date} style={{ display: 'flex', gap: 16, padding: '12px 0', borderBottom: '1px solid rgba(15,27,45,0.06)', alignItems: 'flex-start' }}>
                <div style={{ minWidth: 90 }}>
                  <p style={{ fontSize: 12, fontWeight: 700, color: '#0F1B2D' }}>{day.label}</p>
                  <p style={{ fontSize: 11, color: 'rgba(15,27,45,0.45)' }}>{study.minutes} dk · {study.questions} soru</p>
                </div>
                <div style={{ flex: 1, display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                  {dayTasks.length === 0 ? (
                    <span style={{ fontSize: 12, color: 'rgba(15,27,45,0.35)', fontStyle: 'italic' }}>Görev yok</span>
                  ) : dayTasks.map(t => (
                    <Badge key={t.id} variant={t.done ? 'teal' : 'gray'}>{t.title.slice(0,30)}{t.title.length > 30 ? '…' : ''}</Badge>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Görüşme Tarihleri</h3>
        {futureMeetings.length === 0 ? (
          <p style={{ fontSize: 13, color: 'rgba(15,27,45,0.45)' }}>Planlanmış görüşme yok.</p>
        ) : futureMeetings.map(m => (
          <div key={m.id} style={{ display: 'flex', gap: 12, padding: '10px 0', borderBottom: '1px solid rgba(15,27,45,0.06)' }}>
            <div style={{ flex: 1 }}>
              <p style={{ fontSize: 13, fontWeight: 600 }}>{m.subject}</p>
              <p style={{ fontSize: 11, color: 'rgba(15,27,45,0.5)' }}>{m.datetime}</p>
            </div>
            <Badge variant="gray">{m.participant}</Badge>
            <Badge variant="gold">Planlandı</Badge>
          </div>
        ))}
      </Card>
    </div>
  );
}

import { Card, EmptyState } from '../../components/ui';
import { notifications_parent } from '../../lib/mockData';

export default function ParentNotifications() {
  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div>
        <h1 className="page-title">Bildirimler</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Çocuğunuzla ilgili hatırlatmalar</p>
      </div>

      {notifications_parent.length === 0 ? (
        <Card><EmptyState icon="✅" title="Her şey yolunda!" desc="Bekleyen hatırlatma yok." /></Card>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {notifications_parent.map(n => (
            <div key={n.id} className="card anim-slide" style={{
              display: 'flex', alignItems: 'flex-start', gap: 14,
              borderLeft: `3px solid ${n.priority === 'high' ? '#C4503A' : '#E4BB60'}`,
              borderRadius: '0 10px 10px 0',
            }}>
              <div style={{ fontSize: 22, flexShrink: 0 }}>{n.icon}</div>
              <p style={{ fontSize: 13, color: '#0F1B2D', lineHeight: 1.6 }}>{n.text}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

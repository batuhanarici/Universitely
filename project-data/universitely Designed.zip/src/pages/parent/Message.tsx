import { useState, useRef, useEffect } from 'react';
import { Card, Btn, Input } from '../../components/ui';

const initMsgs = [
  { id: '1', from: 'coach', text: 'Merhaba, Arda bu hafta çok iyi çalıştı.', time: '10:00' },
  { id: '2', from: 'parent', text: 'Çok sevindim! Matematik notları nasıl?', time: '10:05' },
  { id: '3', from: 'coach', text: 'Matematik %72 başarıyla iyi durumda. Kimya\'ya odaklanıyoruz.', time: '10:08' },
];

export default function ParentMessage() {
  const [msgs, setMsgs] = useState(initMsgs);
  const [text, setText] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [msgs]);

  function send(e: React.FormEvent) {
    e.preventDefault();
    if (!text.trim()) return;
    setMsgs(m => [...m, { id: Date.now().toString(), from: 'parent', text: text.trim(), time: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }) }]);
    setText('');
  }

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div>
        <h1 className="page-title">Koça Mesaj</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Koçla birebir iletişim</p>
      </div>

      <Card style={{ display: 'flex', flexDirection: 'column', height: 500 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14, paddingBottom: 12, borderBottom: '1px solid rgba(15,27,45,0.08)' }}>
          <div style={{ width: 36, height: 36, borderRadius: '50%', background: '#0F1B2D', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#E4BB60', fontWeight: 700 }}>K</div>
          <div>
            <p style={{ fontSize: 14, fontWeight: 600 }}>Koç Ahmet</p>
            <p style={{ fontSize: 11, color: 'rgba(15,27,45,0.4)' }}>Arda Kaya'nın koçu</p>
          </div>
        </div>

        <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 10 }}>
          {msgs.map(m => (
            <div key={m.id} style={{ display: 'flex', flexDirection: m.from === 'parent' ? 'row-reverse' : 'row', alignItems: 'flex-end', gap: 8 }}>
              {m.from !== 'parent' && (
                <div style={{ width: 28, height: 28, borderRadius: '50%', background: '#0F1B2D', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#E4BB60', fontSize: 12, fontWeight: 700, flexShrink: 0 }}>K</div>
              )}
              <div>
                <div className={m.from === 'parent' ? 'bubble-self' : 'bubble-other'}>{m.text}</div>
                <p style={{ fontSize: 10, color: 'rgba(15,27,45,0.35)', marginTop: 2, textAlign: m.from === 'parent' ? 'right' : 'left' }}>{m.time}</p>
              </div>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        <form onSubmit={send} style={{ display: 'flex', gap: 8, marginTop: 12, paddingTop: 12, borderTop: '1px solid rgba(15,27,45,0.08)' }}>
          <Input placeholder="Mesaj yaz…" value={text} onChange={e => setText(e.target.value)} style={{ flex: 1 }}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(e as any); }}} />
          <Btn variant="primary" type="submit">Gönder</Btn>
        </form>
      </Card>
    </div>
  );
}

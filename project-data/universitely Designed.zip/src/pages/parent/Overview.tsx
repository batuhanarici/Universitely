import { Card, KPICard, Badge, ProgressBar, AnimatedNumber } from '../../components/ui';
import { exams, studySessions, tasks, subjects, subjectPerformance } from '../../lib/mockData';

const today = '2024-01-28';
const todayStudy = studySessions.filter(s => s.date === today);
const todayMins = todayStudy.reduce((a, s) => a + s.duration, 0);
const todayQ = todayStudy.reduce((a, s) => a + s.questions, 0);
const avgNet = +(exams.reduce((a,e) => a + e.net, 0) / exams.length).toFixed(1);
const doneTasks = tasks.filter(t => t.done).length;
const totalTasks = tasks.length;
const doneSubjects = subjects.filter(s => s.done).length;

export default function ParentOverview() {
  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div>
        <h1 className="page-title">Genel Durum</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Çocuğunuzun çalışma özeti · 28 Ocak 2024</p>
      </div>

      <div className="grid-2">
        <KPICard label="Ortalama Net" value={avgNet} decimals={1} color="#E4BB60" />
        <KPICard label="Toplam Deneme" value={exams.length} />
      </div>

      <div className="grid-2">
        <Card>
          <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(15,27,45,0.4)', marginBottom: 8 }}>Bugünkü Çalışma</p>
          <span className="metric-value" style={{ fontSize: 40, fontWeight: 700, color: '#2A9D8F', lineHeight: 1 }}>
            <AnimatedNumber value={todayMins} /> <span style={{ fontSize: 16, fontWeight: 500, color: 'rgba(15,27,45,0.5)' }}>dk</span>
          </span>
        </Card>
        <Card>
          <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(15,27,45,0.4)', marginBottom: 8 }}>Bugün Çözülen Soru</p>
          <span className="metric-value" style={{ fontSize: 40, fontWeight: 700, color: '#2A9D8F', lineHeight: 1 }}>
            <AnimatedNumber value={todayQ} />
          </span>
        </Card>
      </div>

      {/* Haftalık özet */}
      <Card className="tape-accent">
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Haftalık Özet</h3>
        <div className="grid-4" style={{ gap: 12 }}>
          <div><p style={{ fontSize: 11, color: 'rgba(15,27,45,0.4)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Çalışma</p><p className="metric-value" style={{ fontSize: 22, fontWeight: 700 }}>7.2 saat</p></div>
          <div><p style={{ fontSize: 11, color: 'rgba(15,27,45,0.4)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Soru</p><p className="metric-value" style={{ fontSize: 22, fontWeight: 700 }}>255</p></div>
          <div><p style={{ fontSize: 11, color: 'rgba(15,27,45,0.4)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Görev</p><p className="metric-value" style={{ fontSize: 22, fontWeight: 700 }}>{Math.round(doneTasks/totalTasks*100)}%</p></div>
          <div><p style={{ fontSize: 11, color: 'rgba(15,27,45,0.4)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Deneme</p><p className="metric-value" style={{ fontSize: 22, fontWeight: 700 }}>2</p></div>
        </div>
      </Card>

      {/* Konu ilerlemesi */}
      <Card>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <h3 className="section-title" style={{ marginBottom: 0, fontSize: 16 }}>Konu İlerlemesi</h3>
          <span style={{ fontSize: 13, color: 'rgba(15,27,45,0.5)' }}>{doneSubjects}/{subjects.length} konu</span>
        </div>
        <ProgressBar pct={Math.round((doneSubjects/subjects.length)*100)} color="#2A9D8F" />
      </Card>

      {/* Son denemeler */}
      <Card>
        <h3 className="section-title" style={{ marginBottom: 12, fontSize: 16 }}>Son Denemeler</h3>
        <table className="data-table">
          <thead><tr><th>Deneme</th><th>Tarih</th><th>D/Y</th><th>Net</th></tr></thead>
          <tbody>
            {[...exams].reverse().map(e => (
              <tr key={e.id}>
                <td style={{ fontWeight: 500, fontSize: 13 }}>{e.name}</td>
                <td style={{ fontSize: 12, color: 'rgba(15,27,45,0.5)' }}>{e.date}</td>
                <td className="tabular" style={{ fontSize: 12 }}>{e.correct}/{e.wrong}</td>
                <td><span className="metric-value" style={{ fontSize: 18, fontWeight: 700 }}>{e.net}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      {/* Ders başarı */}
      <Card>
        <h3 className="section-title" style={{ marginBottom: 12, fontSize: 16 }}>Ders Bazlı Başarı</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {subjectPerformance.map(s => (
            <div key={s.subject}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span style={{ fontSize: 13 }}>{s.subject}</span>
                <span className="tabular" style={{ fontSize: 13, fontWeight: 600, color: s.pct < 55 ? '#C4503A' : '#2A9D8F' }}>{s.pct}%</span>
              </div>
              <ProgressBar pct={s.pct} color={s.pct < 55 ? '#C4503A' : '#2A9D8F'} />
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

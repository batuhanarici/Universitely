import { Card, Btn, KPICard } from '../../components/ui';
import { printPDF } from '../../lib/utils';
import { weeklyStudyData, exams, subjectPerformance } from '../../lib/mockData';

export default function ParentReport() {
  function weeklyPDF() {
    printPDF('Haftalık Rapor', '22–28 Ocak 2024 · Arda Kaya',
      ['Gün', 'Süre (dk)', 'Soru', 'Görev (%)'],
      weeklyStudyData.map((d, i) => [d.day, String(d.minutes), String(d.questions), String(Math.round(Math.random() * 40 + 60))]),
    );
  }

  function monthlyPDF() {
    printPDF('Aylık Gelişim Raporu', 'Ocak 2024 · Arda Kaya',
      ['Ders', 'Başarı %'],
      subjectPerformance.map(s => [s.subject, String(s.pct)]),
    );
  }

  const avgNet = +(exams.reduce((a,e) => a + e.net, 0) / exams.length).toFixed(1);

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div><h1 className="page-title">Rapor</h1></div>

      <Card className="tape-accent">
        <h3 className="section-title" style={{ marginBottom: 10, fontSize: 16 }}>Haftalık PDF Raporu</h3>
        <p style={{ fontSize: 13, color: 'rgba(15,27,45,0.6)', marginBottom: 14 }}>Son 7 günün çalışma süresi, soru sayısı ve görev tamamlama oranlarını içerir.</p>
        <Btn variant="primary" onClick={weeklyPDF}>Haftalık Raporu PDF Yazdır</Btn>
      </Card>

      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Aylık Gelişim Raporu · Ocak 2024</h3>
        <div className="grid-4" style={{ marginBottom: 16 }}>
          <KPICard label="Çalışma" value={31} sub="saat" />
          <KPICard label="Soru" value={1785} />
          <KPICard label="Deneme" value={exams.length} />
          <KPICard label="Ort. Net" value={avgNet} decimals={1} color="#E4BB60" />
        </div>
        <Btn variant="ghost" onClick={monthlyPDF}>Aylık Raporu PDF Yazdır</Btn>
      </Card>
    </div>
  );
}

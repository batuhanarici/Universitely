import { Card } from '../../components/ui';
import { exams, weeklyStudyData, subjectPerformance, subjects } from '../../lib/mockData';

const lastNet = exams[exams.length - 1].net;
const prevAvg = +(exams.slice(0,-1).reduce((a,e) => a + e.net, 0) / (exams.length - 1)).toFixed(1);
const weekMins = weeklyStudyData.reduce((a,d) => a + d.minutes, 0);
const bestSubject = [...subjectPerformance].sort((a,b) => b.pct - a.pct)[0];
const worstSubject = [...subjectPerformance].sort((a,b) => a.pct - b.pct)[0];
const doneSubjects = subjects.filter(s => s.done).length;

const summaryCards = [
  {
    label: 'Net Trendi',
    icon: lastNet > prevAvg ? '📈' : '📉',
    title: lastNet > prevAvg ? `Son denemede ${lastNet} net ile yükseliş var` : `Son denemede düşüş: ${lastNet} net`,
    desc: `Önceki ortalama: ${prevAvg}. ${lastNet > prevAvg ? 'Harika bir gelişme! Devam edilmesi önerilir.' : 'Zayıf derslere odaklanmak gerekiyor.'}`,
    color: lastNet > prevAvg ? '#2A9D8F' : '#C4503A',
  },
  {
    label: 'Çalışma Temposu',
    icon: weekMins > 210 ? '⚡' : '⏰',
    title: weekMins > 210 ? `Bu hafta ${Math.floor(weekMins/60)} saat çalışıldı — düzenli` : `Bu hafta ${Math.floor(weekMins/60)} saat — az`,
    desc: weekMins > 210 ? 'Çalışma temposu hedefin üzerinde. Bu ritmi korumak çok önemli.' : 'Haftada en az 3.5 saat çalışma hedefleniyor. Desteğe ihtiyaç olabilir.',
    color: weekMins > 210 ? '#2A9D8F' : '#E4BB60',
  },
  {
    label: 'Güçlü / Zayıf Ders',
    icon: '🎯',
    title: `En güçlü: ${bestSubject.subject} (%${bestSubject.pct}) · En zayıf: ${worstSubject.subject} (%${worstSubject.pct})`,
    desc: `${worstSubject.subject} için koçla birlikte özel çalışma planı yapılması önerilir.`,
    color: '#0F1B2D',
  },
  {
    label: 'Hedefe Uzaklık',
    icon: '🏹',
    title: `Hedef: 110 net · Mevcut: ${lastNet.toFixed(1)} net`,
    desc: `Hedefe ${(110 - lastNet).toFixed(1)} net uzaklık var. ${110 - lastNet < 20 ? 'Hedef yaklaşıyor!' : 'Odaklanmış çalışma gerekiyor.'}`,
    color: '#E4BB60',
  },
  {
    label: 'Konu İlerlemesi',
    icon: '📚',
    title: `${doneSubjects}/${subjects.length} konu tamamlandı (%${Math.round(doneSubjects/subjects.length*100)})`,
    desc: 'Kalan konular programa dahil edilmeli. Koç konu takibini yapıyor.',
    color: '#2A9D8F',
  },
];

export default function ParentAISummary() {
  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div>
        <h1 className="page-title">AI Özet</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Çocuğunuzun gelişim özeti</p>
      </div>

      <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {summaryCards.map(c => (
          <Card key={c.label} style={{ display: 'flex', gap: 16, borderLeft: `3px solid ${c.color}`, borderRadius: '0 10px 10px 0' }}>
            <div style={{ fontSize: 28, flexShrink: 0 }}>{c.icon}</div>
            <div>
              <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'rgba(15,27,45,0.4)', marginBottom: 4 }}>{c.label}</p>
              <p style={{ fontSize: 14, fontWeight: 600, color: '#0F1B2D', marginBottom: 6 }}>{c.title}</p>
              <p style={{ fontSize: 13, color: 'rgba(15,27,45,0.65)', lineHeight: 1.6 }}>{c.desc}</p>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

import { Card, Badge, Btn } from '../../components/ui';
import { exams, examTemplates } from '../../lib/mockData';
import { downloadCSV, net } from '../../lib/utils';

export default function StudentCompare() {
  const t1Exams = exams.filter(e => e.templateId === 't1');

  if (t1Exams.length < 2) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
        <h1 className="page-title">Karşılaştırma</h1>
        <Card>
          <p style={{ fontSize: 14, color: 'rgba(15,27,45,0.6)' }}>Aynı şablondan en az 2 deneme gereklidir. Henüz yeterli deneme yok.</p>
        </Card>
      </div>
    );
  }

  const lessons = ['Türkçe', 'Matematik Temel', 'Fen Bilimleri', 'Sosyal Bilimler'];
  const sortedExams = [...t1Exams].sort((a,b) => a.date.localeCompare(b.date));
  const totals = sortedExams.map(e => e.net);
  const bestIdx = totals.indexOf(Math.max(...totals));

  function exportCSV() {
    downloadCSV('karsilastirma', ['Şablon','Deneme','Tarih','Ders','Net'],
      sortedExams.flatMap(e => lessons.map(l => ['TYT Standart', e.name, e.date, l, String(Math.random() * 20 + 15 | 0)])));
  }

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div>
          <h1 className="page-title">Karşılaştırma</h1>
          <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Aynı şablon · TYT Standart</p>
        </div>
        <Btn variant="ghost" size="sm" onClick={exportCSV}>CSV İndir</Btn>
      </div>

      <Card style={{ overflowX: 'auto' }}>
        <table className="data-table">
          <thead>
            <tr>
              <th>Ders</th>
              {sortedExams.map((e, i) => (
                <th key={e.id} style={{ color: i === bestIdx ? '#A07C20' : undefined }}>
                  {e.name.split(' ').slice(-1)[0]} · {e.date.slice(5)}
                  {i === bestIdx && ' 🏅'}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {lessons.map(l => (
              <tr key={l}>
                <td style={{ fontWeight: 500 }}>{l}</td>
                {sortedExams.map((e, i) => (
                  <td key={e.id} className="tabular" style={{ background: i === bestIdx ? 'rgba(228,187,96,0.06)' : undefined, fontWeight: 600 }}>
                    {(Math.random() * 15 + 10).toFixed(1)}
                  </td>
                ))}
              </tr>
            ))}
            <tr style={{ fontWeight: 700 }}>
              <td>Toplam Net</td>
              {sortedExams.map((e, i) => (
                <td key={e.id} className="tabular metric-value" style={{ fontSize: 18, background: i === bestIdx ? 'rgba(228,187,96,0.08)' : undefined, color: i === bestIdx ? '#A07C20' : '#0F1B2D' }}>
                  {e.net}
                  {i === bestIdx && <span style={{ marginLeft: 4 }}>🏅</span>}
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </Card>
    </div>
  );
}

import { useState } from 'react';
import { Card, Btn, Input, Label, FormGroup, Select, Checkbox, EmptyState, Badge, useToast } from '../../components/ui';
import { wrongQuestions as initial } from '../../lib/mockData';
import { subjects } from '../../lib/mockData';
import { Icon } from '../../components/Layout';

export default function StudentWrongs() {
  const { toast, show } = useToast();
  const [list, setList] = useState(initial);
  const [form, setForm] = useState({ desc: '', subject: '', source: '', page: '', qno: '' });

  const unique = [...new Set(subjects.map(s => s.lesson))];

  function addWrong(e: React.FormEvent) {
    e.preventDefault();
    if (!form.desc) return;
    setList(l => [...l, { id: Date.now().toString(), desc: form.desc, subject: form.subject, source: form.source, page: +form.page || 0, qno: +form.qno || 0, solved: false }]);
    setForm({ desc: '', subject: '', source: '', page: '', qno: '' });
    show('Yanlış eklendi ✓');
  }
  function toggle(id: string) { setList(l => l.map(x => x.id === id ? { ...x, solved: !x.solved } : x)); }
  function del(id: string) { setList(l => l.filter(x => x.id !== id)); }
  function addToRep(id: string) { show('Tekrar planına eklendi ✓'); }

  const unsolved = list.filter(x => !x.solved);
  const solved = list.filter(x => x.solved);

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {toast}
      <div>
        <h1 className="page-title">Yanlışlar</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Yanlış soru arşivi ve tekrar planı</p>
      </div>

      {/* Add form */}
      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Yanlış Soru Ekle</h3>
        <form onSubmit={addWrong} style={{ display: 'grid', gridTemplateColumns: '3fr 1fr 1fr 1fr 1fr auto', gap: 10, alignItems: 'flex-end' }}>
          <FormGroup><Label>Açıklama *</Label><Input placeholder="Fonksiyon tanımı ve özellikleri" value={form.desc} onChange={e => setForm(f=>({...f,desc:e.target.value}))} required /></FormGroup>
          <FormGroup><Label>Konu</Label><Select value={form.subject} onChange={e => setForm(f=>({...f,subject:e.target.value}))}><option value="">Seç…</option>{unique.map(u => <option key={u}>{u}</option>)}</Select></FormGroup>
          <FormGroup><Label>Kaynak</Label><Input placeholder="Palme TYT" value={form.source} onChange={e => setForm(f=>({...f,source:e.target.value}))} /></FormGroup>
          <FormGroup><Label>Sayfa</Label><Input type="number" min={0} placeholder="142" value={form.page} onChange={e => setForm(f=>({...f,page:e.target.value}))} /></FormGroup>
          <FormGroup><Label>Soru No</Label><Input type="number" min={0} placeholder="12" value={form.qno} onChange={e => setForm(f=>({...f,qno:e.target.value}))} /></FormGroup>
          <Btn variant="primary" type="submit" size="sm"><Icon name="plus" size={14} /> Ekle</Btn>
        </form>
      </Card>

      {/* Unsolved */}
      <Card>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
          <h3 className="section-title" style={{ marginBottom: 0, fontSize: 16 }}>Çözülmeyenler</h3>
          <Badge variant="brick">{unsolved.length} bekliyor</Badge>
        </div>
        {unsolved.length === 0 ? (
          <EmptyState icon="✅" title="Tüm yanlışları çözdün!" desc="Harika iş! Yeni yanlışlar eklenince burada görünür." />
        ) : (
          <div className="rule-lines" style={{ borderRadius: 8, overflow: 'hidden' }}>
            {unsolved.map(q => (
              <div key={q.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px' }}>
                <Checkbox checked={false} onChange={() => toggle(q.id)} />
                <div style={{ flex: 1 }}>
                  <p style={{ fontSize: 13, fontWeight: 500, color: '#0F1B2D', marginBottom: 2 }}>{q.desc}</p>
                  <p style={{ fontSize: 11, color: 'rgba(15,27,45,0.45)' }}>
                    {q.subject && <>{q.subject} · </>}{q.source && <>{q.source}</>}{q.page > 0 && <> · s.{q.page}</>}{q.qno > 0 && <> · s.{q.qno}</>}
                  </p>
                </div>
                <button className="btn btn-ghost btn-sm" onClick={() => addToRep(q.id)}>Tekrara Ekle</button>
                <button className="btn btn-danger btn-sm" onClick={() => del(q.id)}><Icon name="trash" size={13} /></button>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Solved */}
      {solved.length > 0 && (
        <Card>
          <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Çözülenler</h3>
          <div className="rule-lines" style={{ borderRadius: 8, overflow: 'hidden' }}>
            {solved.map(q => (
              <div key={q.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', opacity: 0.6 }}>
                <Checkbox checked onChange={() => toggle(q.id)} />
                <p style={{ fontSize: 13, textDecoration: 'line-through', color: 'rgba(15,27,45,0.5)' }}>{q.desc}</p>
                <Badge variant="teal">Çözüldü ✓</Badge>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

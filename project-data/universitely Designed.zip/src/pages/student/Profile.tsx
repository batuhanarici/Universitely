import { useState } from 'react';
import { Card, Btn, Input, Label, FormGroup, Badge, useToast } from '../../components/ui';

const examTypes = ['TYT', 'AYT', 'TYT+AYT'];

export default function StudentProfile() {
  const { toast, show } = useToast();
  const [form, setForm] = useState({ university: 'İTÜ Bilgisayar Mühendisliği', department: 'Bilgisayar Mühendisliği', examType: 'TYT+AYT', targetNet: '110', emailNotif: true });
  const [saved, setSaved] = useState(true);

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) => { setForm(f => ({ ...f, [k]: e.target.value })); setSaved(false); };

  function save(e: React.FormEvent) {
    e.preventDefault();
    setSaved(true);
    show('Profil kaydedildi ✓');
  }

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20, maxWidth: 640 }}>
      {toast}
      <div>
        <h1 className="page-title">Profil & Hedefler</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Hedeflerini belirle, AI koçun sana özel plan yapsın.</p>
      </div>

      {saved && (
        <Card className="tape-accent" style={{ background: '#F0EBE0' }}>
          <p style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'rgba(15,27,45,0.4)', marginBottom: 10 }}>Hedef Özeti</p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
            <Badge variant="ink">🏛 {form.university}</Badge>
            <Badge variant="ink">📐 {form.department}</Badge>
            <Badge variant="gold">📋 {form.examType}</Badge>
            <Badge variant="teal">🎯 Hedef: {form.targetNet} net</Badge>
          </div>
        </Card>
      )}

      <Card>
        <h2 className="section-title" style={{ marginBottom: 20 }}>Bilgileri Düzenle</h2>
        <form onSubmit={save} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <FormGroup>
            <Label>Hedef Üniversite</Label>
            <Input placeholder="Örn: İTÜ, ODTÜ, Boğaziçi…" value={form.university} onChange={set('university')} />
          </FormGroup>
          <FormGroup>
            <Label>Hedef Bölüm</Label>
            <Input placeholder="Örn: Bilgisayar Mühendisliği" value={form.department} onChange={set('department')} />
          </FormGroup>
          <FormGroup>
            <Label>Sınav Türü</Label>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 4 }}>
              {examTypes.map(t => (
                <button key={t} type="button"
                  onClick={() => { setForm(f => ({ ...f, examType: t })); setSaved(false); }}
                  style={{ padding: '6px 16px', borderRadius: 8, border: form.examType === t ? '1.5px solid #E4BB60' : '1.5px solid rgba(15,27,45,0.15)', background: form.examType === t ? 'rgba(228,187,96,0.12)' : 'transparent', fontFamily: 'var(--font-body)', fontSize: 13, fontWeight: 600, color: form.examType === t ? '#A07C20' : '#0F1B2D', cursor: 'pointer' }}>
                  {t}
                </button>
              ))}
            </div>
          </FormGroup>
          <FormGroup>
            <Label>Hedef Net</Label>
            <Input type="number" placeholder="Örn: 110" value={form.targetNet} onChange={set('targetNet')} style={{ maxWidth: 160 }} />
          </FormGroup>
          <label style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', fontSize: 13 }}>
            <input type="checkbox" className="checkbox" checked={form.emailNotif} onChange={e => setForm(f => ({ ...f, emailNotif: e.target.checked }))} />
            <span>
              <strong>E-posta hatırlatmaları</strong>
              <span style={{ color: 'rgba(15,27,45,0.5)', fontSize: 12, display: 'block' }}>Her sabah görev, tekrar ve çözülmemiş yanlış özeti</span>
            </span>
          </label>
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 4 }}>
            <Btn variant="primary" type="submit">Kaydet</Btn>
          </div>
        </form>
      </Card>
    </div>
  );
}

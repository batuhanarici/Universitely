import { useState } from 'react';
import { Card, Checkbox, Badge } from '../../components/ui';
import { tasks, repetitionPlan } from '../../lib/mockData';

function getWeekDays(baseDate: Date) {
  const days = [];
  const start = new Date(baseDate);
  const day = start.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  start.setDate(start.getDate() + diff);
  for (let i = 0; i < 7; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    days.push(d);
  }
  return days;
}

const dayNames = ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'];

export default function StudentCalendar() {
  const today = new Date('2024-01-28');
  const weekDays = getWeekDays(today);
  const [tasksDone, setTasksDone] = useState<Set<string>>(new Set(['t2']));
  const [repsDone, setRepsDone] = useState<Set<string>>(new Set());

  function fmtDate(d: Date) { return d.toISOString().slice(0, 10); }
  function isToday(d: Date) { return fmtDate(d) === fmtDate(today); }

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div>
        <h1 className="page-title">Takvim</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Haftalık görevler ve tekrar planı</p>
      </div>

      <Card style={{ overflowX: 'auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: `repeat(7, minmax(120px, 1fr))`, gap: 0, minWidth: 700 }}>
          {weekDays.map((day, i) => {
            const dateStr = fmtDate(day);
            const dayTasks = tasks.filter(t => t.date === dateStr && !t.fromCoach);
            const dayReps = repetitionPlan.filter(r => r.date === dateStr);
            return (
              <div key={i} style={{
                borderRight: i < 6 ? '1px solid rgba(15,27,45,0.07)' : 'none',
                padding: '12px 10px',
                background: isToday(day) ? 'rgba(228,187,96,0.06)' : 'transparent',
                minHeight: 160
              }}>
                <div style={{ marginBottom: 10, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2 }}>
                  <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(15,27,45,0.4)' }}>{dayNames[i]}</span>
                  <span style={{
                    width: 28, height: 28, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
                    background: isToday(day) ? '#0F1B2D' : 'transparent',
                    color: isToday(day) ? '#F4EFE4' : '#0F1B2D',
                    fontSize: 13, fontWeight: 700
                  }}>{day.getDate()}</span>
                </div>
                {dayTasks.length === 0 && dayReps.length === 0 ? (
                  <span style={{ fontSize: 12, color: 'rgba(15,27,45,0.3)' }}>—</span>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                    {dayTasks.map(t => (
                      <label key={t.id} style={{ display: 'flex', alignItems: 'flex-start', gap: 6, cursor: 'pointer' }}>
                        <Checkbox checked={tasksDone.has(t.id)} onChange={() => setTasksDone(s => { const n = new Set(s); n.has(t.id) ? n.delete(t.id) : n.add(t.id); return n; })} />
                        <span style={{ fontSize: 11, lineHeight: 1.4, textDecoration: tasksDone.has(t.id) ? 'line-through' : 'none', color: tasksDone.has(t.id) ? 'rgba(15,27,45,0.35)' : '#0F1B2D' }}>{t.title}</span>
                      </label>
                    ))}
                    {dayReps.map(r => (
                      <label key={r.id} style={{ display: 'flex', alignItems: 'flex-start', gap: 6, cursor: 'pointer' }}>
                        <Checkbox checked={repsDone.has(r.id)} onChange={() => setRepsDone(s => { const n = new Set(s); n.has(r.id) ? n.delete(r.id) : n.add(r.id); return n; })} />
                        <span style={{ fontSize: 11, lineHeight: 1.4, color: '#C4503A', textDecoration: repsDone.has(r.id) ? 'line-through' : 'none' }}>Tekrar: {r.desc}</span>
                      </label>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </Card>

      <p style={{ fontSize: 12, color: 'rgba(15,27,45,0.4)' }}>
        Koç atamaları <strong style={{ color: '#E4BB60' }}>altın</strong> renkte, tekrar planları <strong style={{ color: '#C4503A' }}>kırmızı</strong> olarak gösterilir.
      </p>
    </div>
  );
}

import { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { AnimatedNumber, ProgressBar, Badge, Card, KPICard, EmptyState, Checkbox, useToast } from '../../components/ui';
import { exams, tasks, wrongQuestions, subjectPerformance, weeklyStudyData, repetitionPlan } from '../../lib/mockData';
import { pct } from '../../lib/utils';

const chartData = exams.map(e => ({ name: e.name.split(' ').slice(-1)[0], doğru: e.correct, yanlış: e.wrong, boş: e.empty }));
const lastExam = exams[exams.length - 1];
const prevExam = exams[exams.length - 2];
const netDiff = +(lastExam.net - prevExam.net).toFixed(2);

export default function StudentDashboard() {
  const [reps, setReps] = useState(repetitionPlan);
  const [taskList, setTaskList] = useState(tasks.filter(t => t.date === '2024-01-28' && t.type === 'daily'));
  const { toast, show } = useToast();
  const todayDone = taskList.filter(t => t.done).length;
  const todayTotal = taskList.length;

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {toast}

      {/* Header */}
      <div>
        <h1 className="page-title">Günaydın, Arda 👋</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>28 Ocak 2024 · Pazartesi</p>
      </div>

      {/* Hero: Son Net */}
      <div className="card tape-accent" style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 16, alignItems: 'center' }}>
        <div>
          <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(15,27,45,0.4)', marginBottom: 8 }}>Son Net · {lastExam.name}</p>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 12 }}>
            <span className="metric-value" style={{ fontSize: 56, fontWeight: 700, color: '#0F1B2D', lineHeight: 1 }}>
              <AnimatedNumber value={lastExam.net} decimals={2} />
            </span>
            <span style={{ fontSize: 20, fontWeight: 600, color: netDiff >= 0 ? '#2A9D8F' : '#C4503A', display: 'flex', alignItems: 'center', gap: 4 }}>
              {netDiff >= 0 ? '↑' : '↓'} {Math.abs(netDiff).toFixed(2)}
            </span>
          </div>
          <p style={{ fontSize: 13, color: 'rgba(15,27,45,0.5)', marginTop: 6 }}>
            Tekrar havuzunda <strong style={{ color: '#0F1B2D' }}>{wrongQuestions.filter(w => !w.solved).length}</strong> soru bekliyor. Kimya'ya ağırlık ver.
          </p>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ width: 80, height: 80, borderRadius: '50%', border: '3px solid #E4BB60', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' }}>
            <span style={{ fontSize: 11, color: 'rgba(15,27,45,0.4)', fontWeight: 700 }}>D/Y/B</span>
            <span style={{ fontSize: 12, fontWeight: 700, color: '#0F1B2D' }}>{lastExam.correct}/{lastExam.wrong}/{lastExam.empty}</span>
          </div>
        </div>
      </div>

      {/* Row 1: Bugünün Görevleri + Tamamlanma */}
      <div className="grid-2">
        <Card>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
            <h3 className="section-title" style={{ marginBottom: 0, fontSize: 16 }}>Bugünün Yapılacakları</h3>
            <Badge variant="ink">{todayDone}/{todayTotal}</Badge>
          </div>
          {taskList.length === 0 ? (
            <p style={{ fontSize: 13, color: 'rgba(15,27,45,0.4)', fontStyle: 'italic' }}>Bugün için görev yok.</p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {taskList.map(t => (
                <label key={t.id} style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}>
                  <Checkbox
                    checked={t.done}
                    onChange={() => setTaskList(list => list.map(x => x.id === t.id ? { ...x, done: !x.done } : x))}
                  />
                  <span style={{ fontSize: 13, textDecoration: t.done ? 'line-through' : 'none', color: t.done ? 'rgba(15,27,45,0.35)' : '#0F1B2D' }}>{t.title}</span>
                </label>
              ))}
            </div>
          )}
        </Card>

        <Card>
          <h3 className="section-title" style={{ marginBottom: 4, fontSize: 16 }}>Bugünkü Tamamlanma</h3>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 12 }}>
            <span className="metric-value" style={{ fontSize: 40, fontWeight: 700, color: '#2A9D8F' }}>
              <AnimatedNumber value={pct(todayDone, todayTotal)} />%
            </span>
          </div>
          <ProgressBar pct={pct(todayDone, todayTotal)} color="#2A9D8F" />
          <p style={{ fontSize: 12, color: 'rgba(15,27,45,0.45)', marginTop: 10 }}>Bu hafta ortalama tamamlanma: <strong style={{ color: '#0F1B2D' }}>74%</strong></p>
        </Card>
      </div>

      {/* Deneme Grafiği */}
      <Card>
        <h3 className="section-title" style={{ marginBottom: 16, fontSize: 16 }}>Deneme Bazlı D/Y/B</h3>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={chartData} barSize={28} barGap={2}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(15,27,45,0.06)" />
            <XAxis dataKey="name" tick={{ fontSize: 11, fill: 'rgba(15,27,45,0.4)' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: 'rgba(15,27,45,0.4)' }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ background: '#0F1B2D', border: 'none', borderRadius: 8, color: '#F4EFE4', fontSize: 12 }} />
            <Bar dataKey="doğru" fill="#2A9D8F" radius={[2,2,0,0]} />
            <Bar dataKey="yanlış" fill="#C4503A" radius={[2,2,0,0]} />
            <Bar dataKey="boş" fill="#9A9FA8" radius={[2,2,0,0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      {/* Konu Performansı */}
      <Card>
        <h3 className="section-title" style={{ marginBottom: 16, fontSize: 16 }}>Konu Bazlı Performans</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {subjectPerformance.map(s => (
            <div key={s.subject}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                <span style={{ fontSize: 13, fontWeight: 500, display: 'flex', alignItems: 'center', gap: 8 }}>
                  {s.subject}
                  {s.pct < 55 && <Badge variant="brick">Ağırlık ver</Badge>}
                </span>
                <span className="tabular" style={{ fontSize: 13, fontWeight: 600, color: s.pct < 55 ? '#C4503A' : '#2A9D8F' }}>{s.pct}%</span>
              </div>
              <ProgressBar pct={s.pct} color={s.pct < 55 ? '#C4503A' : '#2A9D8F'} />
            </div>
          ))}
        </div>
      </Card>

      {/* Tekrar Havuzu */}
      <Card>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <h3 className="section-title" style={{ marginBottom: 0, fontSize: 16 }}>Tekrar Havuzu</h3>
          <span className="metric-value" style={{ fontSize: 28, fontWeight: 700, color: '#E4BB60' }}>
            <AnimatedNumber value={reps.filter(r => !r.done).length} />
          </span>
        </div>
        {reps.filter(r => !r.done).length === 0 ? (
          <p style={{ fontSize: 13, color: '#2A9D8F', fontWeight: 500 }}>Harika! Tüm tekrarlarını tamamladın. 🎉</p>
        ) : (
          <div className="rule-lines" style={{ borderRadius: 8, overflow: 'hidden' }}>
            {reps.map(r => (
              <label key={r.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '9px 12px', cursor: 'pointer' }}>
                <Checkbox checked={r.done} onChange={() => { setReps(list => list.map(x => x.id === r.id ? { ...x, done: !x.done } : x)); show('Tekrar kaydedildi ✓'); }} />
                <span style={{ flex: 1, fontSize: 13, textDecoration: r.done ? 'line-through' : 'none', color: r.done ? 'rgba(15,27,45,0.35)' : '#0F1B2D' }}>{r.desc}</span>
                <span style={{ fontSize: 11, color: 'rgba(15,27,45,0.4)' }}>{r.date}</span>
              </label>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

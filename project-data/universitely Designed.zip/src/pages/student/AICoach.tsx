import { useState } from 'react';
import { Card, Badge, Btn, EmptyState } from '../../components/ui';
import { aiSuggestions as initial } from '../../lib/mockData';

const priorityVariant: Record<string, 'brick' | 'gold' | 'teal'> = {
  'Öncelikli': 'brick',
  'Dikkat': 'gold',
  'İyi Gidiyorsun': 'teal',
};

export default function StudentAICoach() {
  const [suggestions, setSuggestions] = useState(initial);
  const [refreshKey, setRefreshKey] = useState(0);

  function refresh() {
    setSuggestions([...initial].sort(() => Math.random() - 0.5));
    setRefreshKey(k => k + 1);
  }

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div>
          <h1 className="page-title">AI Koçum</h1>
          <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Verilerine dayalı kişisel öneriler</p>
        </div>
        <Btn variant="ghost" size="sm" onClick={refresh}>↻ Yenile</Btn>
      </div>

      <div key={refreshKey} className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {suggestions.length === 0 ? (
          <EmptyState icon="🤖" title="Henüz öneri yok" desc="Daha fazla deneme ve çalışma verisi ekledikçe öneriler oluşur." />
        ) : (
          suggestions.map(s => (
            <Card key={s.id} className="tape-accent" style={{ display: 'flex', gap: 16, alignItems: 'flex-start' }}>
              <div style={{ fontSize: 28, flexShrink: 0, marginTop: 2 }}>{s.icon}</div>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 6 }}>
                  <Badge variant="gray">{s.category}</Badge>
                  <Badge variant={priorityVariant[s.priority] || 'gray'}>{s.priority}</Badge>
                </div>
                <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 17, fontWeight: 600, color: '#0F1B2D', marginBottom: 6 }}>{s.title}</h3>
                <p style={{ fontSize: 13, color: 'rgba(15,27,45,0.65)', lineHeight: 1.6 }}>{s.desc}</p>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}

import { Card, Badge, EmptyState } from '../../components/ui';
import { notifications_student } from '../../lib/mockData';
import { Icon } from '../../components/Layout';

export default function StudentNotifications() {
  const notifs = notifications_student;

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div>
        <h1 className="page-title">Bildirimler</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Bekleyen hatırlatmalar</p>
      </div>

      {notifs.length === 0 ? (
        <Card>
          <EmptyState icon="✅" title="Her şey yolunda!" desc="Bekleyen hatırlatma yok. Harika bir gün!" />
        </Card>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {notifs.map(n => (
            <div key={n.id} className="card anim-slide" style={{
              display: 'flex', alignItems: 'center', gap: 14,
              borderLeft: `3px solid ${n.priority === 'high' ? '#C4503A' : '#E4BB60'}`,
              borderRadius: '0 10px 10px 0',
            }}>
              <div style={{ color: n.priority === 'high' ? '#C4503A' : '#A07C20' }}>
                <Icon name={n.type === 'warning' ? 'alert' : 'bell'} size={20} />
              </div>
              <p style={{ flex: 1, fontSize: 13, color: '#0F1B2D' }}>{n.text}</p>
              <Badge variant={n.priority === 'high' ? 'brick' : 'gold'}>{n.priority === 'high' ? 'Öncelikli' : 'Normal'}</Badge>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

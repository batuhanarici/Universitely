import { LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts';
import { Card } from '../../components/ui';
import { exams, subjectPerformance } from '../../lib/mockData';

const netData = exams.map(e => ({ name: e.name.replace('Denemesi ', ''), net: e.net }));
const subjectWrong = [...subjectPerformance].sort((a,b) => (a.wrong + a.empty) - (b.wrong + b.empty)).slice(-10).map(s => ({ name: s.subject, yanlış: s.wrong, boş: s.empty }));
const subjectPct = [...subjectPerformance].sort((a,b) => a.pct - b.pct).map(s => ({ name: s.subject, pct: s.pct }));

const tt = { contentStyle: { background: '#0F1B2D', border: 'none', borderRadius: 8, color: '#F4EFE4', fontSize: 12 } };

export default function StudentAnalysis() {
  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div>
        <h1 className="page-title">Analiz</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Deneme performansı grafikleri</p>
      </div>

      {/* Net trend */}
      <Card className="tape-accent">
        <h3 className="section-title" style={{ marginBottom: 16, fontSize: 16 }}>Net Grafiği</h3>
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={netData}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(15,27,45,0.06)" />
            <XAxis dataKey="name" tick={{ fontSize: 11, fill: 'rgba(15,27,45,0.4)' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: 'rgba(15,27,45,0.4)' }} axisLine={false} tickLine={false} domain={['auto','auto']} />
            <Tooltip {...tt} />
            <Line type="monotone" dataKey="net" stroke="#E4BB60" strokeWidth={2.5} dot={{ r: 4, fill: '#E4BB60', strokeWidth: 2, stroke: '#fff' }} activeDot={{ r: 6 }} />
          </LineChart>
        </ResponsiveContainer>
      </Card>

      {/* Ders bazlı */}
      <Card>
        <h3 className="section-title" style={{ marginBottom: 16, fontSize: 16 }}>Ders Bazlı D/Y/B</h3>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={subjectPerformance} barSize={20} barGap={2}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(15,27,45,0.06)" />
            <XAxis dataKey="subject" tick={{ fontSize: 10, fill: 'rgba(15,27,45,0.4)' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: 'rgba(15,27,45,0.4)' }} axisLine={false} tickLine={false} />
            <Tooltip {...tt} />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <Bar dataKey="correct" name="Doğru" fill="#2A9D8F" radius={[2,2,0,0]} />
            <Bar dataKey="wrong" name="Yanlış" fill="#C4503A" radius={[2,2,0,0]} />
            <Bar dataKey="empty" name="Boş" fill="#9A9FA8" radius={[2,2,0,0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      {/* Yanlış dağılım */}
      <Card>
        <h3 className="section-title" style={{ marginBottom: 16, fontSize: 16 }}>En Çok Yanlış/Boş Yapılan Konular</h3>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={subjectWrong} layout="vertical" barSize={14} barGap={2}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(15,27,45,0.06)" horizontal={false} />
            <XAxis type="number" tick={{ fontSize: 11, fill: 'rgba(15,27,45,0.4)' }} axisLine={false} tickLine={false} />
            <YAxis type="category" dataKey="name" width={80} tick={{ fontSize: 11, fill: '#0F1B2D' }} axisLine={false} tickLine={false} />
            <Tooltip {...tt} />
            <Bar dataKey="yanlış" fill="#C4503A" radius={[0,2,2,0]} />
            <Bar dataKey="boş" fill="#9A9FA8" radius={[0,2,2,0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      {/* Konu bazlı başarı */}
      <Card>
        <h3 className="section-title" style={{ marginBottom: 16, fontSize: 16 }}>Konu Bazlı Başarı Yüzdesi</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {subjectPct.map(s => (
            <div key={s.name} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <span style={{ width: 80, fontSize: 12, fontWeight: 500, color: s.pct < 55 ? '#C4503A' : '#0F1B2D' }}>{s.name}</span>
              <div style={{ flex: 1, height: 8, background: 'rgba(15,27,45,0.07)', borderRadius: 4, overflow: 'hidden' }}>
                <div style={{ height: '100%', width: `${s.pct}%`, background: s.pct < 55 ? '#C4503A' : '#2A9D8F', borderRadius: 4, transition: 'width 700ms ease' }} />
              </div>
              <span className="tabular" style={{ fontSize: 13, fontWeight: 600, width: 40, textAlign: 'right', color: s.pct < 55 ? '#C4503A' : '#2A9D8F' }}>{s.pct}%</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

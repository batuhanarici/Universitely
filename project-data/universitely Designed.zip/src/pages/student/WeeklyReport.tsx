import { Card, KPICard, Btn, AnimatedNumber, useToast } from '../../components/ui';
import { weeklyStudyData, exams, subjectPerformance } from '../../lib/mockData';
import { printPDF } from '../../lib/utils';

const totalMins = weeklyStudyData.reduce((a,d) => a + d.minutes, 0);
const totalH = Math.floor(totalMins / 60);
const dailyAvg = Math.round(totalMins / 7);
const avgNet = +(exams.reduce((a,e) => a + e.net, 0) / exams.length).toFixed(1);
const top3 = [{ name: 'Matematik', mins: 255 }, { name: 'Fizik', mins: 120 }, { name: 'Türkçe', mins: 60 }];
const maxBar = Math.max(...weeklyStudyData.map(d => d.minutes));

export default function StudentWeeklyReport() {
  const { toast, show } = useToast();

  const summary = `Bu hafta toplam ${totalH} saat ${totalMins % 60} dakika çalıştın. ${exams.length} deneme yaptın ve ortalama netin ${avgNet}. Kimya konusunda zayıflık devam ediyor — önümüzdeki hafta bu derse öncelik ver. Matematik tempon güçlü, bunu koru. Tekrar havuzundaki 3 soru hâlâ bekliyor; bu hafta tamamlamayı hedefle.`;

  function copyReport() {
    navigator.clipboard.writeText(summary);
    show('Rapor kopyalandı ✓');
  }

  function downloadPDF() {
    printPDF('Haftalık Rapor', '28 Ocak 2024 – Universitely', ['Gün', 'Süre (dk)', 'Soru'],
      weeklyStudyData.map(d => [d.day, String(d.minutes), String(d.questions)]));
  }

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {toast}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div>
          <h1 className="page-title">Haftalık Rapor</h1>
          <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>22 – 28 Ocak 2024</p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <Btn variant="ghost" size="sm" onClick={copyReport}>Kopyala</Btn>
          <Btn variant="primary" size="sm" onClick={downloadPDF}>PDF</Btn>
        </div>
      </div>

      {/* Özet */}
      <Card className="tape-accent">
        <h3 className="section-title" style={{ marginBottom: 12, fontSize: 16 }}>Özet</h3>
        <p style={{ fontSize: 14, lineHeight: 1.7, color: 'rgba(15,27,45,0.75)' }}>{summary}</p>
      </Card>

      {/* Günlük grafik */}
      <Card>
        <h3 className="section-title" style={{ marginBottom: 16, fontSize: 16 }}>Günlük Çalışma Süresi</h3>
        <div style={{ display: 'flex', gap: 8, height: 120, alignItems: 'flex-end' }}>
          {weeklyStudyData.map(d => (
            <div key={d.day} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
              <span className="tabular" style={{ fontSize: 10, color: 'rgba(15,27,45,0.45)', fontWeight: 600 }}>{d.minutes > 0 ? d.minutes : ''}</span>
              <div style={{
                width: '100%', borderRadius: '3px 3px 0 0',
                background: d.minutes > 0 ? '#E4BB60' : 'rgba(15,27,45,0.07)',
                height: maxBar ? `${(d.minutes / maxBar) * 90}px` : 4,
                minHeight: 4,
                transition: 'height 700ms ease'
              }} />
              <span style={{ fontSize: 11, fontWeight: 600, color: 'rgba(15,27,45,0.5)' }}>{d.day}</span>
            </div>
          ))}
        </div>
      </Card>

      {/* KPIs */}
      <div className="grid-4">
        <KPICard label="Toplam Çalışma" value={totalH} sub={`${dailyAvg} dk/gün ort.`} />
        <KPICard label="Görev Tamamlama" value={74} sub="% bu hafta" color="#2A9D8F" />
        <KPICard label="Deneme Ortalaması" value={avgNet} sub="net" decimals={1} color="#E4BB60" />
        <KPICard label="Kaynak İlerlemesi" value={68} sub="% genel" color="#0F1B2D" />
      </div>

      {/* En çok çalışılan */}
      <Card>
        <h3 className="section-title" style={{ marginBottom: 16, fontSize: 16 }}>En Çok Çalıştığın Konular</h3>
        {top3.map((s, i) => (
          <div key={s.name} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: i < top3.length - 1 ? '1px solid rgba(15,27,45,0.06)' : 'none' }}>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, color: '#E4BB60', minWidth: 28 }}>{i + 1}</span>
            <span style={{ flex: 1, fontSize: 14, fontWeight: 500 }}>{s.name}</span>
            <span className="tabular" style={{ fontSize: 14, fontWeight: 700, color: '#0F1B2D' }}>{s.mins} dk</span>
          </div>
        ))}
      </Card>

      {/* Alt istatistikler */}
      <div style={{ display: 'flex', gap: 12 }}>
        <Card style={{ flex: 1, textAlign: 'center' }}>
          <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(15,27,45,0.4)', marginBottom: 4 }}>Çözülen Yanlış</p>
          <span className="metric-value" style={{ fontSize: 32, fontWeight: 700, color: '#2A9D8F' }}>
            <AnimatedNumber value={3} />
          </span>
        </Card>
        <Card style={{ flex: 1, textAlign: 'center' }}>
          <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(15,27,45,0.4)', marginBottom: 4 }}>Yapılan Tekrar</p>
          <span className="metric-value" style={{ fontSize: 32, fontWeight: 700, color: '#2A9D8F' }}>
            <AnimatedNumber value={4} />
          </span>
        </Card>
      </div>
    </div>
  );
}

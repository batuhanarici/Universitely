import { useState } from 'react';
import { Card, Btn, Input, Label, FormGroup, Select, ProgressBar, Badge, AnimatedNumber, EmptyState, useToast } from '../../components/ui';
import { resources as initialResources } from '../../lib/mockData';
import { pct, daysLeft } from '../../lib/utils';
import { Icon } from '../../components/Layout';

const types = ['Kitap', 'Soru Bankası', 'Deneme', 'Video'];

export default function StudentResources() {
  const { toast, show } = useToast();
  const [resList, setResList] = useState(initialResources);
  const [form, setForm] = useState({ name: '', type: 'Kitap', total: '', endDate: '' });

  const totalProgress = resList.reduce((a, r) => a + r.progress, 0);
  const totalTotal = resList.reduce((a, r) => a + r.total, 0);

  function addResource(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name || !form.total) return;
    setResList(l => [...l, { id: Date.now().toString(), name: form.name, type: form.type, total: +form.total, progress: 0, startDate: new Date().toISOString().slice(0,10), endDate: form.endDate || '2024-03-31' }]);
    setForm({ name: '', type: 'Kitap', total: '', endDate: '' });
    show('Kaynak eklendi ✓');
  }

  function adjust(id: string, delta: number) {
    setResList(l => l.map(r => r.id === id ? { ...r, progress: Math.max(0, Math.min(r.total, r.progress + delta)) } : r));
  }

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {toast}
      <div>
        <h1 className="page-title">Kaynaklar</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Kitap, soru bankası ve deneme takibi</p>
      </div>

      {/* Genel İlerleme */}
      <div className="card tape-accent" style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
        <div>
          <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(15,27,45,0.4)' }}>Genel İlerleme</p>
          <span className="metric-value" style={{ fontSize: 48, fontWeight: 700, lineHeight: 1 }}>
            <AnimatedNumber value={pct(totalProgress, totalTotal)} />%
          </span>
          <p style={{ fontSize: 13, color: 'rgba(15,27,45,0.5)', marginTop: 4 }}>{totalProgress} / {totalTotal} tamamlandı</p>
        </div>
        <div style={{ flex: 1 }}><ProgressBar pct={pct(totalProgress, totalTotal)} color="#E4BB60" /></div>
      </div>

      {/* Add form */}
      <Card>
        <h3 className="section-title" style={{ marginBottom: 16, fontSize: 16 }}>Kaynak Ekle</h3>
        <form onSubmit={addResource} style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr auto', gap: 10, alignItems: 'flex-end' }}>
          <FormGroup><Label>Kaynak Adı *</Label><Input placeholder="Palme TYT Mat." value={form.name} onChange={e => setForm(f => ({...f, name: e.target.value}))} required /></FormGroup>
          <FormGroup><Label>Tür</Label><Select value={form.type} onChange={e => setForm(f => ({...f, type: e.target.value}))}>{types.map(t => <option key={t}>{t}</option>)}</Select></FormGroup>
          <FormGroup><Label>Toplam *</Label><Input type="number" min={1} placeholder="320" value={form.total} onChange={e => setForm(f => ({...f, total: e.target.value}))} required /></FormGroup>
          <FormGroup><Label>Bitiş Hedefi</Label><Input type="date" value={form.endDate} onChange={e => setForm(f => ({...f, endDate: e.target.value}))} /></FormGroup>
          <Btn variant="primary" type="submit" size="sm"><Icon name="plus" size={14} /> Ekle</Btn>
        </form>
      </Card>

      {/* Resources list */}
      <Card>
        <h3 className="section-title" style={{ marginBottom: 16, fontSize: 16 }}>Kaynaklarım</h3>
        {resList.length === 0 ? (
          <EmptyState icon="📚" title="Henüz kaynak yok" desc="Kitap, soru bankası veya deneme ekleyerek başla." />
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {resList.map(r => {
              const remaining = daysLeft(r.endDate);
              const p = pct(r.progress, r.total);
              const over = remaining < 0;
              const done = p >= 100;
              return (
                <div key={r.id} style={{ borderBottom: '1px solid rgba(15,27,45,0.07)', paddingBottom: 16 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                    <div>
                      <span style={{ fontSize: 14, fontWeight: 600 }}>{r.name}</span>
                      <Badge variant="gray" key="type">{r.type}</Badge>
                      {over && <Badge variant="brick">Gecikmiş</Badge>}
                      {done && <Badge variant="teal">Bitti ✓</Badge>}
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <button className="btn btn-ghost btn-sm" onClick={() => adjust(r.id, -1)}>−</button>
                      <span className="tabular" style={{ fontSize: 14, fontWeight: 600, minWidth: 60, textAlign: 'center' }}>
                        {r.progress} / {r.total}
                      </span>
                      <button className="btn btn-ghost btn-sm" onClick={() => adjust(r.id, 1)}>+</button>
                      <button className="btn btn-danger btn-sm" onClick={() => setResList(l => l.filter(x => x.id !== r.id))}><Icon name="trash" size={14} /></button>
                    </div>
                  </div>
                  <ProgressBar pct={p} color={over ? '#C4503A' : done ? '#2A9D8F' : '#E4BB60'} />
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6, fontSize: 12, color: 'rgba(15,27,45,0.45)' }}>
                    <span>{p}% tamamlandı</span>
                    <span style={{ color: over ? '#C4503A' : 'rgba(15,27,45,0.45)' }}>
                      {over ? `${Math.abs(remaining)} gün gecikmiş` : `${remaining} gün kaldı`}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>
    </div>
  );
}

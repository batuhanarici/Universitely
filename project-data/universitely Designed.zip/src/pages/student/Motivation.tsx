import { AnimatedNumber, ProgressBar, Badge } from '../../components/ui';
import { badges } from '../../lib/mockData';

export default function StudentMotivation() {
  const earned = badges.filter(b => b.earned);
  const streak = 7;

  const streakMsg = streak >= 7
    ? 'Bir haftayı tamamladın! Ritmin çok güçlü. 🔥'
    : streak >= 3
    ? 'Harika bir seri! Devam et.'
    : 'Her gün çalış, seriyi büyüt!';

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div>
        <h1 className="page-title">Motivasyon</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Seriler ve başarı rozetleri</p>
      </div>

      {/* Seri + İstatistikler */}
      <div className="grid-3">
        <div className="card tape-accent" style={{ textAlign: 'center', padding: '24px 16px' }}>
          <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(15,27,45,0.4)', marginBottom: 8 }}>Günlük Seri</p>
          <div style={{ fontSize: 60, fontWeight: 700, fontFamily: 'var(--font-display)', color: '#E4BB60', lineHeight: 1 }}>
            <AnimatedNumber value={streak} />
          </div>
          <p style={{ fontSize: 12, color: 'rgba(15,27,45,0.5)', marginTop: 8 }}>gün kesintisiz</p>
          <p style={{ fontSize: 12, color: '#0F1B2D', fontWeight: 500, marginTop: 8 }}>{streakMsg}</p>
        </div>
        <div className="card" style={{ textAlign: 'center', padding: '24px 16px' }}>
          <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(15,27,45,0.4)', marginBottom: 8 }}>Toplam Çalışma</p>
          <div className="metric-value" style={{ fontSize: 40, fontWeight: 700, color: '#0F1B2D', lineHeight: 1 }}>
            31<span style={{ fontSize: 20, fontWeight: 500, color: 'rgba(15,27,45,0.5)' }}> saat</span>
          </div>
        </div>
        <div className="card" style={{ textAlign: 'center', padding: '24px 16px' }}>
          <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(15,27,45,0.4)', marginBottom: 8 }}>Kazanılan Rozet</p>
          <div className="metric-value" style={{ fontSize: 40, fontWeight: 700, color: '#E4BB60', lineHeight: 1 }}>
            <AnimatedNumber value={earned.length} />
          </div>
        </div>
      </div>

      {/* Rozetler */}
      <div className="card">
        <h3 className="section-title" style={{ marginBottom: 20 }}>Rozetlerim</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: 12 }}>
          {badges.map(b => (
            <div key={b.id} className="anim-stamp" style={{
              border: `1.5px solid ${b.earned ? 'rgba(228,187,96,0.4)' : 'rgba(15,27,45,0.1)'}`,
              borderRadius: 10,
              padding: '14px 12px',
              background: b.earned ? 'rgba(228,187,96,0.06)' : 'rgba(15,27,45,0.02)',
              position: 'relative',
              opacity: b.earned ? 1 : 0.6,
            }}>
              {b.isNew && (
                <span style={{ position: 'absolute', top: 8, right: 8, background: '#C4503A', color: '#fff', fontSize: 9, fontWeight: 700, padding: '2px 5px', borderRadius: 4, letterSpacing: '0.06em' }}>YENİ</span>
              )}
              {!b.earned && (
                <span style={{ position: 'absolute', top: 8, right: 8, fontSize: 12 }}>🔒</span>
              )}
              <div style={{ fontSize: 28, marginBottom: 8 }}>{b.icon}</div>
              <p style={{ fontSize: 13, fontWeight: 700, color: '#0F1B2D', marginBottom: 2 }}>{b.name}</p>
              <p style={{ fontSize: 11, color: 'rgba(15,27,45,0.5)' }}>{b.desc}</p>
              {!b.earned && 'progress' in b && b.progress !== undefined && (
                <div style={{ marginTop: 8 }}>
                  <ProgressBar pct={Math.round(((b.progress as number) / (b.target as number)) * 100)} color="#E4BB60" />
                  <p style={{ fontSize: 10, color: 'rgba(15,27,45,0.4)', marginTop: 4 }}>{b.progress}/{b.target}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { Card, Badge, ProgressBar, EmptyState, Checkbox, AnimatedNumber } from '../../components/ui';
import { subjects } from '../../lib/mockData';
import { pct } from '../../lib/utils';

export default function StudentSubjects() {
  const [list, setList] = useState(subjects);
  const done = list.filter(s => s.done).length;
  const total = list.length;

  const byLesson: Record<string, typeof list> = {};
  list.forEach(s => { (byLesson[s.lesson] = byLesson[s.lesson] || []).push(s); });
  const weak = list.filter(s => !s.done && s.weak);

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div>
        <h1 className="page-title">Konular</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Konuları tamamlandı olarak işaretle</p>
      </div>

      {/* Progress hero */}
      <div className="card tape-accent" style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
        <div>
          <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(15,27,45,0.4)' }}>Genel İlerleme</p>
          <span className="metric-value" style={{ fontSize: 48, fontWeight: 700, color: '#0F1B2D', lineHeight: 1 }}>
            <AnimatedNumber value={pct(done, total)} />%
          </span>
          <p style={{ fontSize: 13, color: 'rgba(15,27,45,0.5)', marginTop: 4 }}>{done} / {total} konu tamamlandı</p>
        </div>
        <div style={{ flex: 1 }}>
          <ProgressBar pct={pct(done, total)} color="#2A9D8F" />
        </div>
      </div>

      {/* Weak subjects */}
      {weak.length > 0 && (
        <Card>
          <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Eksik / Ağırlık Verilmesi Gerekenler</h3>
          <div className="rule-lines" style={{ borderRadius: 8, overflow: 'hidden' }}>
            {weak.map(s => (
              <label key={s.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '9px 12px', cursor: 'pointer' }}>
                <Checkbox checked={s.done} onChange={() => setList(l => l.map(x => x.id === s.id ? { ...x, done: !x.done } : x))} />
                <span style={{ flex: 1, fontSize: 13 }}>{s.name}</span>
                <Badge variant="gray">{s.lesson}</Badge>
                <Badge variant="brick">Zayıf</Badge>
              </label>
            ))}
          </div>
        </Card>
      )}

      {/* By lesson */}
      {Object.entries(byLesson).map(([lesson, lessonSubjects]) => {
        const lessonDone = lessonSubjects.filter(s => s.done).length;
        return (
          <Card key={lesson}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <h3 className="section-title" style={{ marginBottom: 0, fontSize: 16 }}>{lesson}</h3>
              <span className="tabular" style={{ fontSize: 13, color: 'rgba(15,27,45,0.5)' }}>{lessonDone}/{lessonSubjects.length}</span>
            </div>
            <ProgressBar pct={pct(lessonDone, lessonSubjects.length)} color="#E4BB60" className="mb-3" />
            <div className="rule-lines" style={{ borderRadius: 8, overflow: 'hidden', marginTop: 10 }}>
              {lessonSubjects.map(s => (
                <label key={s.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '9px 12px', cursor: 'pointer' }}>
                  <Checkbox checked={s.done} onChange={() => setList(l => l.map(x => x.id === s.id ? { ...x, done: !x.done } : x))} />
                  <span style={{ flex: 1, fontSize: 13, textDecoration: s.done ? 'line-through' : 'none', color: s.done ? 'rgba(15,27,45,0.35)' : '#0F1B2D' }}>
                    {s.done ? '✓ ' : ''}{s.name}
                  </span>
                  {s.weak && <Badge variant="brick">Zayıf</Badge>}
                </label>
              ))}
            </div>
          </Card>
        );
      })}
    </div>
  );
}

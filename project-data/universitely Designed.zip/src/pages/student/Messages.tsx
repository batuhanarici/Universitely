import { useState, useRef, useEffect } from 'react';
import { Card, Btn, Input } from '../../components/ui';
import { messages as initial } from '../../lib/mockData';

export default function StudentMessages() {
  const [msgs, setMsgs] = useState(initial);
  const [text, setText] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [msgs]);

  function send(e: React.FormEvent) {
    e.preventDefault();
    if (!text.trim()) return;
    setMsgs(m => [...m, { id: Date.now().toString(), from: 'student', text: text.trim(), time: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }), read: true }]);
    setText('');
  }

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div>
        <h1 className="page-title">Mesajlar</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Koçunla birebir sohbet</p>
      </div>

      <Card style={{ display: 'flex', flexDirection: 'column', height: 480 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16, paddingBottom: 14, borderBottom: '1px solid rgba(15,27,45,0.08)' }}>
          <div style={{ width: 36, height: 36, borderRadius: '50%', background: '#0F1B2D', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#E4BB60', fontWeight: 700 }}>K</div>
          <div>
            <p style={{ fontSize: 14, fontWeight: 600 }}>Koç Ahmet</p>
            <p style={{ fontSize: 11, color: 'rgba(15,27,45,0.4)' }}>Çevrimiçi</p>
          </div>
        </div>

        <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 12, paddingRight: 4 }}>
          {msgs.map(m => (
            <div key={m.id} style={{ display: 'flex', flexDirection: m.from === 'student' ? 'row-reverse' : 'row', alignItems: 'flex-end', gap: 8 }}>
              {m.from !== 'student' && (
                <div style={{ width: 28, height: 28, borderRadius: '50%', background: '#0F1B2D', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#E4BB60', fontSize: 12, fontWeight: 700, flexShrink: 0 }}>K</div>
              )}
              <div>
                <div className={m.from === 'student' ? 'bubble-self' : 'bubble-other'}>{m.text}</div>
                <p style={{ fontSize: 10, color: 'rgba(15,27,45,0.35)', marginTop: 3, textAlign: m.from === 'student' ? 'right' : 'left' }}>{m.time}</p>
              </div>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        <form onSubmit={send} style={{ display: 'flex', gap: 8, marginTop: 14, paddingTop: 14, borderTop: '1px solid rgba(15,27,45,0.08)' }}>
          <Input placeholder="Mesaj yaz…" value={text} onChange={e => setText(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(e as any); }}} style={{ flex: 1 }} />
          <Btn variant="primary" type="submit">Gönder</Btn>
        </form>
      </Card>
    </div>
  );
}

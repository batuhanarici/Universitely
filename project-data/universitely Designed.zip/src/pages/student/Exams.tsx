import { useState } from 'react';
import { Card, Badge, Btn } from '../../components/ui';
import { exams } from '../../lib/mockData';
import { formatDate, downloadCSV } from '../../lib/utils';

const types = ['Tümü', 'TYT', 'AYT', 'Branş'];

export default function StudentExams() {
  const [filter, setFilter] = useState('Tümü');
  const filtered = filter === 'Tümü' ? exams : exams.filter(e => e.type === filter);

  function exportCSV() {
    downloadCSV('denemeler', ['Deneme', 'Ders', 'Tarih', 'Doğru', 'Yanlış', 'Boş', 'Net'],
      filtered.map(e => [e.name, e.subject, e.date, String(e.correct), String(e.wrong), String(e.empty), String(e.net)]));
  }

  const badgeVariant: Record<string, 'gold' | 'teal' | 'gray'> = { TYT: 'gold', AYT: 'teal', Branş: 'gray' };

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div>
          <h1 className="page-title">Denemeler</h1>
          <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Tüm deneme sonuçları</p>
        </div>
        <Btn variant="ghost" onClick={exportCSV} size="sm">CSV İndir</Btn>
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: 8 }}>
        {types.map(t => (
          <button key={t}
            onClick={() => setFilter(t)}
            style={{ padding: '6px 14px', borderRadius: 8, border: filter === t ? '1.5px solid #E4BB60' : '1.5px solid rgba(15,27,45,0.15)', background: filter === t ? 'rgba(228,187,96,0.12)' : 'transparent', fontFamily: 'var(--font-body)', fontSize: 12, fontWeight: 600, color: filter === t ? '#A07C20' : '#0F1B2D', cursor: 'pointer' }}>
            {t}
          </button>
        ))}
      </div>

      <Card>
        <table className="data-table">
          <thead>
            <tr><th>Deneme</th><th>Tür</th><th>Ders</th><th>Tarih</th><th>D</th><th>Y</th><th>B</th><th>Net</th></tr>
          </thead>
          <tbody>
            {[...filtered].sort((a,b) => b.date.localeCompare(a.date)).map(e => (
              <tr key={e.id}>
                <td style={{ fontWeight: 500 }}>{e.name}</td>
                <td><Badge variant={badgeVariant[e.type] || 'gray'}>{e.type}</Badge></td>
                <td style={{ fontSize: 12, color: 'rgba(15,27,45,0.6)' }}>{e.subject}</td>
                <td style={{ fontSize: 12, color: 'rgba(15,27,45,0.6)' }}>{formatDate(e.date)}</td>
                <td className="tabular" style={{ color: '#2A9D8F', fontWeight: 600 }}>{e.correct}</td>
                <td className="tabular" style={{ color: '#C4503A', fontWeight: 600 }}>{e.wrong}</td>
                <td className="tabular" style={{ color: '#9A9FA8', fontWeight: 600 }}>{e.empty}</td>
                <td>
                  <span className="metric-value" style={{ fontSize: 18, fontWeight: 700, color: '#0F1B2D' }}>{e.net}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

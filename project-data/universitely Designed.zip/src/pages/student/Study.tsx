import { useState, useEffect, useRef } from 'react';
import { BarChart, Bar, XAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { Card, Btn, Input, Label, FormGroup, useToast } from '../../components/ui';
import { studySessions, weeklyStudyData } from '../../lib/mockData';
import { Icon } from '../../components/Layout';

const POMODORO = 25 * 60;

export default function StudentStudy() {
  const { toast, show } = useToast();
  const [sessions, setSessions] = useState(studySessions);
  const [timeLeft, setTimeLeft] = useState(POMODORO);
  const [running, setRunning] = useState(false);
  const [done, setDone] = useState(false);
  const interval = useRef<ReturnType<typeof setInterval> | null>(null);

  const [form, setForm] = useState({ duration: '', questions: '', note: '' });

  useEffect(() => {
    if (running) {
      interval.current = setInterval(() => {
        setTimeLeft(t => {
          if (t <= 1) {
            clearInterval(interval.current!);
            setRunning(false);
            setDone(true);
            setSessions(s => [{ id: Date.now().toString(), date: new Date().toISOString().slice(0,10), duration: 25, questions: 0, subject: '', note: 'Pomodoro' }, ...s]);
            show('25 dakika tamamlandı! Çalışma kaydedildi. 🎉');
            return POMODORO;
          }
          return t - 1;
        });
      }, 1000);
    } else {
      clearInterval(interval.current!);
    }
    return () => clearInterval(interval.current!);
  }, [running]);

  const mins = String(Math.floor(timeLeft / 60)).padStart(2, '0');
  const secs = String(timeLeft % 60).padStart(2, '0');
  const pctDone = ((POMODORO - timeLeft) / POMODORO) * 100;
  const r = 56, circ = 2 * Math.PI * r;

  function addSession(e: React.FormEvent) {
    e.preventDefault();
    if (!form.duration) return;
    setSessions(s => [{ id: Date.now().toString(), date: new Date().toISOString().slice(0,10), duration: +form.duration, questions: +form.questions || 0, subject: '', note: form.note }, ...s]);
    setForm({ duration: '', questions: '', note: '' });
    show('Çalışma kaydedildi ✓');
  }

  const totalMins7 = weeklyStudyData.reduce((a, d) => a + d.minutes, 0);
  const totalQ7 = weeklyStudyData.reduce((a, d) => a + d.questions, 0);

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {toast}
      <div>
        <h1 className="page-title">Çalışma</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Pomodoro zamanlayıcı ve çalışma geçmişi</p>
      </div>

      <div className="grid-2">
        {/* Pomodoro */}
        <Card className="tape-accent" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16, padding: '28px 20px' }}>
          <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(15,27,45,0.4)' }}>Pomodoro Zamanlayıcı</p>
          <svg width={140} height={140} style={{ transform: 'rotate(-90deg)' }}>
            <circle cx={70} cy={70} r={r} fill="none" stroke="rgba(15,27,45,0.08)" strokeWidth={8} />
            <circle cx={70} cy={70} r={r} fill="none" stroke={done ? '#2A9D8F' : '#E4BB60'} strokeWidth={8}
              strokeDasharray={circ} strokeDashoffset={circ * (1 - pctDone / 100)}
              strokeLinecap="round" style={{ transition: 'stroke-dashoffset 0.9s linear' }} />
            <text x={70} y={74} textAnchor="middle" dominantBaseline="middle"
              style={{ fill: '#0F1B2D', fontFamily: 'var(--font-mono)', fontSize: 28, fontWeight: 600, transform: 'rotate(90deg)', transformOrigin: '70px 70px' }}>
              {mins}:{secs}
            </text>
          </svg>
          <p style={{ fontSize: 12, fontWeight: 600, color: running ? '#2A9D8F' : 'rgba(15,27,45,0.4)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>
            {done ? '✓ Tamamlandı' : running ? 'Çalışılıyor…' : 'Hazır'}
          </p>
          <div style={{ display: 'flex', gap: 8 }}>
            <Btn variant="primary" onClick={() => { setRunning(r => !r); setDone(false); }}>
              {running ? 'Duraklat' : done ? 'Tekrar Başlat' : 'Başlat'}
            </Btn>
            <Btn variant="ghost" onClick={() => { setRunning(false); setTimeLeft(POMODORO); setDone(false); }}>Sıfırla</Btn>
          </div>
        </Card>

        {/* Çalışma Ekle */}
        <Card>
          <h3 className="section-title" style={{ marginBottom: 16, fontSize: 16 }}>Çalışma Ekle</h3>
          <form onSubmit={addSession} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <FormGroup>
              <Label>Süre (dk) *</Label>
              <Input type="number" min={1} placeholder="45" value={form.duration} onChange={e => setForm(f => ({ ...f, duration: e.target.value }))} required />
            </FormGroup>
            <FormGroup>
              <Label>Çözülen Soru Sayısı</Label>
              <Input type="number" min={0} placeholder="0" value={form.questions} onChange={e => setForm(f => ({ ...f, questions: e.target.value }))} />
            </FormGroup>
            <FormGroup>
              <Label>Not</Label>
              <Input placeholder="Konu veya açıklama" value={form.note} onChange={e => setForm(f => ({ ...f, note: e.target.value }))} />
            </FormGroup>
            <Btn variant="primary" type="submit">Kaydet</Btn>
          </form>
        </Card>
      </div>

      {/* Son 7 Gün */}
      <Card>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
          <h3 className="section-title" style={{ marginBottom: 0, fontSize: 16 }}>Son 7 Gün</h3>
          <div style={{ display: 'flex', gap: 20, textAlign: 'right' }}>
            <div>
              <p style={{ fontSize: 11, color: 'rgba(15,27,45,0.4)', fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase' }}>Toplam</p>
              <p className="metric-value" style={{ fontSize: 22, fontWeight: 700 }}>{Math.round(totalMins7 / 60)}h {totalMins7 % 60}dk</p>
            </div>
            <div>
              <p style={{ fontSize: 11, color: 'rgba(15,27,45,0.4)', fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase' }}>Soru</p>
              <p className="metric-value" style={{ fontSize: 22, fontWeight: 700 }}>{totalQ7}</p>
            </div>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={140}>
          <BarChart data={weeklyStudyData} barSize={28}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(15,27,45,0.06)" />
            <XAxis dataKey="day" tick={{ fontSize: 11, fill: 'rgba(15,27,45,0.4)' }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ background: '#0F1B2D', border: 'none', borderRadius: 8, color: '#F4EFE4', fontSize: 12 }} formatter={(v) => [String(v) + ' dk']} />
            <Bar dataKey="minutes" fill="#E4BB60" radius={[3,3,0,0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      {/* Kayıtlar */}
      <Card>
        <h3 className="section-title" style={{ marginBottom: 0, fontSize: 16 }}>Kayıtlar</h3>
        <table className="data-table" style={{ marginTop: 12 }}>
          <thead>
            <tr>
              <th>Tarih</th><th>Süre</th><th>Soru</th><th>Not</th><th></th>
            </tr>
          </thead>
          <tbody>
            {sessions.map(s => (
              <tr key={s.id}>
                <td style={{ fontSize: 12, color: 'rgba(15,27,45,0.5)' }}>{s.date}</td>
                <td className="tabular" style={{ fontWeight: 600 }}>{s.duration} dk</td>
                <td className="tabular">{s.questions || '—'}</td>
                <td style={{ color: 'rgba(15,27,45,0.6)', fontSize: 12 }}>{s.note || '—'}</td>
                <td>
                  <button className="btn btn-danger btn-sm" onClick={() => setSessions(list => list.filter(x => x.id !== s.id))}>
                    <Icon name="trash" size={14} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

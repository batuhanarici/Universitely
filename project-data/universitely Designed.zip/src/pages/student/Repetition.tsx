import { useState } from 'react';
import { Card, Btn, Input, Label, FormGroup, Checkbox, Badge, EmptyState, useToast } from '../../components/ui';
import { repetitionPlan as initial } from '../../lib/mockData';
import { relativeDate } from '../../lib/utils';
import { Icon } from '../../components/Layout';

export default function StudentRepetition() {
  const { toast, show } = useToast();
  const [plan, setPlan] = useState(initial);
  const [form, setForm] = useState({ desc: '', date: new Date().toISOString().slice(0,10) });

  const today = '2024-01-28';
  const todayReps = plan.filter(r => !r.done && r.date === today);
  const future = plan.filter(r => !r.done && r.date !== today);
  const done = plan.filter(r => r.done);

  function add(e: React.FormEvent) {
    e.preventDefault();
    if (!form.desc) return;
    setPlan(l => [...l, { id: Date.now().toString(), desc: form.desc, date: form.date, done: false }]);
    setForm(f => ({ ...f, desc: '' }));
    show('Tekrar planına eklendi ✓');
  }
  function toggle(id: string) { setPlan(l => l.map(x => x.id === id ? { ...x, done: !x.done } : x)); show('Kaydedildi ✓'); }
  function del(id: string) { setPlan(l => l.filter(x => x.id !== id)); }

  function RepItem({ r }: { r: typeof plan[0] }) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px' }}>
        <Checkbox checked={r.done} onChange={() => toggle(r.id)} />
        <span style={{ flex: 1, fontSize: 13, textDecoration: r.done ? 'line-through' : 'none', color: r.done ? 'rgba(15,27,45,0.35)' : '#0F1B2D' }}>{r.desc}</span>
        <span style={{ fontSize: 11, color: 'rgba(15,27,45,0.4)' }}>{relativeDate(r.date)}</span>
        <button className="btn btn-danger btn-sm" onClick={() => del(r.id)}><Icon name="trash" size={13} /></button>
      </div>
    );
  }

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {toast}
      <div>
        <h1 className="page-title">Tekrar Planı</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Aralıklı tekrar planla ve tamamla</p>
      </div>

      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Yeni Tekrar Ekle</h3>
        <form onSubmit={add} style={{ display: 'flex', gap: 10, alignItems: 'flex-end' }}>
          <FormGroup style={{ flex: 1 }}><Label>Konu / Soru Açıklaması *</Label><Input placeholder="Fonksiyonlar — TYT q.12" value={form.desc} onChange={e => setForm(f => ({...f, desc: e.target.value}))} required /></FormGroup>
          <FormGroup><Label>Tarih</Label><Input type="date" value={form.date} onChange={e => setForm(f => ({...f, date: e.target.value}))} /></FormGroup>
          <Btn variant="primary" type="submit" size="sm"><Icon name="plus" size={14} /> Ekle</Btn>
        </form>
      </Card>

      <Card>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <h3 className="section-title" style={{ marginBottom: 0, fontSize: 16 }}>Bugün</h3>
          <Badge variant={todayReps.length > 0 ? 'brick' : 'teal'}>{todayReps.length} bekliyor</Badge>
        </div>
        {todayReps.length === 0 ? (
          <EmptyState icon="✅" title="Bugünkü tekrarlar tamam!" desc="Yarın için plan hazırla." />
        ) : (
          <div className="rule-lines" style={{ borderRadius: 8, overflow: 'hidden' }}>
            {todayReps.map(r => <RepItem key={r.id} r={r} />)}
          </div>
        )}
      </Card>

      {future.length > 0 && (
        <Card>
          <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Gelecek Tekrarlar</h3>
          <div className="rule-lines" style={{ borderRadius: 8, overflow: 'hidden' }}>
            {future.map(r => <RepItem key={r.id} r={r} />)}
          </div>
        </Card>
      )}

      {done.length > 0 && (
        <Card>
          <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Tamamlananlar</h3>
          <div className="rule-lines" style={{ borderRadius: 8, overflow: 'hidden', opacity: 0.6 }}>
            {done.map(r => <RepItem key={r.id} r={r} />)}
          </div>
        </Card>
      )}
    </div>
  );
}

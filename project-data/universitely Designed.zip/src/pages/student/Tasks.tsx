import { useState } from 'react';
import { Card, Btn, Input, Label, FormGroup, Select, Badge, Checkbox, EmptyState, useToast } from '../../components/ui';
import { tasks as initialTasks } from '../../lib/mockData';
import { relativeDate } from '../../lib/utils';
import { Icon } from '../../components/Layout';

export default function StudentTasks() {
  const { toast, show } = useToast();
  const [tasks, setTasks] = useState(initialTasks);
  const [form, setForm] = useState({ title: '', date: new Date().toISOString().slice(0,10), type: 'daily' });

  const today = new Date().toISOString().slice(0,10);
  const todayTasks = tasks.filter(t => !t.fromCoach && t.type === 'daily' && t.date === today);
  const otherDaily = tasks.filter(t => !t.fromCoach && t.type === 'daily' && t.date !== today);
  const weekly = tasks.filter(t => !t.fromCoach && t.type === 'weekly');
  const coachTasks = tasks.filter(t => t.fromCoach);

  function addTask(e: React.FormEvent) {
    e.preventDefault();
    if (!form.title) return;
    setTasks(l => [...l, { id: Date.now().toString(), title: form.title, date: form.date, type: form.type, done: false, fromCoach: false }]);
    setForm(f => ({ ...f, title: '' }));
    show('Görev eklendi ✓');
  }
  function toggle(id: string) { setTasks(l => l.map(x => x.id === id ? { ...x, done: !x.done } : x)); }
  function del(id: string) { setTasks(l => l.filter(x => x.id !== id)); }

  const todayDone = todayTasks.filter(t => t.done).length;

  function TaskItem({ t, canDelete = true }: { t: typeof tasks[0]; canDelete?: boolean }) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 0', borderBottom: '1px solid rgba(15,27,45,0.06)' }}>
        <Checkbox checked={t.done} onChange={() => toggle(t.id)} />
        <span style={{ flex: 1, fontSize: 13, textDecoration: t.done ? 'line-through' : 'none', color: t.done ? 'rgba(15,27,45,0.35)' : '#0F1B2D' }}>{t.title}</span>
        <span style={{ fontSize: 11, color: 'rgba(15,27,45,0.4)' }}>{relativeDate(t.date)}</span>
        {t.fromCoach && (
          <Badge variant={t.approved ? 'teal' : 'gold'}>{t.approved ? '✓ Onaylandı' : 'Onay bekleniyor'}</Badge>
        )}
        {canDelete && (
          <button className="btn btn-danger btn-sm" style={{ opacity: 0 }} onMouseEnter={e => (e.currentTarget.style.opacity = '1')} onMouseLeave={e => (e.currentTarget.style.opacity = '0')} onClick={() => del(t.id)}>
            <Icon name="trash" size={13} />
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="anim-stagger" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {toast}
      <div>
        <h1 className="page-title">Görevler</h1>
        <p style={{ color: 'rgba(15,27,45,0.5)', fontSize: 14, marginTop: 4 }}>Kişisel ve koç görevleri</p>
      </div>

      {/* New task */}
      <Card>
        <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Yeni Görev</h3>
        <form onSubmit={addTask} style={{ display: 'grid', gridTemplateColumns: '3fr 1fr 1fr auto', gap: 10, alignItems: 'flex-end' }}>
          <FormGroup><Label>Görev Başlığı *</Label><Input placeholder="Matematik soru çöz" value={form.title} onChange={e => setForm(f => ({...f, title: e.target.value}))} required /></FormGroup>
          <FormGroup><Label>Tarih</Label><Input type="date" value={form.date} onChange={e => setForm(f => ({...f, date: e.target.value}))} /></FormGroup>
          <FormGroup><Label>Tip</Label><Select value={form.type} onChange={e => setForm(f => ({...f, type: e.target.value}))}><option value="daily">Günlük</option><option value="weekly">Haftalık</option></Select></FormGroup>
          <Btn variant="primary" type="submit" size="sm"><Icon name="plus" size={14} /> Ekle</Btn>
        </form>
      </Card>

      {/* Koç'tan görevler */}
      {coachTasks.length > 0 && (
        <Card className="tape-accent">
          <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Koçtan Görevler</h3>
          {coachTasks.map(t => (
            <div key={t.id}>
              <TaskItem t={t} canDelete={false} />
              {t.coachFeedback && (
                <div style={{ marginLeft: 26, padding: '6px 10px', background: 'rgba(228,187,96,0.1)', borderRadius: 6, fontSize: 12, color: '#0F1B2D', marginBottom: 4 }}>
                  💬 Koçundan: {t.coachFeedback}
                </div>
              )}
            </div>
          ))}
        </Card>
      )}

      {/* Bugün */}
      <Card>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
          <h3 className="section-title" style={{ marginBottom: 0, fontSize: 16 }}>Bugün</h3>
          <Badge variant="ink">{todayDone}/{todayTasks.length} tamamlandı</Badge>
        </div>
        {todayTasks.length === 0 ? <p style={{ fontSize: 13, color: 'rgba(15,27,45,0.45)', fontStyle: 'italic' }}>Bugün için görev yok.</p> : todayTasks.map(t => <TaskItem key={t.id} t={t} />)}
      </Card>

      {/* Other daily */}
      {otherDaily.length > 0 && (
        <Card>
          <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Tüm Günlük Görevler</h3>
          {otherDaily.map(t => <TaskItem key={t.id} t={t} />)}
        </Card>
      )}

      {/* Weekly */}
      {weekly.length > 0 && (
        <Card>
          <h3 className="section-title" style={{ marginBottom: 14, fontSize: 16 }}>Haftalık Hedefler</h3>
          {weekly.map(t => <TaskItem key={t.id} t={t} />)}
        </Card>
      )}
    </div>
  );
}

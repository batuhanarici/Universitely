import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Btn, Input, Label, FormGroup, Tabs } from '../components/ui';

export default function AuthPage() {
  const navigate = useNavigate();
  const [tab, setTab] = useState('Giriş Yap');
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState('');
  const [form, setForm] = useState({ email: '', password: '', name: '', code: '' });

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm(f => ({ ...f, [k]: e.target.value }));

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setMsg('');
    setTimeout(() => {
      setLoading(false);
      if (tab === 'Giriş Yap') {
        if (form.email.includes('coach')) navigate('/coach/dashboard');
        else if (form.email.includes('veli')) navigate('/parent/overview');
        else navigate('/student/dashboard');
      } else if (tab === 'Öğrenci Kaydı') {
        if (!form.code) { setMsg('error:Davet kodu gereklidir.'); return; }
        if (form.code !== 'DEMO123') { setMsg('error:Geçersiz davet kodu.'); return; }
        setMsg('success:Kayıt oluşturuldu! Koçuna otomatik bağlanacaksın.');
        setTimeout(() => setTab('Giriş Yap'), 2000);
      } else {
        if (!form.code) { setMsg('error:Bağlantı kodu gereklidir.'); return; }
        setMsg('success:Çocuğunun hesabına bağlanacaksın.');
        setTimeout(() => setTab('Giriş Yap'), 2000);
      }
    }, 800);
  }

  const isError = msg.startsWith('error:');
  const msgText = msg.replace(/^(error|success):/, '');

  return (
    <div style={{ minHeight: '100vh', background: '#F4EFE4', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
      {/* Background rule lines */}
      <div style={{ position: 'fixed', inset: 0, pointerEvents: 'none', backgroundImage: 'repeating-linear-gradient(to bottom, transparent, transparent 31px, rgba(15,27,45,0.05) 31px, rgba(15,27,45,0.05) 32px)', backgroundSize: '100% 32px' }} />

      <div className="anim-slide" style={{ width: '100%', maxWidth: 420, position: 'relative', zIndex: 1 }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 40 }}>
          <div style={{ width: 48, height: 48, background: '#0F1B2D', borderRadius: 12, margin: '0 auto 16px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#E4BB60" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 2l1.5 4.5L18 8l-4.5 1.5L12 14l-1.5-4.5L6 8l4.5-1.5z"/>
              <circle cx="12" cy="18" r="3"/>
            </svg>
          </div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 32, fontWeight: 700, color: '#0F1B2D', letterSpacing: '-0.03em', marginBottom: 6 }}>Universitely</h1>
          <p style={{ fontSize: 13, color: 'rgba(15,27,45,0.5)' }}>TYT/AYT sınavına giden yolunuz</p>
        </div>

        <div className="card" style={{ borderRadius: 14 }}>
          <Tabs tabs={['Giriş Yap', 'Öğrenci Kaydı', 'Veli Kaydı']} active={tab} onChange={t => { setTab(t); setMsg(''); }} />

          <form onSubmit={submit} style={{ marginTop: 24, display: 'flex', flexDirection: 'column', gap: 14 }}>
            {(tab === 'Öğrenci Kaydı' || tab === 'Veli Kaydı') && (
              <FormGroup>
                <Label>Ad Soyad</Label>
                <Input placeholder="Adınız Soyadınız" value={form.name} onChange={set('name')} required />
              </FormGroup>
            )}
            <FormGroup>
              <Label>E-posta</Label>
              <Input type="email" placeholder="ornek@mail.com" value={form.email} onChange={set('email')} required />
            </FormGroup>
            <FormGroup>
              <Label>Şifre</Label>
              <Input type="password" placeholder="••••••••" value={form.password} onChange={set('password')} required />
            </FormGroup>
            {tab === 'Öğrenci Kaydı' && (
              <FormGroup>
                <Label>Davet Kodu</Label>
                <Input placeholder="Koçunuzdan alınan kod (örn: DEMO123)" value={form.code} onChange={set('code')} required />
              </FormGroup>
            )}
            {tab === 'Veli Kaydı' && (
              <FormGroup>
                <Label>Bağlantı Kodu</Label>
                <Input placeholder="Koçtan veya çocuğunuzdan alınan kod" value={form.code} onChange={set('code')} required />
              </FormGroup>
            )}

            {msgText && (
              <p style={{ fontSize: 13, color: isError ? '#C4503A' : '#2A9D8F', fontWeight: 500 }}>{msgText}</p>
            )}

            <Btn variant="primary" type="submit" disabled={loading} style={{ marginTop: 4, width: '100%' }}>
              {loading ? 'Gönderiliyor…' : tab}
            </Btn>
          </form>
        </div>

        {/* Demo links */}
        <div style={{ marginTop: 20, textAlign: 'center', display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
          <button className="btn btn-ghost btn-sm" onClick={() => navigate('/student/dashboard')}>👨‍🎓 Öğrenci Demo</button>
          <button className="btn btn-ghost btn-sm" onClick={() => navigate('/coach/dashboard')}>👨‍🏫 Koç Demo</button>
          <button className="btn btn-ghost btn-sm" onClick={() => navigate('/parent/overview')}>👪 Veli Demo</button>
        </div>
        <p style={{ textAlign: 'center', fontSize: 11, color: 'rgba(15,27,45,0.35)', marginTop: 12 }}>Demo için doğrudan panel butonlarını kullanın</p>
      </div>
    </div>
  );
}

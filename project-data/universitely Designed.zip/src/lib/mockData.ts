// Mock data for Universitely demo

export const students = [
  { id: '1', name: 'Arda Kaya', active: true, avgNet: 67.5, weakestSubject: 'Türkçe (%38)', parentCode: 'VEL-1234' },
  { id: '2', name: 'Zeynep Yıldız', active: true, avgNet: 82.3, weakestSubject: 'Kimya (%41)', parentCode: 'VEL-5678' },
  { id: '3', name: 'Can Demir', active: true, avgNet: 54.1, weakestSubject: 'Matematik (%29)', parentCode: 'VEL-9012' },
  { id: '4', name: 'Selin Arslan', active: false, avgNet: 71.0, weakestSubject: 'Fizik (%45)', parentCode: '' },
  { id: '5', name: 'Mert Çelik', active: true, avgNet: 44.8, weakestSubject: 'Biyoloji (%22)', parentCode: 'VEL-3456' },
];

export const exams = [
  { id: 'e1', name: 'TYT Denemesi #1', type: 'TYT', subject: 'Tüm Dersler', date: '2024-01-10', correct: 82, wrong: 18, empty: 20, net: 77.5, templateId: 't1' },
  { id: 'e2', name: 'TYT Denemesi #2', type: 'TYT', subject: 'Tüm Dersler', date: '2024-01-17', correct: 88, wrong: 14, empty: 18, net: 84.5, templateId: 't1' },
  { id: 'e3', name: 'AYT Matematik', type: 'AYT', subject: 'Matematik', date: '2024-01-20', correct: 24, wrong: 8, empty: 8, net: 22.0, templateId: 't2' },
  { id: 'e4', name: 'TYT Denemesi #3', type: 'TYT', subject: 'Tüm Dersler', date: '2024-01-24', correct: 91, wrong: 11, empty: 18, net: 88.25, templateId: 't1' },
  { id: 'e5', name: 'AYT Matematik', type: 'AYT', subject: 'Matematik', date: '2024-01-27', correct: 28, wrong: 6, empty: 6, net: 26.5, templateId: 't2' },
];

export const subjectPerformance = [
  { subject: 'Matematik', correct: 28, wrong: 6, empty: 6, pct: 72 },
  { subject: 'Türkçe', correct: 22, wrong: 8, empty: 10, pct: 55 },
  { subject: 'Fizik', correct: 14, wrong: 5, empty: 6, pct: 56 },
  { subject: 'Kimya', correct: 11, wrong: 6, empty: 8, pct: 44 },
  { subject: 'Biyoloji', correct: 16, wrong: 3, empty: 6, pct: 64 },
  { subject: 'Tarih', correct: 18, wrong: 4, empty: 3, pct: 72 },
  { subject: 'Coğrafya', correct: 13, wrong: 7, empty: 5, pct: 52 },
];

export const tasks = [
  { id: 't1', title: 'Türkçe paragraf soruları çöz (20 soru)', date: '2024-01-28', type: 'daily', done: false, fromCoach: false },
  { id: 't2', title: 'Kümeler konusunu tekrar et', date: '2024-01-28', type: 'daily', done: true, fromCoach: false },
  { id: 't3', title: 'Kimya deney notlarını özetle', date: '2024-01-29', type: 'daily', done: false, fromCoach: true, coachFeedback: '', approved: false },
  { id: 't4', title: 'Bu hafta 5 TYT denemesi çöz', date: '2024-01-28', type: 'weekly', done: false, fromCoach: false },
];

export const wrongQuestions = [
  { id: 'w1', desc: 'Fonksiyon tanımı ve özellikleri', subject: 'Matematik', source: 'Palme TYT', page: 142, qno: 12, solved: false },
  { id: 'w2', desc: 'Paragraf tamamlama sorusu', subject: 'Türkçe', source: 'Bilim Yolu', page: 88, qno: 5, solved: true },
  { id: 'w3', desc: 'Newton\'un hareket yasaları', subject: 'Fizik', source: 'TYT Denemesi #2', page: 0, qno: 23, solved: false },
  { id: 'w4', desc: 'Asit-baz reaksiyonları', subject: 'Kimya', source: 'AYT Kimya', page: 210, qno: 8, solved: false },
  { id: 'w5', desc: 'Logaritma denklemi', subject: 'Matematik', source: 'Palme TYT', page: 198, qno: 3, solved: false },
];

export const repetitionPlan = [
  { id: 'r1', desc: 'Kümeler — TYT q.12 yanlışı', date: '2024-01-28', done: false },
  { id: 'r2', desc: 'Newton yasaları özeti', date: '2024-01-28', done: false },
  { id: 'r3', desc: 'Asit-baz reaksiyon kartları', date: '2024-01-30', done: false },
  { id: 'r4', desc: 'Paragraf türleri tekrarı', date: '2024-02-01', done: true },
];

export const studySessions = [
  { id: 's1', date: '2024-01-28', duration: 90, questions: 45, subject: 'Matematik', note: 'Fonksiyonlar bölümü' },
  { id: 's2', date: '2024-01-27', duration: 60, questions: 30, subject: 'Türkçe', note: '' },
  { id: 's3', date: '2024-01-26', duration: 120, questions: 60, subject: 'Fizik', note: 'Mekanik konusu bitti' },
  { id: 's4', date: '2024-01-25', duration: 45, questions: 20, subject: 'Kimya', note: '' },
  { id: 's5', date: '2024-01-24', duration: 90, questions: 50, subject: 'Matematik', note: 'Türev çalışması' },
  { id: 's6', date: '2024-01-23', duration: 30, questions: 15, subject: 'Biyoloji', note: '' },
  { id: 's7', date: '2024-01-22', duration: 75, questions: 35, subject: 'Tarih', note: '' },
];

export const weeklyStudyData = [
  { day: 'Pzt', minutes: 90, questions: 45 },
  { day: 'Sal', minutes: 60, questions: 30 },
  { day: 'Çar', minutes: 120, questions: 60 },
  { day: 'Per', minutes: 45, questions: 20 },
  { day: 'Cum', minutes: 90, questions: 50 },
  { day: 'Cmt', minutes: 30, questions: 15 },
  { day: 'Paz', minutes: 0, questions: 0 },
];

export const subjects = [
  { id: 'sub1', name: 'Kümeler', lesson: 'Matematik', done: true, weak: false },
  { id: 'sub2', name: 'Fonksiyonlar', lesson: 'Matematik', done: false, weak: true },
  { id: 'sub3', name: 'Logaritma', lesson: 'Matematik', done: false, weak: true },
  { id: 'sub4', name: 'Türev', lesson: 'Matematik', done: false, weak: false },
  { id: 'sub5', name: 'Paragraf', lesson: 'Türkçe', done: true, weak: false },
  { id: 'sub6', name: 'Dil Bilgisi', lesson: 'Türkçe', done: false, weak: false },
  { id: 'sub7', name: 'Mekanik', lesson: 'Fizik', done: true, weak: false },
  { id: 'sub8', name: 'Elektrik', lesson: 'Fizik', done: false, weak: true },
  { id: 'sub9', name: 'Asit-Baz', lesson: 'Kimya', done: false, weak: true },
  { id: 'sub10', name: 'Organik Kimya', lesson: 'Kimya', done: false, weak: false },
  { id: 'sub11', name: 'Hücre', lesson: 'Biyoloji', done: true, weak: false },
  { id: 'sub12', name: 'Ekosistem', lesson: 'Biyoloji', done: false, weak: false },
];

export const resources = [
  { id: 'res1', name: 'Palme TYT Matematik', type: 'Kitap', total: 320, progress: 210, startDate: '2024-01-01', endDate: '2024-02-15' },
  { id: 'res2', name: 'Türkçe Soru Bankası', type: 'Soru Bankası', total: 500, progress: 340, startDate: '2024-01-05', endDate: '2024-02-20' },
  { id: 'res3', name: 'AYT Fizik Denemeleri', type: 'Deneme', total: 12, progress: 7, startDate: '2024-01-10', endDate: '2024-03-01' },
  { id: 'res4', name: 'Kimya Video Serisi', type: 'Video', total: 40, progress: 22, startDate: '2024-01-15', endDate: '2024-02-28' },
];

export const messages = [
  { id: 'm1', from: 'coach', text: 'Merhaba! Bu hafta nasılsın?', time: '09:12', read: true },
  { id: 'm2', from: 'student', text: 'İyiyim hocam, Matematik çalışıyorum.', time: '09:15', read: true },
  { id: 'm3', from: 'coach', text: 'Harika! Fonksiyonlar bölümünde soru göndereceğim sana.', time: '09:18', read: true },
  { id: 'm4', from: 'student', text: 'Tamam, bekliyorum.', time: '09:20', read: true },
  { id: 'm5', from: 'coach', text: 'Denemeni inceledim, Kimya\'ya ağırlık ver.', time: '10:30', read: false },
];

export const badges = [
  { id: 'b1', name: 'İlk Adım', desc: 'İlk çalışma kaydın', icon: '📖', earned: true, isNew: false },
  { id: 'b2', name: '3 Gün Seri', desc: '3 gün kesintisiz çalışma', icon: '🔥', earned: true, isNew: false },
  { id: 'b3', name: '7 Gün Seri', desc: '7 gün kesintisiz çalışma', icon: '⚡', earned: true, isNew: true },
  { id: 'b4', name: '14 Gün Seri', desc: '14 gün kesintisiz çalışma', icon: '💎', earned: false, progress: 7, target: 14 },
  { id: 'b5', name: '10 Saat', desc: 'Toplam 10 saat çalışma', icon: '⏱', earned: true, isNew: false },
  { id: 'b6', name: '50 Saat', desc: 'Toplam 50 saat çalışma', icon: '🏆', earned: false, progress: 31, target: 50 },
  { id: 'b7', name: 'İlk Deneme', desc: 'İlk deneme sonucun', icon: '📝', earned: true, isNew: false },
  { id: 'b8', name: '5 Deneme', desc: '5 deneme tamamla', icon: '🎯', earned: true, isNew: false },
  { id: 'b9', name: 'Kaynak Bitti', desc: 'Bir kaynağı bitir', icon: '📚', earned: false, progress: 1, target: 1 },
  { id: 'b10', name: '50 Yanlış Çözdü', desc: '50 yanlış arşivini çöz', icon: '✅', earned: false, progress: 12, target: 50 },
  { id: 'b11', name: '10 Tekrar', desc: '10 tekrar tamamla', icon: '🔄', earned: false, progress: 4, target: 10 },
  { id: 'b12', name: 'Hedef Net', desc: 'Hedef netini aştın', icon: '🌟', earned: false, progress: 88, target: 100 },
];

export const coachNotes = [
  { id: 'n1', studentId: '1', text: 'Fonksiyonlar konusunda destek lazım.', importance: 'high', createdAt: '2024-01-25 14:30' },
  { id: 'n2', studentId: '1', text: 'Aile baskısı var, dikkat et.', importance: 'normal', createdAt: '2024-01-20 09:00' },
  { id: 'n3', studentId: '2', text: 'Kimya motivasyonu düşük.', importance: 'high', createdAt: '2024-01-22 11:15' },
];

export const meetings = [
  { id: 'mt1', studentId: '1', studentName: 'Arda Kaya', participant: 'Öğrenci', datetime: '2024-02-01 15:00', subject: 'Matematik planı', note: '', status: 'planlandı' },
  { id: 'mt2', studentId: '2', studentName: 'Zeynep Yıldız', participant: 'Veli', datetime: '2024-01-30 10:00', subject: 'İlerleme değerlendirme', note: 'Çok başarılı.', status: 'tamamlandı' },
  { id: 'mt3', studentId: '3', studentName: 'Can Demir', participant: 'Öğrenci', datetime: '2024-02-05 16:00', subject: 'Motivasyon görüşmesi', note: '', status: 'planlandı' },
];

export const payments = [
  { id: 'p1', studentId: '1', studentName: 'Arda Kaya', amount: 1500, date: '2024-01-10', desc: 'Ocak ayı ücreti', paid: true },
  { id: 'p2', studentId: '2', studentName: 'Zeynep Yıldız', amount: 1500, date: '2024-01-10', desc: 'Ocak ayı ücreti', paid: true },
  { id: 'p3', studentId: '3', studentName: 'Can Demir', amount: 1500, date: '2024-01-15', desc: 'Ocak ayı ücreti', paid: false },
  { id: 'p4', studentId: '5', studentName: 'Mert Çelik', amount: 1500, date: '2024-01-05', desc: 'Ocak ayı ücreti', paid: false },
  { id: 'p5', studentId: '1', studentName: 'Arda Kaya', amount: 1500, date: '2024-02-10', desc: 'Şubat ayı ücreti', paid: false },
];

export const examTemplates = [
  { id: 't1', name: 'TYT Standart', subject: 'Tüm Dersler', ranges: [
    { from: 1, to: 40, topic: 'Türkçe' },
    { from: 41, to: 60, topic: 'Matematik Temel' },
    { from: 61, to: 80, topic: 'Fen Bilimleri' },
    { from: 81, to: 120, topic: 'Sosyal Bilimler' },
  ]},
  { id: 't2', name: 'AYT Matematik', subject: 'Matematik', ranges: [
    { from: 1, to: 20, topic: 'Analiz' },
    { from: 21, to: 40, topic: 'Cebir' },
  ]},
];

export const notifications_student = [
  { id: 'notif1', type: 'warning', text: 'Tekrar havuzunda 3 bekleyen soru var.', priority: 'high' },
  { id: 'notif2', type: 'info', text: 'Bugün 2 göreviniz tamamlanmadı.', priority: 'normal' },
  { id: 'notif3', type: 'warning', text: 'Kimya konusunda başarı oranınız %44 — ağırlık verin.', priority: 'high' },
  { id: 'notif4', type: 'info', text: '4 çözülmemiş yanlış arşivinizde bekliyor.', priority: 'normal' },
];

export const notifications_parent = [
  { id: 'pn1', icon: '✅', text: 'Bugünün çalışma programı tamamlandı!', priority: 'normal' },
  { id: 'pn2', icon: '📝', text: 'Bu hafta 2 yeni deneme eklendi.', priority: 'normal' },
  { id: 'pn3', icon: '⏰', text: 'Bu hafta henüz tekrar planı tamamlanmadı.', priority: 'high' },
];

export const aiSuggestions = [
  { id: 'ai1', category: 'Zayıf Konu', priority: 'Öncelikli', title: 'Kimya\'ya öncelik ver', desc: 'Kimya başarı oranın %44 ile en düşük seviyede. Haftada en az 3 Kimya çalışma seansı planla.', icon: '⚗️' },
  { id: 'ai2', category: 'Yanlış Arşivi', priority: 'Dikkat', title: '4 yanlış çözülmemiş bekliyor', desc: 'Yanlış arşivindeki sorular uzun süre çözülmeden kalıyor. Bu hafta en az 2 tanesini çöz.', icon: '📋' },
  { id: 'ai3', category: 'Çalışma Temposu', priority: 'İyi Gidiyorsun', title: 'Matematik tempon iyi', desc: 'Matematik çalışma süren bu hafta 3.5 saati geçti. Bu ritmi koru.', icon: '📈' },
  { id: 'ai4', category: 'Net Trendi', priority: 'Dikkat', title: 'TYT neti geçen haftadan düşük', desc: 'Son denemede net 4 puan düştü. Hata analizi yapıp hangi bölümlerde kayıp olduğunu belirle.', icon: '📉' },
];

export const riskScores = [
  { studentId: '5', studentName: 'Mert Çelik', level: 'yüksek', score: 78, avgNet: 44.8, factors: {
    netDrop: 85, pendingTask: 75, wrongUnsolved: 60, resourceDelay: 50, lowTempo: 80
  }},
  { studentId: '3', studentName: 'Can Demir', level: 'yüksek', score: 62, avgNet: 54.1, factors: {
    netDrop: 60, pendingTask: 70, wrongUnsolved: 50, resourceDelay: 40, lowTempo: 65
  }},
  { studentId: '1', studentName: 'Arda Kaya', level: 'orta', score: 38, avgNet: 67.5, factors: {
    netDrop: 30, pendingTask: 40, wrongUnsolved: 45, resourceDelay: 25, lowTempo: 35
  }},
  { studentId: '4', studentName: 'Selin Arslan', level: 'orta', score: 28, avgNet: 71.0, factors: {
    netDrop: 20, pendingTask: 30, wrongUnsolved: 25, resourceDelay: 35, lowTempo: 25
  }},
  { studentId: '2', studentName: 'Zeynep Yıldız', level: 'düşük', score: 12, avgNet: 82.3, factors: {
    netDrop: 5, pendingTask: 15, wrongUnsolved: 10, resourceDelay: 10, lowTempo: 15
  }},
];

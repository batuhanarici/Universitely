import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

// ── SVG Icons (1.5px stroke, 24px grid) ────────────────────────────────────
const icons: Record<string, React.FC<{ size?: number; color?: string }>> = {
  home: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 9.5L12 3l9 6.5V21H3z"/><path d="M9 21V12h6v9"/>
    </svg>
  ),
  user: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/>
    </svg>
  ),
  pen: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 19l7-7-3-3-7 7v3h3z"/><path d="M16 5l3 3"/>
    </svg>
  ),
  book: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 5a2 2 0 012-2h12a2 2 0 012 2v16l-8-3-8 3z"/>
    </svg>
  ),
  folder: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>
    </svg>
  ),
  check: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 13l4 4L19 7"/>
    </svg>
  ),
  calendar: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>
    </svg>
  ),
  chart: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 18l5-6 4 3 4-5 5 8"/><path d="M3 3v18h18"/>
    </svg>
  ),
  x: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="9"/><path d="M9 9l6 6M15 9l-6 6"/>
    </svg>
  ),
  repeat: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M1 4l4 4-4 4"/><path d="M5 8h14a2 2 0 012 2v3"/><path d="M23 20l-4-4 4-4"/><path d="M19 16H5a2 2 0 01-2-2v-3"/>
    </svg>
  ),
  compare: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 3H5a2 2 0 00-2 2v14a2 2 0 002 2h4M15 3h4a2 2 0 012 2v14a2 2 0 01-2 2h-4M12 3v18"/>
    </svg>
  ),
  ai: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 2l1.5 4.5L18 8l-4.5 1.5L12 14l-1.5-4.5L6 8l4.5-1.5z"/><circle cx="12" cy="18" r="3"/>
    </svg>
  ),
  report: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><path d="M14 2v6h6M8 12h8M8 16h5"/>
    </svg>
  ),
  medal: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="14" r="6"/><path d="M8.5 2.5l-2 5M15.5 2.5l2 5M9 7.5h6"/>
    </svg>
  ),
  message: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>
    </svg>
  ),
  bell: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 8a6 6 0 00-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/>
    </svg>
  ),
  students: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/>
    </svg>
  ),
  money: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <rect x="1" y="4" width="22" height="16" rx="2"/><path d="M12 9v6M9 12h6"/>
    </svg>
  ),
  alert: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><path d="M12 9v4M12 17h.01"/>
    </svg>
  ),
  task: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/>
    </svg>
  ),
  note: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><path d="M14 2v6h6M8 10h8M8 14h8M8 18h5"/>
    </svg>
  ),
  meeting: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M16 11h6"/>
    </svg>
  ),
  send: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4 20-7z"/>
    </svg>
  ),
  logout: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9"/>
    </svg>
  ),
  star: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01z"/>
    </svg>
  ),
  resource: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/>
    </svg>
  ),
  grid: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>
    </svg>
  ),
  template: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/>
    </svg>
  ),
  plus: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 5v14M5 12h14"/>
    </svg>
  ),
  trash: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/>
    </svg>
  ),
  copy: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/>
    </svg>
  ),
  download: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3"/>
    </svg>
  ),
  refresh: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M23 4v6h-6M1 20v-6h6M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/>
    </svg>
  ),
  arrow_back: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M19 12H5M12 19l-7-7 7-7"/>
    </svg>
  ),
};

export const Icon = ({ name, size = 18, color = 'currentColor' }: { name: string; size?: number; color?: string }) => {
  const Ic = icons[name];
  if (!Ic) return null;
  return <Ic size={size} color={color} />;
};

// ── Sidebar nav config ──────────────────────────────────────────────────────
const studentNav = [
  { group: 'Genel', items: [
    { path: '/student/dashboard', label: 'Günlük', icon: 'home' },
    { path: '/student/profile', label: 'Profil', icon: 'user' },
  ]},
  { group: 'Çalışma', items: [
    { path: '/student/study', label: 'Çalışma', icon: 'pen' },
    { path: '/student/subjects', label: 'Konular', icon: 'book' },
    { path: '/student/resources', label: 'Kaynaklar', icon: 'resource' },
    { path: '/student/tasks', label: 'Görevler', icon: 'task' },
    { path: '/student/calendar', label: 'Takvim', icon: 'calendar' },
  ]},
  { group: 'Ölçme', items: [
    { path: '/student/exams', label: 'Denemeler', icon: 'folder' },
    { path: '/student/analysis', label: 'Analiz', icon: 'chart' },
    { path: '/student/wrongs', label: 'Yanlışlar', icon: 'x' },
    { path: '/student/repetition', label: 'Tekrar Planı', icon: 'repeat' },
    { path: '/student/compare', label: 'Karşılaştırma', icon: 'compare' },
  ]},
  { group: 'Koç & Sistem', items: [
    { path: '/student/ai-coach', label: 'AI Koçum', icon: 'ai' },
    { path: '/student/weekly-report', label: 'Haftalık Rapor', icon: 'report' },
    { path: '/student/motivation', label: 'Motivasyon', icon: 'medal' },
    { path: '/student/messages', label: 'Mesajlar', icon: 'message' },
    { path: '/student/notifications', label: 'Bildirimler', icon: 'bell' },
  ]},
];

const coachNav = [
  { group: 'Genel', items: [
    { path: '/coach/dashboard', label: 'Dashboard', icon: 'home' },
    { path: '/coach/risk', label: 'AI Risk', icon: 'alert' },
    { path: '/coach/accounting', label: 'Muhasebe', icon: 'money' },
  ]},
  { group: 'Sınıf', items: [
    { path: '/coach/class-overview', label: 'Sınıf Genel', icon: 'chart' },
    { path: '/coach/class-analysis', label: 'Sınıf Analiz', icon: 'grid' },
    { path: '/coach/students', label: 'Öğrenciler', icon: 'students' },
    { path: '/coach/weekly-program', label: 'Haftalık Program', icon: 'calendar' },
  ]},
  { group: 'Atama', items: [
    { path: '/coach/task-management', label: 'Görev Yönetimi', icon: 'task' },
    { path: '/coach/assign-resource', label: 'Kaynak Ata', icon: 'resource' },
    { path: '/coach/assign-subject', label: 'Konu Ata', icon: 'book' },
    { path: '/coach/lesson-management', label: 'Ders/Konu', icon: 'template' },
  ]},
  { group: 'Denemeler', items: [
    { path: '/coach/exam-template', label: 'Deneme Şablonu', icon: 'template' },
    { path: '/coach/create-exam', label: 'Deneme Oluştur', icon: 'plus' },
    { path: '/coach/enter-result', label: 'Sonuç Gir', icon: 'check' },
    { path: '/coach/bulk-result', label: 'Toplu Sonuç', icon: 'grid' },
  ]},
  { group: 'İletişim', items: [
    { path: '/coach/messages', label: 'Mesajlar', icon: 'message' },
    { path: '/coach/notes', label: 'Koç Notları', icon: 'note' },
    { path: '/coach/meetings', label: 'Görüşme & Ödeme', icon: 'meeting' },
    { path: '/coach/bulk-notify', label: 'Toplu Bildirim', icon: 'send' },
    { path: '/coach/class-report', label: 'Sınıf Raporu', icon: 'report' },
  ]},
];

const parentNav = [
  { group: 'Çocuğum', items: [
    { path: '/parent/overview', label: 'Genel Durum', icon: 'home' },
    { path: '/parent/charts', label: 'Grafikler', icon: 'chart' },
    { path: '/parent/calendar', label: 'Takvim', icon: 'calendar' },
    { path: '/parent/notifications', label: 'Bildirimler', icon: 'bell' },
    { path: '/parent/report', label: 'Rapor', icon: 'report' },
    { path: '/parent/ai-summary', label: 'AI Özet', icon: 'ai' },
    { path: '/parent/message', label: 'Koça Mesaj', icon: 'message' },
  ]},
];

function SidebarContent({ navConfig, role, roleLabel, onNavigate }: {
  navConfig: typeof studentNav; role: string; roleLabel: string; onNavigate: (p: string) => void;
}) {
  const location = useLocation();
  return (
    <div className="sidebar">
      {/* Logo */}
      <div style={{ padding: '20px 20px 12px', borderBottom: '1px solid rgba(244,239,228,0.08)' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, color: '#F4EFE4', letterSpacing: '-0.02em' }}>
          Universitely
        </div>
        <div style={{ fontSize: 11, color: 'rgba(244,239,228,0.4)', marginTop: 2, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
          {roleLabel}
        </div>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, overflowY: 'auto', padding: '8px 0' }}>
        {navConfig.map(group => (
          <div key={group.group}>
            <div className="sidebar-label">{group.group}</div>
            {group.items.map(item => (
              <a
                key={item.path}
                className={`sidebar-item ${location.pathname === item.path ? 'active' : ''}`}
                onClick={(e) => { e.preventDefault(); onNavigate(item.path); }}
                href={item.path}
              >
                <Icon name={item.icon} size={16} />
                <span>{item.label}</span>
              </a>
            ))}
          </div>
        ))}
      </nav>

      {/* Footer */}
      <div style={{ padding: '12px 8px', borderTop: '1px solid rgba(244,239,228,0.08)' }}>
        <a className="sidebar-item" onClick={(e) => { e.preventDefault(); onNavigate('/'); }} href="/">
          <Icon name="logout" size={16} />
          <span>Çıkış Yap</span>
        </a>
      </div>
    </div>
  );
}

export function StudentLayout({ children }: { children: React.ReactNode }) {
  const navigate = useNavigate();
  return (
    <div className="panel-layout">
      <SidebarContent navConfig={studentNav} role="student" roleLabel="Öğrenci Paneli" onNavigate={navigate} />
      <main className="panel-main">{children}</main>
    </div>
  );
}

export function CoachLayout({ children }: { children: React.ReactNode }) {
  const navigate = useNavigate();
  return (
    <div className="panel-layout">
      <SidebarContent navConfig={coachNav} role="coach" roleLabel="Koç Paneli" onNavigate={navigate} />
      <main className="panel-main">{children}</main>
    </div>
  );
}

export function ParentLayout({ children }: { children: React.ReactNode }) {
  const navigate = useNavigate();
  return (
    <div className="panel-layout">
      <SidebarContent navConfig={parentNav} role="parent" roleLabel="Veli Paneli" onNavigate={navigate} />
      <main className="panel-main">{children}</main>
    </div>
  );
}
